﻿namespace USAExportWorkflowWeb_V1.LDAP
{
    public class LdapConfiguration
    {
        public string Name { get; set; }
        public string Server { get; set; }
        public string Port { get; set; }
        public string Domain { get; set; }
        public string SubDomain { get; set; }
        public string DomainCode { get; set; }
    }
    public class LdapOptions
    {
        public List<LdapConfiguration> LdapConfigurations { get; set; }
        public string lDapRegion { get; set; }
    }
}
