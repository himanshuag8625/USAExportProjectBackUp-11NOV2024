﻿using ClosedXML.Excel;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Data;
using System.Linq.Dynamic.Core;
using System.Reflection;
using System.Security.Claims;
using USAExportWorkflowWeb_V1.DataModel;
using USAExportWorkflowWeb_V1.ViewModels;
using Column = USAExportWorkflowWeb_V1.ViewModels.Column;

namespace USAExportWorkflowWeb_V1.Controllers
{
    //Dashboard
    [Authorize]
    public class DashboardController : Controller
    {
        ApplicationDBContext _context;
        private readonly IHttpContextAccessor _httpContextAccessor;
        public DashboardController(ApplicationDBContext context, IHttpContextAccessor httpContextAccessor)
        {
            _context = context;
            _httpContextAccessor = httpContextAccessor;
        }
        public async Task<IActionResult> Index()
        {
			_context.Database.SetCommandTimeout(300);
			ViewData["StatusMaster"] = _context.StatusMaster.OrderBy(x => x.Status).ToList();
            ViewData["ActivityMaster"] = _context.ActivityMaster.OrderBy(x => x.NameOfActivity).ToList();
            ViewData["Users"] = _context.Users.OrderBy(x => x.UserName).ToList();
            return View();
        }


        //[HttpPost]
        //public ActionResult GetFiles(DataTableAjaxPostModel model, string activity, string user, string status, string hblnumber, string container, string etd, string bookingno, string fileno, string search)
        //{
        //    var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
        //    int pageSize = model.length.HasValue ? model.length.Value : 100;
        //    int skip = model.start.HasValue ? model.start.Value : 0;

        //    #region Search Criteria

        //    _context.Database.SetCommandTimeout(300);

        //    var threeMonthsAgo = DateTime.Now.AddMonths(-3);
        //    //Commented code 
        //    //var query = from hblMaster in _context.HBLMaster
        //    //            join hblActivityLog in _context.HBLActivityLog on hblMaster.Id equals hblActivityLog.HBLId into activityLogs
        //    //            from activityLog in activityLogs.DefaultIfEmpty()
        //    //            where hblMaster.EnterDate >= threeMonthsAgo  // Filter data for the last three months
        //    //            select new HBLDashModel
        //    //            {
        //    //                Id = hblMaster.Id,
        //    //                CountryName = _context.CountryMaster.Where(x => x.Id == hblMaster.File.CountryId).Select(x => x.CountryName).FirstOrDefault(),
        //    //                FileNumber = _context.FileMaster.Where(x => x.Id == hblMaster.FileId).Select(x => x.FileNumber).FirstOrDefault(),
        //    //                HBLNumber = hblMaster.HBLNumber,
        //    //                ContainerNo = hblMaster.Container,
        //    //                BookingNo = hblMaster.Booking,
        //    //                CustomerName = hblMaster.CustomerName,
        //    //                User = _context.Users.Where(x => x.Id == activityLog.UserId).Select(x => x.UserName).FirstOrDefault(),
        //    //                Status = _context.StatusMaster.Where(x => x.Id == activityLog.Status.Id).Select(x => x.Status).FirstOrDefault(),
        //    //                Activity = _context.ActivityMaster.Where(x => x.Id == activityLog.ActivityId).Select(x => x.NameOfActivity).FirstOrDefault(),
        //    //                ReceivedDate = hblMaster.EnterDate,
        //    //                ETD = hblMaster.File.Etd
        //    //            };

        //    List<HBLMaster> hBLDashModel = new List<HBLMaster>();
        //    hBLDashModel = _context.HBLMaster
        //        .Include(x => x.File)
        //        .ThenInclude(x => x.Country)
        //        .Include(x => x.HBLActivityLogs).ThenInclude(x => x.Status).Include(x => x.HBLActivityLogs).ThenInclude(x => x.Activity).Include(x => x.HBLActivityLogs).ThenInclude(x => x.ApplicationUser)
        //        .Where(x => x.File.Etd >= threeMonthsAgo).ToList();  // Filter data for the last three months
        //    var query = hBLDashModel.Select(x => new HBLDashModel
        //    {
        //        Id = x.Id,
        //        CountryName = x.File.Country.CountryName,
        //        HBLNumber = x.HBLNumber,
        //        ContainerNo = x.Container,
        //        BookingNo = x.Booking,
        //        CustomerName = x.CustomerName,
        //        User = x.HBLActivityLogs.Where(y => y.HBLId == x.Id).Select(y => y.ApplicationUser.UserName).FirstOrDefault(),
        //        Status = x.HBLActivityLogs.Where(y => y.HBLId == x.Id).Select(y => y.Status.Status).FirstOrDefault(),
        //        Activity = x.HBLActivityLogs.Where(y => y.HBLId == x.Id).Select(y => y.Activity.NameOfActivity).FirstOrDefault(),
        //        ReceivedDate = x.EnterDate,
        //        ETD = x.File.Etd,
        //        FileNumber = x.File.FileNumber
        //    }).AsQueryable();

        //    IQueryable<HBLDashModel> SortedData = query.AsQueryable();
        //    #endregion

        //    #region Sort

        //    foreach (Order order in model.order)
        //    {
        //        Column column = model.columns[order.column];
        //        if (column.orderable)
        //        {
        //            if (column.name != "userName" && column.name != "currentStatus")
        //            {
        //                SortedData = SortedData.OrderBy(column.name + " " + order.dir).AsQueryable();
        //            }
        //            else
        //            {
        //                SortedData = SortedData.Where(x => x.Status == status.Trim()).OrderBy(column.name + " " + order.dir).AsQueryable();
        //            }
        //        }
        //    }

        //    #endregion

        //    #region Search

        //    if (!string.IsNullOrEmpty(activity) && activity != "none" && activity != "--Select--")
        //    {
        //        SortedData = SortedData.Where(x => x.Activity == activity.Trim()).AsQueryable();
        //    }
        //    if (!string.IsNullOrEmpty(user) && user != "none" && user != "--Select--")
        //    {
        //        SortedData = SortedData.Where(x => x.User == user.Trim()).AsQueryable();
        //    }
        //    if (!string.IsNullOrEmpty(status) && status != "none" && status != "--Select--")
        //    {
        //        SortedData = SortedData.Where(x => x.Status == status.Trim()).AsQueryable();
        //    }
        //    if (!string.IsNullOrEmpty(hblnumber) && hblnumber != "none")
        //    {
        //        SortedData = SortedData.Where(x => x.HBLNumber.Contains(hblnumber.Trim())).AsQueryable();
        //    }
        //    if (!string.IsNullOrEmpty(container) && container != "none")
        //    {
        //        SortedData = SortedData.Where(x => x.ContainerNo.Contains(container.Trim())).AsQueryable();
        //    }
        //    if (!string.IsNullOrEmpty(bookingno) && bookingno != "none")
        //    {
        //        //string escapeCharacter = "%";
        //        //string searchPattern = $"%{bookingno.Trim().Replace("%", escapeCharacter)}%";
        //        //query = query.Where(x => EF.Functions.Like(x.BookingNo, searchPattern, escapeCharacter));
        //        SortedData = SortedData.Where(x => x.BookingNo.Contains(bookingno.Trim())).AsQueryable();

        //    }
        //    if (!string.IsNullOrEmpty(fileno) && fileno != "none")
        //    {
        //        SortedData = SortedData.Where(x => x.FileNumber.Contains(fileno.Trim())).AsQueryable();
        //    }
        //    if (!string.IsNullOrEmpty(etd) && etd != "none")
        //    {
        //        var etdDate = Convert.ToDateTime(etd.Trim());
        //        SortedData = SortedData.Where(x => x.ETD != null && x.ETD.Value.Date == etdDate.Date).AsQueryable();
        //    }
        //    if (search == "WIP" || search == "Completed" || search == "Pending" || search == "Query" ||
        //        search == "Received" || search == "UnAllocated" || search == "etd2" || search == "etd5" || search == "etd10")
        //    {
        //        if (search == "etd2")
        //        {
        //            var twoDaysAgo = DateTime.UtcNow.AddDays(2);
        //            SortedData = SortedData.Where(x => x.ETD != null && x.ETD.Value.Date <= twoDaysAgo.Date && x.ETD.Value.Date > DateTime.UtcNow.Date && x.Status != "Completed").AsQueryable();
        //        }
        //        else if (search == "etd5")
        //        {
        //            var tenDaysAgo = DateTime.UtcNow.AddDays(10);
        //            var fiveDaysAgo = DateTime.UtcNow.AddDays(5);
        //            SortedData = SortedData.Where(x => x.ETD != null && x.ETD.Value.Date > fiveDaysAgo.Date && x.ETD.Value.Date <= tenDaysAgo.Date && x.Status != "Completed").AsQueryable();
        //        }
        //        else if (search == "etd10")
        //        {
        //            var tenDaysAgo = DateTime.UtcNow.AddDays(10);
        //            SortedData = SortedData.Where(x => x.ETD != null && x.ETD.Value.Date > tenDaysAgo.Date && x.Status != "Completed").AsQueryable();
        //        }

        //        //else if (search == "Pending")
        //        //{
        //        //    query = query.Where(x => x.Status == "Pending" && x.Status != "Query" && x.Status != null && x.Status != "WIP");
        //        //}
        //        else if (search == "Pending")
        //        {
        //            SortedData = SortedData.Where(x => x.Status == "Pending" || x.Status == "Followup1" || x.Status == "Followup2" || x.Status == "Followup3").AsQueryable();
        //        }
        //        else if (search == "Received")
        //        {
        //            SortedData = SortedData.AsQueryable();
        //        }
        //        else
        //        {
        //            SortedData = SortedData.Where(x => x.Status == search).AsQueryable();
        //        }
        //    }

        //    //SortedData = SortedData.Skip(skip).Take(pageSize == -1 ? 100 : pageSize).AsQueryable();
        //    #endregion

        //    return Json(new
        //    {
        //        draw = model.draw,
        //        recordsTotal = query.Count(),
        //        recordsFiltered = SortedData.Count(),
        //        data = SortedData.ToList()
        //    });
        //}

        //[HttpPost]
        //public ActionResult GetFiles(DataTableAjaxPostModel model, string activity, string user, string status, string hblnumber, string container, string etd, string bookingno, string fileno, string search)
        //{
        //    var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
        //    //int pageSize = model.length.HasValue ? model.length.Value : 100;
        //    //int skip = model.start.HasValue ? model.start.Value : 0;
        //    //var draw = Request.Form["draw"].FirstOrDefault();
        //    //var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
        //    //var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();

        //    int pageSize = model.length.HasValue ? model.length.Value : 100;
        //    int skip = model.start.HasValue ? model.start.Value : 0;
        //    var draw = Request.Form["draw"].FirstOrDefault();
        //    var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
        //    var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();

        //    #region Search Criteria

        //    _context.Database.SetCommandTimeout(600);

        //    var threeMonthsAgo = DateTime.Now.AddMonths(-3);
        //    //var threeMonthsAgo = DateTime.Now.AddDays(15);
        //    //Commented code 
        //    //var query = from hblMaster in _context.HBLMaster
        //    //            join hblActivityLog in _context.HBLActivityLog on hblMaster.Id equals hblActivityLog.HBLId into activityLogs
        //    //            from activityLog in activityLogs.DefaultIfEmpty()
        //    //            where hblMaster.EnterDate >= threeMonthsAgo  // Filter data for the last three months
        //    //            select new HBLDashModel
        //    //            {
        //    //                Id = hblMaster.Id,
        //    //                CountryName = _context.CountryMaster.Where(x => x.Id == hblMaster.File.CountryId).Select(x => x.CountryName).FirstOrDefault(),
        //    //                FileNumber = _context.FileMaster.Where(x => x.Id == hblMaster.FileId).Select(x => x.FileNumber).FirstOrDefault(),
        //    //                HBLNumber = hblMaster.HBLNumber,
        //    //                ContainerNo = hblMaster.Container,
        //    //                BookingNo = hblMaster.Booking,
        //    //                CustomerName = hblMaster.CustomerName,
        //    //                User = _context.Users.Where(x => x.Id == activityLog.UserId).Select(x => x.UserName).FirstOrDefault(),
        //    //                Status = _context.StatusMaster.Where(x => x.Id == activityLog.Status.Id).Select(x => x.Status).FirstOrDefault(),
        //    //                Activity = _context.ActivityMaster.Where(x => x.Id == activityLog.ActivityId).Select(x => x.NameOfActivity).FirstOrDefault(),
        //    //                ReceivedDate = hblMaster.EnterDate,
        //    //                ETD = hblMaster.File.Etd
        //    //            };

        //    List<HBLMaster> hBLDashModel = new List<HBLMaster>();
        //    //hBLDashModel = _context.HBLMaster
        //    //    .Include(x => x.File)
        //    //    .ThenInclude(x => x.Country)
        //    //    .Include(x => x.HBLActivityLogs).ThenInclude(x => x.Status).Include(x => x.HBLActivityLogs).ThenInclude(x => x.Activity).Include(x => x.HBLActivityLogs).ThenInclude(x => x.ApplicationUser)
        //    //    .Where(x => x.File.Etd >= threeMonthsAgo).ToList();  // Filter data for the last three months
        //    //var query = hBLDashModel.Select(x => new HBLDashModel
        //    //{
        //    //    Id = x.Id,
        //    //    CountryName = x.File.Country.CountryName,
        //    //    HBLNumber = x.HBLNumber,
        //    //    ContainerNo = x.Container,
        //    //    BookingNo = x.Booking,
        //    //    CustomerName = x.CustomerName,
        //    //    User = x.HBLActivityLogs.Where(y => y.HBLId == x.Id).Select(y => y.ApplicationUser.UserName).FirstOrDefault(),
        //    //    Status = x.HBLActivityLogs.Where(y => y.HBLId == x.Id).Select(y => y.Status.Status).FirstOrDefault(),
        //    //    Activity = x.HBLActivityLogs.Where(y => y.HBLId == x.Id).Select(y => y.Activity.NameOfActivity).FirstOrDefault(),
        //    //    ReceivedDate = x.EnterDate,
        //    //    ETD = x.File.Etd,
        //    //    FileNumber = x.File.FileNumber
        //    //}).AsQueryable();

        //    var query = _context.HBLMaster
        //                .Where(x => x.File.Etd.Value.Date >= threeMonthsAgo.Date)
        //                .Include(x => x.File)
        //                    .ThenInclude(file => file.Country)
        //                .Include(x => x.HBLActivityLogs)
        //                    .ThenInclude(log => log.Status)
        //                .Include(x => x.HBLActivityLogs)
        //                    .ThenInclude(log => log.Activity)
        //                .Include(x => x.HBLActivityLogs)
        //                    .ThenInclude(log => log.ApplicationUser)
        //                .Select(x => new HBLDashModel
        //                {
        //                    Id = x.Id,
        //                    CountryName = x.File.Country.CountryName,
        //                    HBLNumber = x.HBLNumber,
        //                    ContainerNo = x.Container,
        //                    BookingNo = x.Booking,
        //                    CustomerName = x.CustomerName,
        //                    User = x.HBLActivityLogs
        //                        .OrderByDescending(x => x.ActivityId) // Assuming logs have a LogDate to get the latest one
        //                        .Select(x => x.ApplicationUser.UserName)
        //                        .FirstOrDefault(),
        //                    Status = x.HBLActivityLogs
        //                        .OrderByDescending(x => x.ActivityId) // Assuming logs have a LogDate to get the latest one
        //                        .Select(x => x.Status.Status)
        //                        .FirstOrDefault(),
        //                    Activity = x.HBLActivityLogs
        //                        .OrderByDescending

        //                        (x => x.ActivityId) // Assuming logs have a LogDate to get the latest one
        //                        .Select(x => x.Activity.NameOfActivity)
        //                        .FirstOrDefault(),
        //                    ReceivedDate = x.EnterDate,
        //                    ETD = x.File.Etd,
        //                    FileNumber = x.File.FileNumber
        //                }).ToList();



        //    // Sort data if necessary (deferred execution)
        //    //IQueryable<HBLDashModel> SortedData = query;

        //    IQueryable<HBLDashModel> SortedData = query.AsQueryable();
        //    #endregion

        //    #region Sort

        //    //foreach (Order order in model.order)
        //    //{
        //    //    Column column = model.columns[order.column];
        //    //    if (column.orderable)
        //    //    {
        //    //        if (column.name != "userName" && column.name != "currentStatus")
        //    //        {
        //    //            SortedData = SortedData.OrderBy(column.name + " " + order.dir).AsQueryable();
        //    //        }
        //    //        else
        //    //        {
        //    //            SortedData = SortedData.Where(x => x.Status == status.Trim()).OrderBy(column.name + " " + order.dir).AsQueryable();
        //    //        }
        //    //    }
        //    //}

        //    #endregion

        //    #region Search

        //    if (!string.IsNullOrEmpty(activity) && activity != "none" && activity != "--Select--")
        //    {
        //        SortedData = SortedData.Where(x => x.Activity == activity.Trim()).AsQueryable();
        //    }
        //    if (!string.IsNullOrEmpty(user) && user != "none" && user != "--Select--")
        //    {
        //        SortedData = SortedData.Where(x => x.User == user.Trim()).AsQueryable();
        //    }
        //    if (!string.IsNullOrEmpty(status) && status != "none" && status != "--Select--")
        //    {
        //        SortedData = SortedData.Where(x => x.Status == status.Trim()).AsQueryable();
        //    }
        //    if (!string.IsNullOrEmpty(hblnumber) && hblnumber != "none")
        //    {
        //        SortedData = SortedData.Where(x => x.HBLNumber.Contains(hblnumber.Trim())).AsQueryable();
        //    }
        //    if (!string.IsNullOrEmpty(container) && container != "none")
        //    {
        //        SortedData = SortedData.Where(x => x.ContainerNo.Contains(container.Trim())).AsQueryable();
        //    }
        //    if (!string.IsNullOrEmpty(bookingno) && bookingno != "none")
        //    {
        //        //string escapeCharacter = "%";
        //        //string searchPattern = $"%{bookingno.Trim().Replace("%", escapeCharacter)}%";
        //        //query = query.Where(x => EF.Functions.Like(x.BookingNo, searchPattern, escapeCharacter));
        //        SortedData = SortedData.Where(x => x.BookingNo.Contains(bookingno.Trim())).AsQueryable();

        //    }
        //    if (!string.IsNullOrEmpty(fileno) && fileno != "none")
        //    {
        //        SortedData = SortedData.Where(x => x.FileNumber.Contains(fileno.Trim())).AsQueryable();
        //    }
        //    if (!string.IsNullOrEmpty(etd) && etd != "none")
        //    {
        //        var etdDate = Convert.ToDateTime(etd.Trim());
        //        SortedData = SortedData.Where(x => x.ETD != null && x.ETD.Value.Date == etdDate.Date).AsQueryable();
        //    }
        //    if (search == "WIP" || search == "Completed" || search == "Pending" || search == "Query" ||
        //        search == "Received" || search == "UnAllocated" || search == "etd2" || search == "etd5" || search == "etd10")
        //    {
        //        if (search == "etd2")
        //        {
        //            var twoDaysAgo = DateTime.UtcNow.AddDays(2);
        //            SortedData = SortedData.Where(x => x.ETD != null && x.ETD.Value.Date <= twoDaysAgo.Date && x.ETD.Value.Date > DateTime.UtcNow.Date && x.Status != "Completed").AsQueryable();
        //        }
        //        else if (search == "etd5")
        //        {
        //            var tenDaysAgo = DateTime.UtcNow.AddDays(10);
        //            var fiveDaysAgo = DateTime.UtcNow.AddDays(5);
        //            SortedData = SortedData.Where(x => x.ETD != null && x.ETD.Value.Date > fiveDaysAgo.Date && x.ETD.Value.Date <= tenDaysAgo.Date && x.Status != "Completed").AsQueryable();
        //        }
        //        else if (search == "etd10")
        //        {
        //            var tenDaysAgo = DateTime.UtcNow.AddDays(10);
        //            SortedData = SortedData.Where(x => x.ETD != null && x.ETD.Value.Date > tenDaysAgo.Date && x.Status != "Completed").AsQueryable();
        //        }

        //        //else if (search == "Pending")
        //        //{
        //        //    query = query.Where(x => x.Status == "Pending" && x.Status != "Query" && x.Status != null && x.Status != "WIP");
        //        //}
        //        else if (search == "Pending")
        //        {
        //            SortedData = SortedData.Where(x => x.Status == "Pending" || x.Status == "Followup1" || x.Status == "Followup2" || x.Status == "Followup3").AsQueryable();
        //        }
        //        else if (search == "Received")
        //        {
        //            SortedData = SortedData.AsQueryable();
        //        }
        //        else
        //        {
        //            SortedData = SortedData.Where(x => x.Status == search).AsQueryable();
        //        }
        //    }

        //    if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
        //    {
        //        SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
        //    }
        //    else
        //    {
        //        sortColumn = "receivedDate";
        //        sortColumnDirection = "desc";
        //        SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
        //    }

        //    //SortedData = SortedData.Skip(skip).Take(pageSize == -1 ? 100 : pageSize).AsQueryable();
        //    #endregion
        //    var data = SortedData.Skip(skip).Take(pageSize == -1 ? 100 : pageSize).ToList();
        //    var recordsTotal = query.Count();
        //    var recordsFiltered = data.Count();

        //    return Json(new
        //    {
        //        draw = draw,
        //        recordsTotal = recordsTotal,
        //        recordsFiltered = recordsFiltered,
        //        data = data
        //    });
        //}

        [HttpPost]
        public ActionResult GetFiles(DataTableAjaxPostModel model, string activity, string user, string status, string hblnumber, string container, string etd, string bookingno, string fileno, string search)
        {
            try
            {
                var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
                int pageSize = model.length.HasValue ? model.length.Value : 100;
                int skip = model.start.HasValue ? model.start.Value : 0;
                var draw = Request.Form["draw"].FirstOrDefault();
                var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
                var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();

                #region Search Criteria

                _context.Database.SetCommandTimeout(600);

                var threeMonthsAgo = DateTime.Now.AddMonths(-3);

                var query = _context.HBLMaster
                    .Where(x => x.File.Etd.Value.Date >= threeMonthsAgo.Date)
                    .Include(x => x.File)
                        .ThenInclude(file => file.Country)
                    .Include(x => x.HBLActivityLogs)
                        .ThenInclude(log => log.Status)
                    .Include(x => x.HBLActivityLogs)
                        .ThenInclude(log => log.Activity)
                    .Include(x => x.HBLActivityLogs)
                        .ThenInclude(log => log.ApplicationUser)
                    .Select(x => new HBLDashModel
                    {
                        Id = x.Id,
                        CountryName = x.File.Country.CountryName,
                        HBLNumber = x.HBLNumber,
                        ContainerNo = x.Container,
                        BookingNo = x.Booking,
                        CustomerName = x.CustomerName,
                        User = x.HBLActivityLogs
                            .OrderByDescending(x => x.ActivityId)
                            .Select(x => x.ApplicationUser.UserName)
                            .FirstOrDefault(),
                        Status = x.HBLActivityLogs
                            .OrderByDescending(x => x.ActivityId)
                            .Select(x => x.Status.Status)
                            .FirstOrDefault(),
                        Activity = x.HBLActivityLogs
                            .OrderByDescending(x => x.ActivityId)
                            .Select(x => x.Activity.NameOfActivity)
                            .FirstOrDefault(),
                        ReceivedDate = x.EnterDate,
                        ETD = x.File.Etd,
                        FileNumber = x.File.FileNumber
                    }).AsQueryable();

                #endregion

                IQueryable<HBLDashModel> SortedData = query;

                #region Search

                if (!string.IsNullOrEmpty(activity) && activity != "none" && activity != "--Select--")
                {
                    query = query.Where(x => x.Activity == activity.Trim());
                }
                if (!string.IsNullOrEmpty(user) && user != "none" && user != "--Select--")
                {
                    query = query.Where(x => x.User == user.Trim());
                }
                if (!string.IsNullOrEmpty(status) && status != "none" && status != "--Select--")
                {
                    query = query.Where(x => x.Status == status.Trim());
                }
                if (!string.IsNullOrEmpty(hblnumber) && hblnumber != "none")
                {
                    query = query.Where(x => x.HBLNumber.Contains(hblnumber.Trim()));
                }
                if (!string.IsNullOrEmpty(container) && container != "none")
                {
                    query = query.Where(x => x.ContainerNo.Contains(container.Trim()));
                }
                if (!string.IsNullOrEmpty(bookingno) && bookingno != "none")
                {
                    query = query.Where(x => x.BookingNo.Contains(bookingno.Trim()));
                }
                if (!string.IsNullOrEmpty(fileno) && fileno != "none")
                {
                    query = query.Where(x => x.FileNumber.Contains(fileno.Trim()));
                }
                if (!string.IsNullOrEmpty(etd) && etd != "none")
                {
                    var etdDate = Convert.ToDateTime(etd.Trim());
                    query = query.Where(x => x.ETD != null && x.ETD.Value.Date == etdDate.Date);
                }
                if (search == "WIP" || search == "Completed" || search == "Pending" || search == "Query" ||
                    search == "Received" || search == "UnAllocated" || search == "etd2" || search == "etd5" || search == "etd10")
                {
                    if (search == "etd2")
                    {
                        var twoDaysAgo = DateTime.UtcNow.AddDays(2);
                        query = query.Where(x => x.ETD != null && x.ETD.Value.Date <= twoDaysAgo.Date && x.ETD.Value.Date > DateTime.UtcNow.Date && x.Status != "Completed");
                    }
                    else if (search == "etd5")
                    {
                        var tenDaysAgo = DateTime.UtcNow.AddDays(10);
                        var fiveDaysAgo = DateTime.UtcNow.AddDays(5);
                        query = query.Where(x => x.ETD != null && x.ETD.Value.Date > fiveDaysAgo.Date && x.ETD.Value.Date <= tenDaysAgo.Date && x.Status != "Completed");
                    }
                    else if (search == "etd10")
                    {
                        var tenDaysAgo = DateTime.UtcNow.AddDays(10);
                        query = query.Where(x => x.ETD != null && x.ETD.Value.Date > tenDaysAgo.Date && x.Status != "Completed");
                    }
                    else if (search == "Pending")
                    {
                        query = query.Where(x => x.Status == "Pending" || x.Status == "Followup1" || x.Status == "Followup2" || x.Status == "Followup3");
                    }
                    else if (search == "Received")
                    {
                        // No filtering needed
                    }
                    else
                    {
                        query = query.Where(x => x.Status == search);
                    }
                }

                if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
                {
                    query = query.OrderBy(sortColumn + " " + sortColumnDirection);
                }
                else
                {
                    sortColumn = "receivedDate";
                    sortColumnDirection = "desc";
                    query = query.OrderBy(sortColumn + " " + sortColumnDirection);
                }
                #endregion

                var data = query;
                var recordsTotal = query.Count();
                var recordsFiltered = data.Count();

                return Json(new
                {
                    draw = draw,
                    recordsTotal = recordsTotal,
                    recordsFiltered = recordsFiltered,
                    data = data.Skip(skip).Take(pageSize == -1 ? 100 : pageSize).ToList()
                });
            }
            catch (Exception ex)
            {
                // Log the exception (you can use your logging mechanism here)
                return Json(new
                {
                    error = ex.Message
                });
            }
        }

        //public JsonResult GetDashboardCount(string activity, string user, string status, string hblnumber, string container, string etd, string bookingno, string fileno, string search)
        //{
        //    //var hBLActivityLog = _context.HBLActivityLog.Include(x => x.Hbl.File).Include(x => x.Status).Include(x => x.ApplicationUser).ToList();
        //    _context.Database.SetCommandTimeout(600);

        //    var threeMonthsAgo = DateTime.Now.AddMonths(-3);
        //    //var threeMonthsAgo = DateTime.Now.AddDays(15);
        //    ////_context.Database.SetCommandTimeout(300);
        //    //List<HBLMaster> hBLDashModel = new List<HBLMaster>();
        //    //hBLDashModel = _context.HBLMaster
        //    //    .Include(x => x.File)
        //    //    .ThenInclude(x => x.Country)
        //    //    .Include(x => x.HBLActivityLogs).ThenInclude(x => x.Status).Include(x => x.HBLActivityLogs).ThenInclude(x => x.Activity).Include(x => x.HBLActivityLogs).ThenInclude(x => x.ApplicationUser)
        //    //    .Where(x => x.EnterDate >= threeMonthsAgo).ToList();  // Filter data for the last three months
        //    //var query = hBLDashModel.Select(x => new HBLDashModel
        //    //{
        //    //    Id = x.Id,
        //    //    CountryName = x.File.Country.CountryName,
        //    //    HBLNumber = x.HBLNumber,
        //    //    ContainerNo = x.Container,
        //    //    BookingNo = x.Booking,
        //    //    CustomerName = x.CustomerName,
        //    //    User = x.HBLActivityLogs.Where(y => y.HBLId == x.Id).Select(y => y.ApplicationUser.UserName).FirstOrDefault(),
        //    //    Status = x.HBLActivityLogs.Where(y => y.HBLId == x.Id).Select(y => y.Status.Status).FirstOrDefault(),
        //    //    Activity = x.HBLActivityLogs.Where(y => y.HBLId == x.Id).Select(y => y.Activity.NameOfActivity).FirstOrDefault(),
        //    //    ReceivedDate = x.EnterDate,
        //    //    ETD = x.File.Etd,
        //    //    FileNumber = x.File.FileNumber
        //    //}).AsQueryable();

        //    //IQueryable<HBLDashModel> SortedData = query.AsQueryable();

        //    ////DashboardProdcount dp = new DashboardProdcount
        //    ////{
        //    ////    Received = SortedData.Count(),
        //    ////    Pending = hBLActivityLog.Where(x => x.Status.Status == "Pending").Count() + hBLActivityLog.Where(x => x.Status.Status == "Followup1").Count() + hBLActivityLog.Where(x => x.Status.Status == "Followup2").Count() + hBLActivityLog.Where(x => x.Status.Status == "Followup3").Count(),
        //    ////    WIP = hBLActivityLog.Where(x => x.Status.Status == "WIP").Count(),
        //    ////    Query = hBLActivityLog.Where(x => x.Status.Status == "Query").Count(),
        //    ////    Completed = hBLActivityLog.Where(x => x.Status.Status == "Completed").Count(),
        //    ////    UnAllocated = hBLActivityLog.Where(x => x.StatusId == null && x.UserId == null).Count(),
        //    ////    etd2 = SortedData.Where(x => x.ETD.Value.AddDays(2) <= DateTime.UtcNow && (x.Status != "Completed")).Count(),
        //    ////    etd5 = SortedData.Where(x => x.ETD.Value.AddDays(5) > DateTime.UtcNow && x.ETD.Value.AddDays(2) <= DateTime.UtcNow && (x.Status == null || x.Status != "Completed")).Count(),
        //    ////    etd10 = SortedData.Where(x => x.ETD.Value.AddDays(10) > DateTime.UtcNow && (x.Status != "Completed")).Count(),

        //    ////};
        //    //DashboardProdcount dp = new DashboardProdcount
        //    //{
        //    //    Received = SortedData.Count(),
        //    //    Pending = SortedData.Where(x => x.Status == "Pending").Count() + SortedData.Where(x => x.Status == "Followup1").Count() + SortedData.Where(x => x.Status == "Followup2").Count() + SortedData.Where(x => x.Status == "Followup3").Count(),
        //    //    WIP = SortedData.Where(x => x.Status == "WIP").Count(),
        //    //    Query = SortedData.Where(x => x.Status == "Query").Count(),
        //    //    Completed = SortedData.Where(x => x.Status == "Completed").Count(),
        //    //    UnAllocated = SortedData.Where(x => x.Status == null && x.User == null).Count(),
        //    //    etd2 = SortedData.Where(x => x.ETD.Value.AddDays(2) <= DateTime.UtcNow && (x.Status != "Completed")).Count(),
        //    //    etd5 = SortedData.Where(x => x.ETD.Value.AddDays(5) > DateTime.UtcNow && x.ETD.Value.AddDays(2) <= DateTime.UtcNow && (x.Status == null || x.Status != "Completed")).Count(),
        //    //    etd10 = SortedData.Where(x => x.ETD.Value.AddDays(10) > DateTime.UtcNow && (x.Status != "Completed")).Count(),

        //    //};

        //    //List<HBLMaster> hBLDashModel = new List<HBLMaster>();
        //    //hBLDashModel = _context.HBLMaster
        //    //    .Include(x => x.File)
        //    //    .ThenInclude(x => x.Country)
        //    //    .Include(x => x.HBLActivityLogs).ThenInclude(x => x.Status).Include(x => x.HBLActivityLogs).ThenInclude(x => x.Activity).Include(x => x.HBLActivityLogs).ThenInclude(x => x.ApplicationUser)
        //    //    .Where(x => x.File.Etd >= threeMonthsAgo).ToList();  // Filter data for the last three months
        //    //var query = hBLDashModel.Select(x => new HBLDashModel
        //    //{
        //    //    Id = x.Id,
        //    //    CountryName = x.File.Country.CountryName,
        //    //    HBLNumber = x.HBLNumber,
        //    //    ContainerNo = x.Container,
        //    //    BookingNo = x.Booking,
        //    //    CustomerName = x.CustomerName,
        //    //    User = x.HBLActivityLogs.Where(y => y.HBLId == x.Id).Select(y => y.ApplicationUser.UserName).FirstOrDefault(),
        //    //    Status = x.HBLActivityLogs.Where(y => y.HBLId == x.Id).Select(y => y.Status.Status).FirstOrDefault(),
        //    //    Activity = x.HBLActivityLogs.Where(y => y.HBLId == x.Id).Select(y => y.Activity.NameOfActivity).FirstOrDefault(),
        //    //    ReceivedDate = x.EnterDate,
        //    //    ETD = x.File.Etd,
        //    //    FileNumber = x.File.FileNumber
        //    //}).AsQueryable();

        //    var query = _context.HBLMaster
        //                .Where(x => x.File.Etd.Value.Date >= threeMonthsAgo.Date)
        //                .Include(x => x.File)
        //                    .ThenInclude(file => file.Country)
        //                .Include(x => x.HBLActivityLogs)
        //                    .ThenInclude(log => log.Status)
        //                .Include(x => x.HBLActivityLogs)
        //                    .ThenInclude(log => log.Activity)
        //                .Include(x => x.HBLActivityLogs)
        //                    .ThenInclude(log => log.ApplicationUser)
        //                .Select(x => new HBLDashModel
        //                {
        //                    Id = x.Id,
        //                    CountryName = x.File.Country.CountryName,
        //                    HBLNumber = x.HBLNumber,
        //                    ContainerNo = x.Container,
        //                    BookingNo = x.Booking,
        //                    CustomerName = x.CustomerName,
        //                    User = x.HBLActivityLogs
        //                        .OrderByDescending(x => x.ActivityId) // Assuming logs have a LogDate to get the latest one
        //                        .Select(x => x.ApplicationUser.UserName)
        //                        .FirstOrDefault(),
        //                    Status = x.HBLActivityLogs
        //                        .OrderByDescending(x => x.ActivityId) // Assuming logs have a LogDate to get the latest one
        //                        .Select(x => x.Status.Status)
        //                        .FirstOrDefault(),
        //                    Activity = x.HBLActivityLogs
        //                        .OrderByDescending(x => x.ActivityId) // Assuming logs have a LogDate to get the latest one
        //                        .Select(x => x.Activity.NameOfActivity)
        //                        .FirstOrDefault(),
        //                    ReceivedDate = x.EnterDate,
        //                    ETD = x.File.Etd,
        //                    FileNumber = x.File.FileNumber
        //                }).ToList();



        //    IQueryable<HBLDashModel> SortedData = query.AsQueryable();
        //    if (!string.IsNullOrEmpty(activity) && activity != "none" && activity != "--Select--")
        //    {
        //        SortedData = SortedData.Where(x => x.Activity == activity.Trim()).AsQueryable();
        //    }
        //    if (!string.IsNullOrEmpty(user) && user != "none" && user != "--Select--")
        //    {
        //        SortedData = SortedData.Where(x => x.User == user.Trim()).AsQueryable();
        //    }
        //    if (!string.IsNullOrEmpty(status) && status != "none" && status != "--Select--")
        //    {
        //        SortedData = SortedData.Where(x => x.Status == status.Trim()).AsQueryable();
        //    }
        //    if (!string.IsNullOrEmpty(hblnumber) && hblnumber != "none")
        //    {
        //        SortedData = SortedData.Where(x => x.HBLNumber.Contains(hblnumber.Trim())).AsQueryable();
        //    }
        //    if (!string.IsNullOrEmpty(container) && container != "none")
        //    {
        //        SortedData = SortedData.Where(x => x.ContainerNo.Contains(container.Trim())).AsQueryable();
        //    }
        //    if (!string.IsNullOrEmpty(bookingno) && bookingno != "none")
        //    {
        //        //string escapeCharacter = "%";
        //        //string searchPattern = $"%{bookingno.Trim().Replace("%", escapeCharacter)}%";
        //        //query = query.Where(x => EF.Functions.Like(x.BookingNo, searchPattern, escapeCharacter));
        //        SortedData = SortedData.Where(x => x.BookingNo.Contains(bookingno.Trim())).AsQueryable();

        //    }
        //    if (!string.IsNullOrEmpty(fileno) && fileno != "none")
        //    {
        //        SortedData = SortedData.Where(x => x.FileNumber.Contains(fileno.Trim())).AsQueryable();
        //    }
        //    if (!string.IsNullOrEmpty(etd) && etd != "none")
        //    {
        //        var etdDate = Convert.ToDateTime(etd.Trim());
        //        SortedData = SortedData.Where(x => x.ETD != null && x.ETD.Value.Date == etdDate.Date).AsQueryable();
        //    }
        //    var twoDaysAgo = DateTime.UtcNow.AddDays(2);
        //    var fiveDaysAgo = DateTime.UtcNow.AddDays(5);
        //    var tenDaysAgo = DateTime.UtcNow.AddDays(10);
        //    //var tenDaysAgo = DateTime.UtcNow.AddDays(10);

        //    DashboardProdcount dp = new DashboardProdcount
        //    {
        //        Received = SortedData.Count(),
        //        Pending = SortedData.Count(x => x.Status == "Pending" || x.Status == "Followup1" || x.Status == "Followup2" || x.Status == "Followup3"),
        //        WIP = SortedData.Count(x => x.Status == "WIP"),
        //        Query = SortedData.Count(x => x.Status == "Query"),
        //        Completed = SortedData.Count(x => x.Status == "Completed"),
        //        UnAllocated = SortedData.Count(x => x.Status == null && x.User == null),
        //        etd2 = SortedData.Count(x => x.ETD != null && x.ETD.Value.Date <= twoDaysAgo.Date && x.ETD.Value.Date > DateTime.UtcNow.Date && x.Status != "Completed"),
        //        etd5 = SortedData.Count(x => x.ETD != null && x.ETD.Value.Date > fiveDaysAgo.Date && x.ETD.Value.Date <= tenDaysAgo.Date && x.Status != "Completed"),
        //        etd10 = SortedData.Count(x => x.ETD != null && x.ETD.Value.Date > tenDaysAgo.Date && x.Status != "Completed")

        //    };

        //    return Json(dp);
        //}

        public JsonResult GetDashboardCount(string activity, string user, string status, string hblnumber, string container, string etd, string bookingno, string fileno, string search)
        {
            _context.Database.SetCommandTimeout(600);

            var threeMonthsAgo = DateTime.Now.AddMonths(-3);

            var query = _context.HBLMaster
                .Where(x => x.File.Etd.Value.Date >= threeMonthsAgo.Date)
                .Include(x => x.File)
                    .ThenInclude(file => file.Country)
                .Include(x => x.HBLActivityLogs)
                    .ThenInclude(log => log.Status)
                .Include(x => x.HBLActivityLogs)
                    .ThenInclude(log => log.Activity)
                .Include(x => x.HBLActivityLogs)
                    .ThenInclude(log => log.ApplicationUser)
                .Select(x => new HBLDashModel
                {
                    Id = x.Id,
                    CountryName = x.File.Country.CountryName,
                    HBLNumber = x.HBLNumber,
                    ContainerNo = x.Container,
                    BookingNo = x.Booking,
                    CustomerName = x.CustomerName,
                    User = x.HBLActivityLogs
                        .OrderByDescending(x => x.ActivityId)
                        .Select(x => x.ApplicationUser.UserName)
                        .FirstOrDefault(),
                    Status = x.HBLActivityLogs
                        .OrderByDescending(x => x.ActivityId)
                        .Select(x => x.Status.Status)
                        .FirstOrDefault(),
                    Activity = x.HBLActivityLogs
                        .OrderByDescending(x => x.ActivityId)
                        .Select(x => x.Activity.NameOfActivity)
                        .FirstOrDefault(),
                    ReceivedDate = x.EnterDate,
                    ETD = x.File.Etd,
                    FileNumber = x.File.FileNumber
                }).ToList();

            IQueryable<HBLDashModel> SortedData = query.AsQueryable();

            #region Search

            if (!string.IsNullOrEmpty(activity) && activity != "none" && activity != "--Select--")
            {
                SortedData = SortedData.Where(x => x.Activity == activity.Trim());
            }
            if (!string.IsNullOrEmpty(user) && user != "none" && user != "--Select--")
            {
                SortedData = SortedData.Where(x => x.User == user.Trim());
            }
            if (!string.IsNullOrEmpty(status) && status != "none" && status != "--Select--")
            {
                SortedData = SortedData.Where(x => x.Status == status.Trim());
            }
            if (!string.IsNullOrEmpty(hblnumber) && hblnumber != "none")
            {
                SortedData = SortedData.Where(x => x.HBLNumber.Contains(hblnumber.Trim()));
            }
            if (!string.IsNullOrEmpty(container) && container != "none")
            {
                SortedData = SortedData.Where(x => x.ContainerNo.Contains(container.Trim()));
            }
            if (!string.IsNullOrEmpty(bookingno) && bookingno != "none")
            {
                SortedData = SortedData.Where(x => x.BookingNo.Contains(bookingno.Trim()));
            }
            if (!string.IsNullOrEmpty(fileno) && fileno != "none")
            {
                SortedData = SortedData.Where(x => x.FileNumber.Contains(fileno.Trim()));
            }
            if (!string.IsNullOrEmpty(etd) && etd != "none")
            {
                var etdDate = Convert.ToDateTime(etd.Trim());
                SortedData = SortedData.Where(x => x.ETD != null && x.ETD.Value.Date == etdDate.Date);
            }
            #endregion

            var twoDaysAgo = DateTime.UtcNow.AddDays(2);
            var fiveDaysAgo = DateTime.UtcNow.AddDays(5);
            var tenDaysAgo = DateTime.UtcNow.AddDays(10);

            DashboardProdcount dp = new DashboardProdcount
            {
                Received = SortedData.Count(),
                Pending = SortedData.Count(x => x.Status == "Pending" || x.Status == "Followup1" || x.Status == "Followup2" || x.Status == "Followup3"),
                WIP = SortedData.Count(x => x.Status == "WIP"),
                Query = SortedData.Count(x => x.Status == "Query"),
                Completed = SortedData.Count(x => x.Status == "Completed"),
                UnAllocated = SortedData.Count(x => x.Status == null && x.User == null),
                etd2 = SortedData.Count(x => x.ETD != null && x.ETD.Value.Date <= twoDaysAgo.Date && x.ETD.Value.Date > DateTime.UtcNow.Date && x.Status != "Completed"),
                etd5 = SortedData.Count(x => x.ETD != null && x.ETD.Value.Date > fiveDaysAgo.Date && x.ETD.Value.Date <= tenDaysAgo.Date && x.Status != "Completed"),
                etd10 = SortedData.Count(x => x.ETD != null && x.ETD.Value.Date > tenDaysAgo.Date && x.Status != "Completed")
            };
            return Json(dp);
        }


        public ActionResult QuotationIndex()
        {
			_context.Database.SetCommandTimeout(300);
			ViewData["Users"] = _context.Users.ToList();
            ViewData["StatusMaster"] = _context.StatusMaster.ToList();
            ViewData["OfficeName"] = _context.CountryMaster.ToList();
            return View();
        }

        [HttpPost]

        public JsonResult GetQuotations(DataTableAjaxPostModel model, string user, string quotationNumber, string productType, string office)
        {
			_context.Database.SetCommandTimeout(300);
			var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            int pageSize = model.length.HasValue ? model.length.Value : 100;
            int skip = model.start.HasValue ? model.start.Value : 0;

            #region Search Criteria

            var query = _context.QutationMaster.Select(x => new QutationMaster
            {
                id = x.id,
                QuoteNumber = x.QuoteNumber,
                ContainerType = x.ContainerType,
                BookingOffice = _context.CountryMaster.Where(y => y.Id == x.BookingOffice).Select(y => y.CountryName).FirstOrDefault(),
                DoorPort = x.DoorPort,
                QuoteDate = x.QuoteDate == null ? null : x.QuoteDate,
                UserId = _context.Users.Where(y => y.Id == x.UserId).Select(y => y.CitrixId).FirstOrDefault()

            });

            #endregion

            #region Sort

            foreach (Order order in model.order)
            {
                Column column = model.columns[order.column];
                if (column.orderable)
                {
                    if (column.name != "userName" && column.name != "currentStatus")
                    {
                        query = query.OrderBy(column.name + " " + order.dir);
                    }
                }
            }

            #endregion

            #region Search

            if (!string.IsNullOrEmpty(user) && user != "none" && user != "--Select--")
            {
                query = query.Where(x => x.UserId == user.Trim());
            }
            if (!string.IsNullOrEmpty(quotationNumber) && quotationNumber != "none")
            {
                query = query.Where(x => x.QuoteNumber.Contains(quotationNumber.Trim()));
            }
            if (!string.IsNullOrEmpty(productType) && productType != "none")
            {
                query = query.Where(x => x.ContainerType == productType.Trim());
            }
            if (!string.IsNullOrEmpty(office) && office != "none" && office != "--Select--")
            {
                query = query.Where(x => x.BookingOffice == office.Trim());
            }
            //if (!string.IsNullOrEmpty(etd) && etd != "none")
            //{
            //    var etdDate = Convert.ToDateTime(etd.Trim());
            //    query = query.Where(x => x.ETD != null && x.ETD.Value.Date == etdDate.Date);
            //}

            #endregion

            return Json(new
            {
                draw = model.draw,
                recordsTotal = query.Count(),
                recordsFiltered = query.Count(),
                data = query.Skip(skip).Take(pageSize == -1 ? 100 : pageSize)
            });
        }
        private IQueryable<HBLDashModel> GetFilteredData(string activity, string user, string status, string search, string hblnumber, string container, string etd, string bookingno, string fileno)
        {
			_context.Database.SetCommandTimeout(300);
			var query = _context.HBLMaster.Include(x => x.File).ThenInclude(x => x.Country)
                .Select(x => new HBLDashModel
                {
                    Id = x.Id,
                    CountryName = x.File.Country.CountryName,
                    FileNumber = x.File.FileNumber,
                    HBLNumber = x.HBLNumber,
                    ContainerNo = x.Container,
                    BookingNo = x.Booking,
                    CustomerName = x.CustomerName,
                    User = x.HBLActivityLogs.Select(x => x.ApplicationUser.UserName).FirstOrDefault(),
                    Status = x.HBLActivityLogs.Select(x => x.Status.Status).FirstOrDefault(),
                    Activity = x.HBLActivityLogs.Select(x => x.Activity.NameOfActivity).FirstOrDefault(),
                    ReceivedDate = x.EnterDate,
                    ETD = x.File.Etd
                }).AsQueryable();

            // Apply filters based on the provided parameters
            if (!string.IsNullOrEmpty(activity) && activity != "none" && activity != "--Select--")
            {
                query = query.Where(x => x.Activity == activity.Trim());
            }
            if (!string.IsNullOrEmpty(user) && user != "none" && user != "--Select--")
            {
                query = query.Where(x => x.User == user.Trim());
            }
            if (!string.IsNullOrEmpty(status) && status != "none" && status != "--Select--")
            {
                query = query.Where(x => x.Status == status.Trim());
            }
            if (!string.IsNullOrEmpty(hblnumber) && hblnumber != "none")
            {
                query = query.Where(x => x.HBLNumber.Contains(hblnumber.Trim()));
            }
            if (!string.IsNullOrEmpty(container) && container != "none")
            {
                query = query.Where(x => x.ContainerNo.Contains(container.Trim()));
            }
            if (!string.IsNullOrEmpty(bookingno) && bookingno != "none")
            {
                query = query.Where(x => x.BookingNo.Contains(bookingno.Trim()));
            }
            if (!string.IsNullOrEmpty(fileno) && fileno != "none")
            {
                query = query.Where(x => x.FileNumber.Contains(fileno.Trim()));
            }
            if (!string.IsNullOrEmpty(etd) && etd != "none")
            {
                var etdDate = Convert.ToDateTime(etd.Trim());
                query = query.Where(x => x.ETD != null && x.ETD.Value.Date == etdDate.Date);
            }

            if (search == "WIP" || search == "Completed" || search == "Pending" || search == "Query" ||
                search == "Received" || search == "UnAllocated" || search == "etd2" || search == "etd5" || search == "etd10")
            {
                // Apply additional search filters
                if (search == "etd2")
                {
                    var twoDaysAgo = DateTime.UtcNow.AddDays(2);
                    query = query.Where(x => x.ETD != null && x.ETD.Value.Date <= twoDaysAgo.Date && x.ETD.Value.Date > DateTime.UtcNow.Date && x.Status != "Completed");
                }
                else if (search == "etd5")
                {
                    var tenDaysAgo = DateTime.UtcNow.AddDays(10);
                    var fiveDaysAgo = DateTime.UtcNow.AddDays(5);
                    query = query.Where(x => x.ETD != null && x.ETD.Value.Date > fiveDaysAgo.Date && x.ETD.Value.Date <= tenDaysAgo.Date && x.Status != "Completed");
                }
                else if (search == "etd10")
                {
                    var tenDaysAgo = DateTime.UtcNow.AddDays(10);
                    query = query.Where(x => x.ETD != null && x.ETD.Value.Date > tenDaysAgo.Date && x.Status != "Completed");
                }

                else if (search == "Pending")
                {
                    query = query.Where(x => x.Status != "Completed" && x.Status != "Query" && x.Status != null && x.Status != "WIP");
                }
                else
                {
                    query = query.Where(x => x.Status == search);
                }
            }
            // Sorting data by columns



            return query.AsQueryable();
        }

        private byte[] GenerateExcelFile(DataTable data)
        {
            using (var workbook = new XLWorkbook())
            {
                var worksheet = workbook.Worksheets.Add(data, "Sheet1");



                // Load the data into the worksheet
                //        worksheet.Cell(1, 1).InsertTable(data);

                //        // Auto-fit columns
                //        // Auto-fit columns
                //        worksheet.ColumnWidth = 15; // Set a default column width

                //// Manually set column widths based on an estimated maximum width
                //worksheet.Column(1).Width = 15;
                //worksheet.Column(2).Width = 15;
                //worksheet.Column(3).Width = 15;
                //worksheet.Column(4).Width = 15;
                //worksheet.Column(5).Width = 15;
                //worksheet.Column(6).Width = 15;
                //worksheet.Column(7).Width = 15;

                // Convert the Excel workbook to a byte array
                using (var stream = new MemoryStream())
                {
                    workbook.SaveAs(stream);
                    return stream.ToArray();
                }

            }
        }

        [HttpPost]
        public ActionResult DownloadExcel(string activity, string user, string status, string search, string hblnumber, string container, string etd, string bookingno, string fileno)
        {
			//var query = from hblMaster in _context.HBLMaster
			//            join hblActivityLog in _context.HBLActivityLog
			//            on hblMaster.Id equals hblActivityLog.HBLId into activityLogs
			//            from activityLog in activityLogs.DefaultIfEmpty()
			//            select new HBLDashModel
			//            {
			//                Id = hblMaster.Id,
			//                CountryName = hblMaster.File.Country.CountryName,
			//                FileNumber = hblMaster.File.FileNumber,
			//                HBLNumber = hblMaster.HBLNumber,
			//                ContainerNo = hblMaster.Container,
			//                BookingNo = hblMaster.Booking,
			//                CustomerName = hblMaster.CustomerName,
			//                User = activityLog.ApplicationUser.UserName,
			//                Status = activityLog.Status.Status,
			//                Activity = activityLog.Activity.NameOfActivity,
			//                ReceivedDate = hblMaster.EnterDate,
			//                ETD = hblMaster.File.Etd
			//            };
			_context.Database.SetCommandTimeout(300);
			var query = _context.HBLMaster
                .Include(x => x.HBLActivityLogs)
                .Include(x => x.File)
                .ThenInclude(x => x.Country)                  // Filter data for the last three months
                .Select(x => new
                {
                    //Id = x.Id,
                    ReceivedDate = x.EnterDate,
                    CountryName = x.File.Country.CountryName,
                    FileNumber = x.File.FileNumber,
                    ContainerNo = x.Container,
                    ETD = x.File.Etd,
                    HBLNumber = x.HBLNumber,
                    BookingNo = x.Booking,
                    CustomerName = x.CustomerName,
                    User = x.HBLActivityLogs.Where(y => y.HBLId == x.Id).Select(y => y.ApplicationUser.UserName).FirstOrDefault(),
                    Status = x.HBLActivityLogs.Where(y => y.HBLId == x.Id).Select(y => y.Status.Status).FirstOrDefault(),
                    Activity = x.HBLActivityLogs.Where(y => y.HBLId == x.Id).Select(y => y.Activity.NameOfActivity).FirstOrDefault(),
                    Comment = x.HBLActivityLogs.Where(y => y.HBLId == x.Id).Select(y => y.Comment).FirstOrDefault(),
                    StartDate = x.HBLActivityLogs.Where(y => y.HBLId == x.Id).Select(y => y.StartDate).FirstOrDefault(),
                    EndDate = x.HBLActivityLogs.Where(y => y.HBLId == x.Id).Select(y => y.EndDate).FirstOrDefault()
                });

            if (!string.IsNullOrEmpty(activity) && activity != "none" && activity != "--Select--")
            {

                query = query.Where(x => x.Activity == activity.Trim());
            }
            if (!string.IsNullOrEmpty(user) && user != "none" && user != "--Select--")
            {
                query = query.Where(x => x.User == user.Trim());
            }
            if (!string.IsNullOrEmpty(status) && status != "none" && status != "--Select--")
            {
                query = query.Where(x => x.Status == status.Trim());
            }
            if (!string.IsNullOrEmpty(hblnumber) && hblnumber != "none")
            {
                query = query.Where(x => x.HBLNumber.Contains(hblnumber.Trim()));
            }
            if (!string.IsNullOrEmpty(container) && container != "none")
            {
                query = query.Where(x => x.ContainerNo.Contains(container.Trim()));
            }
            if (!string.IsNullOrEmpty(bookingno) && bookingno != "none")
            {
                query = query.Where(x => x.BookingNo.Contains(bookingno.Trim()));
            }
            if (!string.IsNullOrEmpty(fileno) && fileno != "none")
            {
                query = query.Where(x => x.FileNumber.Contains(fileno.Trim()));
            }
            if (!string.IsNullOrEmpty(etd) && etd != "none")
            {
                var etdDate = Convert.ToDateTime(etd.Trim());
                query = query.Where(x => x.ETD != null && x.ETD.Value.Date == etdDate.Date);
            }
            if (search == "WIP" || search == "Completed" || search == "Pending" || search == "Query" ||
                search == "Received" || search == "UnAllocated" || search == "etd2" || search == "etd5" || search == "etd10")
            {
                if (search == "etd2")
                {
                    var twoDaysAgo = DateTime.UtcNow.AddDays(2);
                    query = query.Where(x => x.ETD != null && x.ETD.Value.Date <= twoDaysAgo.Date && x.ETD.Value.Date > DateTime.UtcNow.Date && x.Status != "Completed");
                }
                else if (search == "etd5")
                {
                    var tenDaysAgo = DateTime.UtcNow.AddDays(10);
                    var fiveDaysAgo = DateTime.UtcNow.AddDays(5);
                    query = query.Where(x => x.ETD != null && x.ETD.Value.Date > fiveDaysAgo.Date && x.ETD.Value.Date <= tenDaysAgo.Date && x.Status != "Completed");
                }
                else if (search == "etd10")
                {
                    var tenDaysAgo = DateTime.UtcNow.AddDays(10);
                    query = query.Where(x => x.ETD != null && x.ETD.Value.Date > tenDaysAgo.Date && x.Status != "Completed");
                }

                else if (search == "Pending")
                {
                    query = query.Where(x => x.Status != "Completed" && x.Status != "Query" && x.Status != null && x.Status != "WIP");
                }
                else
                {
                    query = query.Where(x => x.Status == search);
                }
            }
            var finaldata = query.ToList();

            DataTable dt = ToDataTable(finaldata);

            using (XLWorkbook wb = new XLWorkbook())
            {
                dt.TableName = "Data";

                var wsFileData = wb.Worksheets.Add(dt);

                using (MemoryStream stream = new MemoryStream())
                {
                    wb.SaveAs(stream);
                    string excelname = $"FilteredData-{DateTime.UtcNow.ToString("ddmmyyyy hh:mm:ss")}.xlsx";
                    return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                }
            }

        }

        private DataTable ConvertToDataTable(IEnumerable<HBLDashModel> data)
        {
            DataTable dataTable = new DataTable();

            // Add columns to the DataTable
            dataTable.Columns.Add("Country Name", typeof(string));
            dataTable.Columns.Add("File Number", typeof(string));
            dataTable.Columns.Add("HBL Number", typeof(string));
            dataTable.Columns.Add("Container No", typeof(string));
            dataTable.Columns.Add("Booking No", typeof(string));
            dataTable.Columns.Add("ETD", typeof(DateTime));
            dataTable.Columns.Add("Customer Name", typeof(string));

            // Add rows to the DataTable
            foreach (var item in data)
            {
                dataTable.Rows.Add(
                    item.CountryName,
                    item.FileNumber,
                    item.HBLNumber,
                    item.ContainerNo,
                    item.BookingNo,
                    item.ETD,
                    item.CustomerName
                );
            }

            return dataTable;
        }


        //Get HBL's data Filter and sort record
        [HttpPost]
        public IActionResult GetHBLs(DataTableAjaxPostModel model, string country, string fileNumber)
        {
			_context.Database.SetCommandTimeout(300);
			var draw = model.draw;
            var sortColumn = string.IsNullOrEmpty(model.columns[model.order[0].column].data) ? "id" : model.columns[model.order[0].column].data;
            var sortColumnDirection = model.order[0].dir;
            var searchValue = model.search.value;
            int pageSize = model.length.HasValue ? model.length.Value : 100;
            int skip = model.start.HasValue ? model.start.Value : 0;

            if (fileNumber != null)
            {
                searchValue = "";
            }
            else if (country != null)
            {
                searchValue = "";
            }


            // Get the data for the DataTable
            var data = _context.HBLMaster.Include(x => x.File).ThenInclude(x => x.Country).AsQueryable();

            if (!string.IsNullOrEmpty(country) && country != "-- Select Country --")
            {
                data = data.Where(x => x.File.Country.CountryName.Contains(country));
            }
            if (!string.IsNullOrEmpty(fileNumber))
            {
                data = data.Where(x => x.HBLNumber.Contains(fileNumber));
            }

            IEnumerable<HBLUserViewModel> hbls = null;
            if (searchValue == "Completed")
            {
                var data1 = _context.HBLMaster
                                    .Include(fm => fm.File)
                                    .ThenInclude(fm => fm.Country)
                                    .Include(fm => fm.HBLActivityLogs)
                                    .ThenInclude(fa => fa.Status.Status == "Completed")
                                    .Select(fm => new HBLUserViewModel
                                    {
                                        Id = fm.Id,
                                        CountryName = fm.File.Country.CountryName,
                                        FileNo = fm.File.FileNumber,
                                        BookingNo = fm.Booking,
                                        hblNo = fm.HBLNumber
                                    })
                                    .ToList();

                hbls = data1;
            }
            else if (searchValue == "Pending")
            {

                var data1 = _context.HBLMaster
                                    .Include(fm => fm.File)
                                    .ThenInclude(fm => fm.Country)
                                    .Include(fm => fm.HBLActivityLogs)
                                    .ThenInclude(fa => fa.Status.Status == "Pending")
                                    .Select(fm => new HBLUserViewModel
                                    {
                                        Id = fm.Id,
                                        CountryName = fm.File.Country.CountryName,
                                        CustomerName = fm.CustomerName,
                                        FileNo = fm.File.FileNumber,
                                        BookingNo = fm.Booking,
                                        hblNo = fm.HBLNumber
                                    })
                                    .ToList();

                hbls = data1;
            }
            else if (searchValue == "Query")
            {
                //var data1 = (from fm in _context.FileMaster
                //             join fa in _context.FileActivityLog
                //             on fm.Id equals fa.FileId
                //             join am in _context.ActivityMaster
                //             on fa.ActivityId equals am.Id
                //             join sm in _context.StatusMaster
                //             on fa.StatusId equals sm.Id
                //             where (sm.Status=="Query")
                //             join um in _context.Users
                //             on fa.UserId equals um.Id
                //             select new FileDashModel
                //             {
                //                 Id = fm.Id,
                //                 CountryName = fm.Country.CountryName,
                //                 FileNumber = fm.FileNumber,
                //                 ETD = fm.Etd,
                //                 DraftCutOff = fm.DraftCutoff,
                //                 CountofHBL = fm.HBLMasters.Count()
                //             }).ToList();

                //files=data1;

            }
            else if (searchValue == "UnAllocated")
            {

                //var data1 = (from fm in _context.FileMaster
                //             where !(from fa in _context.FileActivityLog
                //                     where fm.Id == fa.FileId
                //                     select fa)
                //                    .Any()
                //             select new FileDashModel
                //             {
                //                 Id = fm.Id,
                //                 CountryName = fm.Country.CountryName,
                //                 FileNumber = fm.FileNumber,
                //                 ETD = fm.Etd,
                //                 DraftCutOff = fm.DraftCutoff,
                //                 CountofHBL = fm.HBLMasters.Count()
                //             }).ToList();

                //files=data1;
            }
            else if (searchValue == "etd2")
            {

                //var data1 = (from fm in _context.FileMaster
                //             join fa in _context.FileActivityLog
                //             on fm.Id equals fa.FileId
                //             join am in _context.ActivityMaster
                //             on fa.ActivityId equals am.Id
                //             join sm in _context.StatusMaster
                //             on fa.StatusId equals sm.Id
                //             where (sm.Status!="Completed")
                //             join um in _context.Users
                //             on fa.UserId equals um.Id
                //             select new FileDashModel
                //             {
                //                 Id = fm.Id,
                //                 CountryName = fm.Country.CountryName,
                //                 FileNumber = fm.FileNumber,
                //                 ETD = fm.Etd,
                //                 DraftCutOff = fm.DraftCutoff,
                //                 CountofHBL = fm.HBLMasters.Count()
                //             }).ToList();

                //files=data1.Where(x => x.ETD != null && Convert.ToDateTime(x.ETD).AddDays(-10) <= DateTime.Now);
            }
            else if (searchValue == "etd5")
            {

                //var data1 = (from fm in _context.FileMaster
                //             join fa in _context.FileActivityLog
                //             on fm.Id equals fa.FileId
                //             join am in _context.ActivityMaster
                //             on fa.ActivityId equals am.Id
                //             join sm in _context.StatusMaster
                //             on fa.StatusId equals sm.Id
                //             where (sm.Status!="Completed")
                //             join um in _context.Users
                //             on fa.UserId equals um.Id
                //             select new FileDashModel
                //             {
                //                 Id = fm.Id,
                //                 CountryName = fm.Country.CountryName,
                //                 FileNumber = fm.FileNumber,
                //                 ETD = fm.Etd,
                //                 DraftCutOff = fm.DraftCutoff,
                //                 CountofHBL = fm.HBLMasters.Count()
                //  /           }).ToList();


                //files=data1.Where(x => x.ETD.Value.AddDays(-10) > DateTime.Now && x.ETD.Value.AddDays(-12) <= DateTime.Now);
            }
            else if (searchValue == "etd10")
            {

                //var data1 = (from fm in _context.FileMaster
                //             join fa in _context.FileActivityLog
                //             on fm.Id equals fa.FileId
                //             join am in _context.ActivityMaster
                //             on fa.ActivityId equals am.Id
                //             join sm in _context.StatusMaster
                //             on fa.StatusId equals sm.Id
                //             where (sm.Status!="Completed")
                //             join um in _context.Users
                //             on fa.UserId equals um.Id
                //             select new FileDashModel
                //             {
                //                 Id = fm.Id,
                //                 CountryName = fm.Country.CountryName,
                //                 FileNumber = fm.FileNumber,
                //                 ETD = fm.Etd,
                //                 DraftCutOff = fm.DraftCutoff,
                //                 CountofHBL = fm.HBLMasters.Count()
                //             }).ToList();


                //files=data1.Where(x => x.ETD.Value.AddDays(-12) > DateTime.Now);
            }
            else
            {

                hbls = data.Select(
                    fm => new HBLUserViewModel
                    {
                        Id = fm.Id,
                        CountryName = fm.File.Country.CountryName,
                        CustomerName = fm.CustomerName,
                        FileNo = fm.File.FileNumber,
                        BookingNo = fm.Booking,
                        hblNo = fm.HBLNumber
                    })
                  .OrderBy(sortColumn + " " + sortColumnDirection)
                  .Skip(skip)
                  .Take(pageSize).AsQueryable().ToList();

            }

            // Return the data in the format required by DataTables
            return Json(new
            {
                draw = model.draw,
                recordsTotal = data.Count(),
                recordsFiltered = hbls.Count(),
                data = hbls
            });
        }

        //Get HBL's data Filter and sort record
        //     [HttpGet]
        //     public IActionResult GetHblData(string hblNumber, string activity, string user, string status)
        //     {
        //_context.Database.SetCommandTimeout(300);
        //var hbl = _context.HBLMaster.Where(x => x.Id == hblNumber).ToList();
        //         var hblNo = _context.HBLMaster.Where(x => x.Id == hblNumber).Select(x => x.HBLNumber).FirstOrDefault();

        //         var sm = _context.StatusMaster.ToList();

        //         var hBLActivities = _context.HBLActivityLog.Include(x => x.Activity).Include(x => x.Status).Include(x => x.ApplicationUser).Where(x => x.HBLId == hblNumber).ToList();

        //         var data = _context.HBLActivityLog.Select(x => new HBLDashModel
        //         {
        //             Id = x.Id,
        //             HBLNumber = x.Hbl.HBLNumber,
        //             Activity = x.Activity.NameOfActivity,
        //             Status = x.Status.Status,
        //             User = x.ApplicationUser.CitrixId,
        //             StartDate = x.StartDate,
        //             EndDate = x.EndDate,
        //             Comment = x.Comment == null ? "" : x.Comment,


        //         }).Where(x => x.HBLNumber == hblNo).ToList();

        //         IQueryable<HBLDashModel> hBLActivityLog = data.AsQueryable();

        //         if (!string.IsNullOrEmpty(activity) && activity != "none" && activity != "--Select--")
        //         {
        //             hBLActivityLog = hBLActivityLog.Where(x => x.Activity == activity.Trim());

        //         }
        //         if (!string.IsNullOrEmpty(user) && user != "none" && user != "--Select--")
        //         {
        //             hBLActivityLog = hBLActivityLog.Where(x => x.User == user.Trim());

        //         }
        //         if (!string.IsNullOrEmpty(status) && status != "none" && status != "--Select--")
        //         {
        //             hBLActivityLog = hBLActivityLog.Where(x => x.Status == status.Trim());

        //         }
        //         return Json(new { hBLActivityLog, hbl, sm });
        //     }

        [HttpGet]
        public IActionResult GetHblData(string hblNumber, string activity, string user, string status)
        {
            // Extend the command timeout
            _context.Database.SetCommandTimeout(300);

            // Fetch the HBLMaster data and HBLNumber
            var hbl = _context.HBLMaster.Where(x => x.Id == hblNumber).ToList();
            var hblNo = _context.HBLMaster.Where(x => x.Id == hblNumber).Select(x => x.HBLNumber).FirstOrDefault();

            // Fetch the StatusMaster data
            var sm = _context.StatusMaster.ToList();

            // Fetch HBLActivityLog data
            var hBLActivities = _context.HBLActivityLog
                                        .Include(x => x.Activity)
                                        .Include(x => x.Status)
                                        .Include(x => x.ApplicationUser)
                                        .Where(x => x.HBLId == hblNumber)
                                        .ToList();

            // Map the data to the HBLDashModel
            var data = _context.HBLActivityLog
                               .Select(x => new HBLDashModel
                               {
                                   Id = x.Id,
                                   HBLNumber = x.Hbl.HBLNumber,
                                   Activity = x.Activity.NameOfActivity,
                                   Status = x.Status.Status,
                                   User = x.ApplicationUser.CitrixId,
                                   StartDate = x.StartDate,
                                   EndDate = x.EndDate,
                                   Comment = x.Comment == null ? "" : x.Comment
                               })
                               .Where(x => x.HBLNumber == hblNo)
                               .ToList();

            // Convert to IQueryable to apply filtering
            IQueryable<HBLDashModel> hBLActivityLog = data.AsQueryable();

            // Filter by activity
            if (!string.IsNullOrEmpty(activity) && activity != "none" && activity != "--Select--")
            {
                hBLActivityLog = hBLActivityLog.Where(x => x.Activity == activity.Trim());
            }

            // Filter by user
            if (!string.IsNullOrEmpty(user) && user != "none" && user != "--Select--")
            {
                hBLActivityLog = hBLActivityLog.Where(x => x.User == user.Trim());
            }

            // Filter by status
            if (!string.IsNullOrEmpty(status) && status != "none" && status != "--Select--")
            {
                hBLActivityLog = hBLActivityLog.Where(x => x.Status == status.Trim());
            }

            // Remove duplicates by selecting the most recent record for each HBLNumber
            var uniqueHBLActivityLog = hBLActivityLog
                                        .GroupBy(x => x.HBLNumber)      // Group by HBLNumber
                                        .Select(g => g.OrderByDescending(x => x.EndDate).First())  // Select the most recent entry by EndDate
                                        .ToList();

            // Return the filtered, non-duplicate records
            return Json(new { hBLActivityLog = uniqueHBLActivityLog, hbl, sm });
        }

        //Get HBL's activity data
        //     [HttpGet]
        //     public IActionResult GetHblActivityData(string hblnumber)
        //     {
        //_context.Database.SetCommandTimeout(300);
        //var hblact = _context.HBLActivityLog.Include(x => x.Hbl).Include(x => x.Activity).Include(x => x.Status).Where(x => x.Hbl.HBLNumber == hblnumber).ToList();
        //         IQueryable<HBLActivityLog> hblActivityLog = hblact.AsQueryable();
        //         foreach (var item in hblact)
        //         {
        //             hblActivityLog.Select(x => new HBLActivityLog
        //             {
        //                 ActivityId = _context.HBLActivityLog.Where(x => x.Activity.Id == item.ActivityId).Select(x => x.Activity.NameOfActivity).FirstOrDefault(),
        //                 StatusId = _context.HBLActivityLog.Where(x => x.Status.Id == item.StatusId).Select(x => x.Status.Status).FirstOrDefault(),
        //                 UserId = _context.HBLActivityLog.Where(x => x.ApplicationUser.Id == item.UserId).Select(x => x.ApplicationUser.UserName).FirstOrDefault(),

        //             }).ToList();
        //         }
        //         return Json(hblact);
        //     }

        [HttpGet]
        public IActionResult GetHblActivityData(string hblnumber)
        {
            // Increase timeout in case of long-running queries
            _context.Database.SetCommandTimeout(300);

            // Fetch all HBLActivityLog records for the given HBL number
            var uniqueHblAct = _context.HBLActivityLog
                                .Include(x => x.Hbl)
                                .Include(x => x.Activity)
                                .Include(x => x.Status)
                                .Include(x => x.ApplicationUser)
                                .Where(x => x.Hbl.HBLNumber == hblnumber)
                                .ToList();

            // Group records by ActivityId, StatusId, and UserId to avoid duplicates
            var hblact = uniqueHblAct
                                .GroupBy(x => new { x.ActivityId, x.StatusId, x.UserId })
                                .Select(g => g.OrderByDescending(x => x.EndDate).FirstOrDefault()) // Select the most recent record
                                .ToList();

            // Create IQueryable from the filtered data
            IQueryable<HBLActivityLog> hblActivityLog = hblact.AsQueryable();

            // Map each item with the necessary properties
            foreach (var item in hblact)
            {
                hblActivityLog.Select(x => new
                {
                    ActivityName = _context.HBLActivityLog.Where(x => x.Activity.Id == item.ActivityId)
                                                          .Select(x => x.Activity.NameOfActivity)
                                                          .FirstOrDefault(),
                    Status = _context.HBLActivityLog.Where(x => x.Status.Id == item.StatusId)
                                                    .Select(x => x.Status.Status)
                                                    .FirstOrDefault(),
                    UserName = _context.HBLActivityLog.Where(x => x.ApplicationUser.Id == item.UserId)
                                                      .Select(x => x.ApplicationUser.UserName)
                                                      .FirstOrDefault(),
                    // Optionally, return other fields like StartDate, EndDate, etc.
                    StartDate = item.StartDate,
                    EndDate = item.EndDate
                }).ToList();
            }

            return Json(hblact); // Return only unique records
        }


        //     public JsonResult GetDashboardCount(string activity, string user, string status, string hblnumber, string container, string etd, string bookingno, string fileno, string search)
        //     {
        ////var hBLActivityLog = _context.HBLActivityLog.Include(x => x.Hbl.File).Include(x => x.Status).Include(x => x.ApplicationUser).ToList();
        //_context.Database.SetCommandTimeout(300);

        //         //var threeMonthsAgo = DateTime.Now.AddMonths(-3);
        //         var threeMonthsAgo = DateTime.Now.AddDays(15);
        //         ////_context.Database.SetCommandTimeout(300);
        //         //List<HBLMaster> hBLDashModel = new List<HBLMaster>();
        //         //hBLDashModel = _context.HBLMaster
        //         //    .Include(x => x.File)
        //         //    .ThenInclude(x => x.Country)
        //         //    .Include(x => x.HBLActivityLogs).ThenInclude(x => x.Status).Include(x => x.HBLActivityLogs).ThenInclude(x => x.Activity).Include(x => x.HBLActivityLogs).ThenInclude(x => x.ApplicationUser)
        //         //    .Where(x => x.EnterDate >= threeMonthsAgo).ToList();  // Filter data for the last three months
        //         //var query = hBLDashModel.Select(x => new HBLDashModel
        //         //{
        //         //    Id = x.Id,
        //         //    CountryName = x.File.Country.CountryName,
        //         //    HBLNumber = x.HBLNumber,
        //         //    ContainerNo = x.Container,
        //         //    BookingNo = x.Booking,
        //         //    CustomerName = x.CustomerName,
        //         //    User = x.HBLActivityLogs.Where(y => y.HBLId == x.Id).Select(y => y.ApplicationUser.UserName).FirstOrDefault(),
        //         //    Status = x.HBLActivityLogs.Where(y => y.HBLId == x.Id).Select(y => y.Status.Status).FirstOrDefault(),
        //         //    Activity = x.HBLActivityLogs.Where(y => y.HBLId == x.Id).Select(y => y.Activity.NameOfActivity).FirstOrDefault(),
        //         //    ReceivedDate = x.EnterDate,
        //         //    ETD = x.File.Etd,
        //         //    FileNumber = x.File.FileNumber
        //         //}).AsQueryable();

        //         //IQueryable<HBLDashModel> SortedData = query.AsQueryable();

        //         ////DashboardProdcount dp = new DashboardProdcount
        //         ////{
        //         ////    Received = SortedData.Count(),
        //         ////    Pending = hBLActivityLog.Where(x => x.Status.Status == "Pending").Count() + hBLActivityLog.Where(x => x.Status.Status == "Followup1").Count() + hBLActivityLog.Where(x => x.Status.Status == "Followup2").Count() + hBLActivityLog.Where(x => x.Status.Status == "Followup3").Count(),
        //         ////    WIP = hBLActivityLog.Where(x => x.Status.Status == "WIP").Count(),
        //         ////    Query = hBLActivityLog.Where(x => x.Status.Status == "Query").Count(),
        //         ////    Completed = hBLActivityLog.Where(x => x.Status.Status == "Completed").Count(),
        //         ////    UnAllocated = hBLActivityLog.Where(x => x.StatusId == null && x.UserId == null).Count(),
        //         ////    etd2 = SortedData.Where(x => x.ETD.Value.AddDays(2) <= DateTime.UtcNow && (x.Status != "Completed")).Count(),
        //         ////    etd5 = SortedData.Where(x => x.ETD.Value.AddDays(5) > DateTime.UtcNow && x.ETD.Value.AddDays(2) <= DateTime.UtcNow && (x.Status == null || x.Status != "Completed")).Count(),
        //         ////    etd10 = SortedData.Where(x => x.ETD.Value.AddDays(10) > DateTime.UtcNow && (x.Status != "Completed")).Count(),

        //         ////};
        //         //DashboardProdcount dp = new DashboardProdcount
        //         //{
        //         //    Received = SortedData.Count(),
        //         //    Pending = SortedData.Where(x => x.Status == "Pending").Count() + SortedData.Where(x => x.Status == "Followup1").Count() + SortedData.Where(x => x.Status == "Followup2").Count() + SortedData.Where(x => x.Status == "Followup3").Count(),
        //         //    WIP = SortedData.Where(x => x.Status == "WIP").Count(),
        //         //    Query = SortedData.Where(x => x.Status == "Query").Count(),
        //         //    Completed = SortedData.Where(x => x.Status == "Completed").Count(),
        //         //    UnAllocated = SortedData.Where(x => x.Status == null && x.User == null).Count(),
        //         //    etd2 = SortedData.Where(x => x.ETD.Value.AddDays(2) <= DateTime.UtcNow && (x.Status != "Completed")).Count(),
        //         //    etd5 = SortedData.Where(x => x.ETD.Value.AddDays(5) > DateTime.UtcNow && x.ETD.Value.AddDays(2) <= DateTime.UtcNow && (x.Status == null || x.Status != "Completed")).Count(),
        //         //    etd10 = SortedData.Where(x => x.ETD.Value.AddDays(10) > DateTime.UtcNow && (x.Status != "Completed")).Count(),

        //         //};

        //         //List<HBLMaster> hBLDashModel = new List<HBLMaster>();
        //         //hBLDashModel = _context.HBLMaster
        //         //    .Include(x => x.File)
        //         //    .ThenInclude(x => x.Country)
        //         //    .Include(x => x.HBLActivityLogs).ThenInclude(x => x.Status).Include(x => x.HBLActivityLogs).ThenInclude(x => x.Activity).Include(x => x.HBLActivityLogs).ThenInclude(x => x.ApplicationUser)
        //         //    .Where(x => x.File.Etd >= threeMonthsAgo).ToList();  // Filter data for the last three months
        //         //var query = hBLDashModel.Select(x => new HBLDashModel
        //         //{
        //         //    Id = x.Id,
        //         //    CountryName = x.File.Country.CountryName,
        //         //    HBLNumber = x.HBLNumber,
        //         //    ContainerNo = x.Container,
        //         //    BookingNo = x.Booking,
        //         //    CustomerName = x.CustomerName,
        //         //    User = x.HBLActivityLogs.Where(y => y.HBLId == x.Id).Select(y => y.ApplicationUser.UserName).FirstOrDefault(),
        //         //    Status = x.HBLActivityLogs.Where(y => y.HBLId == x.Id).Select(y => y.Status.Status).FirstOrDefault(),
        //         //    Activity = x.HBLActivityLogs.Where(y => y.HBLId == x.Id).Select(y => y.Activity.NameOfActivity).FirstOrDefault(),
        //         //    ReceivedDate = x.EnterDate,
        //         //    ETD = x.File.Etd,
        //         //    FileNumber = x.File.FileNumber
        //         //}).AsQueryable();

        //         var query = _context.HBLMaster
        //                     .Where(x => x.File.Etd >= threeMonthsAgo)
        //                     .Include(x => x.File)
        //                         .ThenInclude(file => file.Country)
        //                     .Include(x => x.HBLActivityLogs)
        //                         .ThenInclude(log => log.Status)
        //                     .Include(x => x.HBLActivityLogs)
        //                         .ThenInclude(log => log.Activity)
        //                     .Include(x => x.HBLActivityLogs)
        //                         .ThenInclude(log => log.ApplicationUser)
        //                     .Select(x => new HBLDashModel
        //                     {
        //                         Id = x.Id,
        //                         CountryName = x.File.Country.CountryName,
        //                         HBLNumber = x.HBLNumber,
        //                         ContainerNo = x.Container,
        //                         BookingNo = x.Booking,
        //                         CustomerName = x.CustomerName,
        //                         User = x.HBLActivityLogs
        //                             .OrderByDescending(x => x.ActivityId) // Assuming logs have a LogDate to get the latest one
        //                             .Select(x => x.ApplicationUser.UserName)
        //                             .FirstOrDefault(),
        //                         Status = x.HBLActivityLogs
        //                             .OrderByDescending(x => x.ActivityId) // Assuming logs have a LogDate to get the latest one
        //                             .Select(x => x.Status.Status)
        //                             .FirstOrDefault(),
        //                         Activity = x.HBLActivityLogs
        //                             .OrderByDescending(x => x.ActivityId) // Assuming logs have a LogDate to get the latest one
        //                             .Select(x => x.Activity.NameOfActivity)
        //                             .FirstOrDefault(),
        //                         ReceivedDate = x.EnterDate,
        //                         ETD = x.File.Etd,
        //                         FileNumber = x.File.FileNumber
        //                     }).ToList();



        //         IQueryable<HBLDashModel> SortedData = query.AsQueryable();
        //             if (!string.IsNullOrEmpty(activity) && activity != "none" && activity != "--Select--")
        //             {
        //                 SortedData = SortedData.Where(x => x.Activity == activity.Trim()).AsQueryable();
        //             }
        //             if (!string.IsNullOrEmpty(user) && user != "none" && user != "--Select--")
        //             {
        //                 SortedData = SortedData.Where(x => x.User == user.Trim()).AsQueryable();
        //             }
        //             if (!string.IsNullOrEmpty(status) && status != "none" && status != "--Select--")
        //             {
        //                 SortedData = SortedData.Where(x => x.Status == status.Trim()).AsQueryable();
        //             }
        //             if (!string.IsNullOrEmpty(hblnumber) && hblnumber != "none")
        //             {
        //                 SortedData = SortedData.Where(x => x.HBLNumber.Contains(hblnumber.Trim())).AsQueryable();
        //             }
        //             if (!string.IsNullOrEmpty(container) && container != "none")
        //             {
        //                 SortedData = SortedData.Where(x => x.ContainerNo.Contains(container.Trim())).AsQueryable();
        //             }
        //             if (!string.IsNullOrEmpty(bookingno) && bookingno != "none")
        //             {
        //                 //string escapeCharacter = "%";
        //                 //string searchPattern = $"%{bookingno.Trim().Replace("%", escapeCharacter)}%";
        //                 //query = query.Where(x => EF.Functions.Like(x.BookingNo, searchPattern, escapeCharacter));
        //                 SortedData = SortedData.Where(x => x.BookingNo.Contains(bookingno.Trim())).AsQueryable();

        //             }
        //             if (!string.IsNullOrEmpty(fileno) && fileno != "none")
        //             {
        //                 SortedData = SortedData.Where(x => x.FileNumber.Contains(fileno.Trim())).AsQueryable();
        //             }
        //             if (!string.IsNullOrEmpty(etd) && etd != "none")
        //             {
        //                 var etdDate = Convert.ToDateTime(etd.Trim());
        //                 SortedData = SortedData.Where(x => x.ETD != null && x.ETD.Value.Date == etdDate.Date).AsQueryable();
        //             }
        //             var twoDaysAgo = DateTime.UtcNow.AddDays(2);
        //             var fiveDaysAgo = DateTime.UtcNow.AddDays(5);
        //             var tenDaysAgo = DateTime.UtcNow.AddDays(10);
        //         //var tenDaysAgo = DateTime.UtcNow.AddDays(10);

        //         DashboardProdcount dp = new DashboardProdcount
        //         {
        //             Received = SortedData.Count(),
        //             Pending = SortedData.Count(x => x.Status == "Pending" || x.Status == "Followup1" || x.Status == "Followup2" || x.Status == "Followup3"),
        //             WIP = SortedData.Count(x => x.Status == "WIP"),
        //             Query = SortedData.Count(x => x.Status == "Query"),
        //             Completed = SortedData.Count(x => x.Status == "Completed"),
        //             UnAllocated = SortedData.Count(x => x.Status == null && x.User == null),
        //             etd2 = SortedData.Count(x => x.ETD != null && x.ETD.Value.Date <= twoDaysAgo.Date && x.ETD.Value.Date > DateTime.UtcNow.Date && x.Status != "Completed"),
        //             etd5 = SortedData.Count(x => x.ETD != null && x.ETD.Value.Date > fiveDaysAgo.Date && x.ETD.Value.Date <= tenDaysAgo.Date && x.Status != "Completed"),
        //             etd10 = SortedData.Count(x => x.ETD != null && x.ETD.Value.Date > tenDaysAgo.Date && x.Status != "Completed")

        //         };

        //         return Json(dp);
        //     }

        public ActionResult Report()
        {

            return View();
        }
        //Generate report file and download sheets
        public ActionResult GetReport(string reporttype, DateTime startDate, DateTime endDate)
        {
			_context.Database.SetCommandTimeout(300);
			List<ReportTemplateModel> HBLdata = new List<ReportTemplateModel>();
            List<FileDashModel> data = new List<FileDashModel>();
            List<QuotationViewModel> Quote = new List<QuotationViewModel>();
            List<ChatsViewModel> chats = new List<ChatsViewModel>();
            List<HBLDashModel> Allocation = new List<HBLDashModel>();
            if (reporttype == "Production Report")
            {
                if (startDate.ToShortDateString() != "1/1/0001" && endDate.ToShortDateString() != "1/1/0001")
                {
                    //data = (from fa in _context.HBLActivityLog
                    //        where (fa.StartDate >= Convert.ToDateTime(startDate) && fa.StartDate <= Convert.ToDateTime(endDate))
                    //        join hm in _context.HBLMaster
                    //         on fa.HBLId equals hm.Id
                    //        join fm in _context.FileMaster
                    //        on hm.FileId equals fm.Id
                    //        join am in _context.ActivityMaster
                    //        on fa.ActivityId equals am.Id
                    //        join um in _context.Users
                    //        on fa.UserId equals um.Id
                    //        select new FileDashModel
                    //        {
                    //            CountryName = fm.Country.CountryName,
                    //            DraftCutOff = fm.DraftCutoff,
                    //            ETD = fm.Etd,
                    //            FileNumber = fm.FileNumber,
                    //            ActivityId = am.NameOfActivity,
                    //            StatusId = fa.Status.Status,
                    //            Comment = fa.Comment,
                    //            UserId = um.UserName
                    //        }).ToList();report

                    //HBLdata = (from ha in _context.HBLActivityLog
                    //           where (ha.StartDate >= Convert.ToDateTime(startDate) && ha.StartDate <= Convert.ToDateTime(endDate))
                    //           join hm in _context.HBLMaster
                    //           on ha.HBLId equals hm.Id
                    //           join fa in _context.FileMaster
                    //           on hm.FileId equals fa.Id

                    //           join am in _context.ActivityMaster
                    //           on ha.ActivityId equals am.Id
                    //           join um in _context.Users
                    //           on ha.UserId equals um.Id
                    //           select new ReportTemplateModel
                    //           {
                    //               OfficeName = fa.Country.CountryName,
                    //               FileNumber = fa.FileNumber,
                    //               Container = hm.Container,
                    //               BookingNo = hm.Booking,
                    //               ETD = fa.Etd,
                    //               HBL_No = hm.HBLNumber,
                    //               ActivityId = am.NameOfActivity,
                    //               StatusId = ha.Status.Status,
                    //               Comment = ha.Comment,
                    //               UserId = um.UserName,
                    //               EnterDate = hm.EnterDate,
                    //               StartDate = ha.StartDate,
                    //               EndDate = ha.EndDate,
                    //               AES_UN = ha.AES_UN,
                    //               QUOTE_NUMBER = ha.QUOTE_NUMBER,
                    //               MblNumber = ha.MblNumber
                    //           }).ToList();

                    //var hBLActivityLogs = _context.HBLActivityLog.Include(x => x.Hbl).Include(x => x.Status).Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Hbl.File).Include(x => x.Hbl.File.Country).ToList();
                    //var statusId = _context.StatusMaster.Where(x => x.Status == "WIP").Select(x => x.Id).FirstOrDefault();

                    //hBLActivityLogs = hBLActivityLogs.Where(x => (x.EndDate != null && x.EndDate.Value.Date >= startDate.Date && x.EndDate.Value.Date <= endDate.Date) || (x.StartDate != null && x.StatusId == statusId && x.StartDate.Value.Date >= startDate.Date && x.StartDate.Value.Date <= endDate.Date) || x.StatusId == statusId).ToList();
                    //data = hBLActivityLogs.Select(x => new FileDashModel
                    //{
                    //    CountryName = x.Hbl.File.Country.CountryName,
                    //    DraftCutOff = x.Hbl.File.DraftCutoff,
                    //    ETD = x.Hbl.File.Etd,
                    //    FileNumber = x.Hbl.File.FileNumber,
                    //    ActivityId = x.Activity.NameOfActivity,
                    //    StatusId = x.Status.Status,
                    //    Comment = x.Comment,
                    //    UserId = x.ApplicationUser.UserName,
                    //    EnterDate = x.Hbl.File.EnterDate,
                    //    CountofHBL = _context.HBLMaster.Where(y => y.FileId == x.Hbl.FileId).Count(),
                    //}).ToList();

                    //HBLdata = hBLActivityLogs.Select(x => new ReportTemplateModel
                    //{
                    //    OfficeName = x.Hbl.File.Country.CountryName,
                    //    FileNumber = x.Hbl.File.FileNumber,
                    //    Container = x.Hbl.Container,
                    //    BookingNo = x.Hbl.Booking,
                    //    ETD = x.Hbl.File.Etd,
                    //    HBL_No = x.Hbl.HBLNumber,
                    //    ActivityId = x.Activity.NameOfActivity,
                    //    StatusId = x.Status.Status,
                    //    Comment = x.Comment,
                    //    UserId = x.ApplicationUser.UserName,
                    //    EnterDate = x.Hbl.EnterDate,
                    //    StartDate = x.StartDate,
                    //    EndDate = x.EndDate,
                    //    AES_UN = x.AES_UN,
                    //    QUOTE_NUMBER = x.QUOTE_NUMBER,
                    //    MblNumber = x.MblNumber
                    //}).ToList();

                    //DataTable filedata = ToDataTable(data);
                    //DataTable hbldata = ToDataTable(HBLdata);

                    //string filename = "";
                    //string apath = filename + ".xlsx";
                    //using (XLWorkbook wb = new XLWorkbook())
                    //{
                    //    filedata.TableName = "File Data";
                    //    hbldata.TableName = "HBL Data";
                    //    var wsFileData = wb.Worksheets.Add(filedata);
                    //    var wsHblData = wb.Worksheets.Add(hbldata);

                    //    wsFileData.Columns().AdjustToContents();
                    //    wsHblData.Columns().AdjustToContents();
                    //    try
                    //    {
                    //        using (MemoryStream stream = new MemoryStream())
                    //        {
                    //            wb.SaveAs(stream);
                    //            string excelname = $"ProductionReport-{DateTime.Now.ToString("ddMMyyyy hh_mm_ss")}.xlsx";
                    //            return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                    //        }
                    //    }
                    //    catch (Exception ex)
                    //    {

                    //    }
                    //}

                    // Get statusId once
                    // _context.Database.SetCommandTimeout(300);

                    //// Get statusId once
                    //var statusId = _context.StatusMaster
                    //						.Where(x => x.Status == "WIP")
                    //						.Select(x => x.Id)
                    //						.FirstOrDefault();

                    //// Retrieve HBLActivityLogs with necessary includes and filtering
                    //var hblActivityLogs = _context.HBLActivityLog
                    //						.Include(x => x.Hbl)
                    //						.Include(x => x.Hbl.File)
                    //						.Include(x => x.Hbl.File.Country)
                    //						.Include(x => x.Status)
                    //						.Include(x => x.Activity)
                    //						.Include(x => x.ApplicationUser)
                    //						.Where(x => (x.EndDate != null && x.EndDate.Value.Date >= startDate.Date && x.EndDate.Value.Date <= endDate.Date) ||
                    //									(x.StartDate != null && x.StatusId == statusId && x.StartDate.Value.Date >= startDate.Date && x.StartDate.Value.Date <= endDate.Date) ||
                    //									x.StatusId == statusId).ToList();

                    //// Prepare data for FileDashModel and ReportTemplateModel in a single query to avoid multiple database hits
                    ////hblActivityLogs = hblActivityLogs.Where(x => (x.EndDate != null && x.EndDate.Value.Date >= startDate.Date && x.EndDate.Value.Date <= endDate.Date) || (x.StartDate != null && x.StatusId == statusId && x.StartDate.Value.Date >= startDate.Date && x.StartDate.Value.Date <= endDate.Date) || x.StatusId == statusId).ToList();
                    //              data = hblActivityLogs.Select(x => new FileDashModel
                    //               {
                    //                   CountryName = x.Hbl.File.Country.CountryName,
                    //                   DraftCutOff = x.Hbl.File.DraftCutoff,
                    //                   ETD = x.Hbl.File.Etd,
                    //                   FileNumber = x.Hbl.File.FileNumber,
                    //                   ActivityId = x.Activity.NameOfActivity,
                    //                   StatusId = x.Status.Status,
                    //                   Comment = x.Comment,
                    //                   UserId = x.ApplicationUser.UserName,
                    //                   EnterDate = x.Hbl.File.EnterDate,
                    //                   CountofHBL = _context.HBLMaster.Where(y => y.FileId == x.Hbl.FileId).Count(),
                    //               }).ToList();

                    //               HBLdata = hblActivityLogs.Select(x => new ReportTemplateModel
                    //               {
                    //                   OfficeName = x.Hbl.File.Country.CountryName,
                    //                   FileNumber = x.Hbl.File.FileNumber,
                    //                   Container = x.Hbl.Container,
                    //                   BookingNo = x.Hbl.Booking,
                    //                   ETD = x.Hbl.File.Etd,
                    //                   HBL_No = x.Hbl.HBLNumber,
                    //                   ActivityId = x.Activity.NameOfActivity,
                    //                   StatusId = x.Status.Status,
                    //                   Comment = x.Comment,
                    //                   UserId = x.ApplicationUser.UserName,
                    //                   EnterDate = x.Hbl.EnterDate,
                    //                   StartDate = x.StartDate,
                    //                   EndDate = x.EndDate,
                    //                   AES_UN = x.AES_UN,
                    //                   QUOTE_NUMBER = x.QUOTE_NUMBER,
                    //                   MblNumber = x.MblNumber
                    //               }).ToList();

                    //               // Convert lists to DataTables
                    //               DataTable filedata = ToDataTable(data);
                    //DataTable hbldata = ToDataTable(HBLdata);

                    //// Export to Excel
                    //string filename = $"ProductionReport-{DateTime.Now:ddMMyyyy hh_mm_ss}.xlsx";
                    //using (XLWorkbook wb = new XLWorkbook())
                    //{
                    //	filedata.TableName = "File Data";
                    //	hbldata.TableName = "HBL Data";
                    //	var wsFileData = wb.Worksheets.Add(filedata);
                    //	var wsHblData = wb.Worksheets.Add(hbldata);

                    //	//wsFileData.Columns().AdjustToContents();
                    //	//wsHblData.Columns().AdjustToContents();

                    //	try
                    //	{
                    //		using (MemoryStream stream = new MemoryStream())
                    //		{
                    //			wb.SaveAs(stream);
                    //			return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", filename);
                    //		}
                    //	}
                    //	catch (Exception ex)
                    //	{
                    //		// Handle exception (consider logging it)
                    //	}
                    //}

                     _context.Database.SetCommandTimeout(300);

                    // Get statusId once
                    var statusId = _context.StatusMaster
                                            .Where(x => x.Status == "WIP")
                                            .Select(x => x.Id)
                                            .FirstOrDefault();

                    // Retrieve HBLActivityLogs with necessary includes and filtering in one query
                    var hblActivityLogs = _context.HBLActivityLog.Where(x =>
                                                (x.EndDate != null && x.EndDate.Value.Date >= startDate.Date && x.EndDate.Value.Date <= endDate.Date) ||
                                                (x.StartDate != null && x.StatusId == statusId && x.StartDate.Value.Date >= startDate.Date && x.StartDate.Value.Date <= endDate.Date) ||
                                                x.StatusId == statusId)
                                            .Include(x => x.Hbl)
                                            .ThenInclude(h => h.File)
                                            .ThenInclude(f => f.Country)
                                            .Include(x => x.Status)
                                            .Include(x => x.Activity)
                                            .Include(x => x.ApplicationUser)
                                            .ToList();

                    var distinctFileIds = hblActivityLogs.Select(x => x.Hbl.FileId).Distinct();

                    // Get the count of HBLs for each file using a join and grouping
                    var fileHBLCounts = _context.HBLMaster
                        .Where(h => distinctFileIds.Contains(h.FileId))
                        .GroupBy(h => h.FileId)
                        .Select(g => new { FileId = g.Key, Count = g.Count() })
                        .ToDictionary(x => x.FileId, x => x.Count);

                    // Prepare data for FileDashModel and ReportTemplateModel in a single query to avoid multiple database hits
                    data = hblActivityLogs.Select(x => new FileDashModel
                    {
                        CountryName = x.Hbl.File.Country.CountryName,
                        DraftCutOff = x.Hbl.File.DraftCutoff,
                        ETD = x.Hbl.File.Etd,
                        FileNumber = x.Hbl.File.FileNumber,
                        ActivityId = x.Activity.NameOfActivity,
                        StatusId = x.Status.Status,
                        Comment = x.Comment,
                        UserId = x.ApplicationUser.UserName,
                        EnterDate = x.Hbl.File.EnterDate,
                        CountofHBL = fileHBLCounts.ContainsKey(x.Hbl.FileId) ? fileHBLCounts[x.Hbl.FileId] : 0,
                        DocReceivedDate = x.DocReceivedDate == null ? (DateTime?) null : x.DocReceivedDate.Value.Date
                    }).ToList();

                    HBLdata = hblActivityLogs.Select(x => new ReportTemplateModel
                    {
                        OfficeName = x.Hbl.File.Country.CountryName,
                        FileNumber = x.Hbl.File.FileNumber,
                        Container = x.Hbl.Container,
                        BookingNo = x.Hbl.Booking,
                        ETD = x.Hbl.File.Etd,
                        HBL_No = x.Hbl.HBLNumber,
                        ActivityId = x.Activity.NameOfActivity,
                        StatusId = x.Status.Status,
                        Comment = x.Comment,
                        UserId = x.ApplicationUser.UserName,
                        EnterDate = x.Hbl.EnterDate,
                        StartDate = x.StartDate,
                        EndDate = x.EndDate,
                        AES_UN = x.AES_UN,
                        QUOTE_NUMBER = x.QUOTE_NUMBER,
                        MblNumber = x.MblNumber,
                        DocReceivedDate = x.DocReceivedDate == null ? (DateTime?)null : x.DocReceivedDate.Value.Date
                    }).ToList();

                    // Convert lists to DataTables
                    DataTable filedata = ToDataTable(data);
                    DataTable hbldata = ToDataTable(HBLdata);

                    // Export to Excel
                    string filename = $"ProductionReport-{DateTime.Now:ddMMyyyy hh_mm_ss}.xlsx";
                    using (XLWorkbook wb = new XLWorkbook())
                    {
                        filedata.TableName = "File Data";
                        hbldata.TableName = "HBL Data";
                        var wsFileData = wb.Worksheets.Add(filedata);
                        var wsHblData = wb.Worksheets.Add(hbldata);

                        // Uncomment these lines if column adjustment is needed
                        // wsFileData.Columns().AdjustToContents();
                        // wsHblData.Columns().AdjustToContents();

                        try
                        {
                            using (MemoryStream stream = new MemoryStream())
                            {
                                wb.SaveAs(stream);
                                return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", filename);
                            }
                        }
                        catch (Exception ex)
                        {
                            // Handle exception (consider logging it)
                            throw new Exception("An error occurred while generating the report.", ex);
                        }
                    }
                }
            }
            else if (reporttype == "Quotation Report")
            {
                if (startDate.ToShortDateString() != "1/1/0001" && endDate.ToShortDateString() != "1/1/0001")
                {
                    Quote = (from fa in _context.QutationMaster
                             where (fa.enddate != null && fa.enddate.Value.Date >= startDate.Date && fa.enddate.Value.Date <= endDate.Date)
                             join um in _context.Users
                             on fa.UserId equals um.Id
                             join om in _context.CountryMaster
                             on fa.BookingOffice equals om.Id
                             select new QuotationViewModel
                             {
                                 QuoteNumber = fa.QuoteNumber,
                                 ContainerType = fa.ContainerType,
                                 BookingOffice = om.CountryName,
                                 QuoteDate = fa.QuoteDate,
                                 DoorPort = fa.DoorPort,
                                 UserId = um.UserName,
                                 startDate = fa.startDate,
                                 enddate = fa.enddate

                             }).ToList();
                }

                DataTable quotedata = ToDataTable(Quote);

                string filename = "";
                string apath = filename + ".xlsx";
                using (XLWorkbook wb = new XLWorkbook())
                {
                    quotedata.TableName = "Quotation Data";
                    var wsQuoteData = wb.Worksheets.Add(quotedata);

                    wsQuoteData.Columns().AdjustToContents();
                    try
                    {
                        using (MemoryStream stream = new MemoryStream())
                        {
                            wb.SaveAs(stream);
                            string excelname = $"QuotationReport-{DateTime.Now.ToString("ddMMyyyy hh_mm_ss")}.xlsx";
                            return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                        }
                    }
                    catch (Exception ex)
                    {

                    }
                }
            }
            else if (reporttype == "Allocation Report")
            {
                if (startDate.ToShortDateString() != "1/1/0001" && endDate.ToShortDateString() != "1/1/0001")
                {
                    //Allocation = _context.HBLMaster
                    //.Include(x => x.HBLActivityLogs)
                    //.Include(x => x.File)
                    //.ThenInclude(x => x.Country)
                    //.Where(x => x.EnterDate != null && x.EnterDate.Date >= startDate.Date && x.EnterDate.Date <= endDate.Date)// Filter data for the last three months
                    //.Select(x => new HBLDashModel
                    //{
                    //    Id = x.Id,
                    //    CountryName = x.File.Country.CountryName,
                    //    HBLNumber = x.HBLNumber,
                    //    ContainerNo = x.Container,
                    //    BookingNo = x.Booking,
                    //    CustomerName = x.CustomerName,
                    //    User = x.HBLActivityLogs.Where(y => y.HBLId == x.Id).Select(y => y.ApplicationUser.UserName).FirstOrDefault(),
                    //    Status = x.HBLActivityLogs.Where(y => y.HBLId == x.Id).Select(y => y.Status.Status).FirstOrDefault(),
                    //    Activity = x.HBLActivityLogs.Where(y => y.HBLId == x.Id).Select(y => y.Activity.NameOfActivity).FirstOrDefault(),
                    //    ReceivedDate = x.EnterDate,
                    //    ETD = x.File.Etd,
                    //    FileNumber = x.File.FileNumber,
                    //    StartDate = x.HBLActivityLogs.Where(y => y.HBLId == x.Id).FirstOrDefault().StartDate,
                    //    EndDate = x.HBLActivityLogs.Where(y => y.HBLId == x.Id).FirstOrDefault().EndDate

                    //}).ToList();

                    //DataTable Allocationdata = ToDataTable(Allocation);

                    //string filename = "";
                    //string apath = filename + ".xlsx";
                    //using (XLWorkbook wb = new XLWorkbook())
                    //{
                    //    Allocationdata.TableName = "Allocation Data";
                    //    var wsAllocationData = wb.Worksheets.Add(Allocationdata);

                    //    //wsAllocationData.Columns().AdjustToContents();
                    //    try
                    //    {
                    //        using (MemoryStream stream = new MemoryStream())
                    //        {
                    //            wb.SaveAs(stream);
                    //            string excelname = $"AllocationReport-{DateTime.Now.ToString("ddMMyyyy hh_mm_ss")}.xlsx";
                    //            return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                    //        }
                    //    }
                    //    catch (Exception ex)
                    //    {

                    //    }
                    //}

                    var rawAllocations = _context.HBLMaster
                                        .Include(x => x.HBLActivityLogs)
                                        .Include(x => x.File)
                                            .ThenInclude(x => x.Country)
                                        .Where(x => x.EnterDate != null && x.EnterDate.Date >= startDate.Date && x.EnterDate.Date <= endDate.Date)
                                        .Select(x => new
                                        {
                                            //x.Id,
                                            CountryName = x.File.Country.CountryName,
                                            x.HBLNumber,
                                            x.Container,
                                            x.Booking,
                                            x.CustomerName,
                                            x.EnterDate,
                                            x.File.Etd,
                                            x.File.FileNumber,
                                            HBLActivityLogs = x.HBLActivityLogs.Select(y => new
                                            {
                                                y.HBLId,
                                                y.StartDate,
                                                y.EndDate,
                                                UserName = y.ApplicationUser.UserName,
                                                Status = y.Status.Status,
                                                Activity = y.Activity.NameOfActivity,
                                                DocReceivedDate = y.DocReceivedDate == null ? (DateTime?) null : y.DocReceivedDate.Value
                                            }).FirstOrDefault()
                                        }).ToList();

                    // Process the data with null propagation
                    var allocations = rawAllocations.Select(x => new HBLDashModel
                    {
                        //Id = x.Id,
                        CountryName = x.CountryName,
                        HBLNumber = x.HBLNumber,
                        ContainerNo = x.Container,
                        BookingNo = x.Booking,
                        CustomerName = x.CustomerName,
                        ReceivedDate = x.EnterDate,
                        ETD = x.Etd,
                        FileNumber = x.FileNumber,
                        StartDate = x.HBLActivityLogs?.StartDate,
                        EndDate = x.HBLActivityLogs?.EndDate,
                        User = x.HBLActivityLogs?.UserName,
                        Status = x.HBLActivityLogs?.Status,
                        Activity = x.HBLActivityLogs?.Activity,
                        DocReceivedDate = x.HBLActivityLogs?.DocReceivedDate == null ? (DateTime?) null : x.HBLActivityLogs?.DocReceivedDate.Value.Date
                    }).ToList();

                    DataTable allocationData = ToDataTable(allocations);

                    using (XLWorkbook wb = new XLWorkbook())
                    {
                        allocationData.TableName = "Allocation Data";
                        var wsAllocationData = wb.Worksheets.Add(allocationData);

                        try
                        {
                            using (MemoryStream stream = new MemoryStream())
                            {
                                wb.SaveAs(stream);
                                string excelName = $"AllocationReport-{DateTime.Now:ddMMyyyy_hh_mm_ss}.xlsx";
                                return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelName);
                            }
                        }
                        catch (Exception ex)
                        {
                            // Handle exception
                        }
                    }
                }
            }
            else
            {
                if (startDate.ToShortDateString() != "1/1/0001" && endDate.ToShortDateString() != "1/1/0001")
                {

                    var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
                    var userRole = _context.UserRoles.FirstOrDefault(x => x.UserId == userid);
                    var role = _context.Roles.FirstOrDefault(x => x.Id == userRole.RoleId)?.Name;

                    if (role == "User")
                    {
                        chats = _context.ChatMaster.Where(x => x.SendTime != null && x.SendTime.Value.Date >= startDate.Date && x.SendTime.Value.Date <= endDate.Date && (x.SenderId == userid || x.ReceiverId == userid))
                           .Select(x => new ChatsViewModel
                           {
                               Sender = _context.Users.Where(y => y.EmpId == Convert.ToInt32(x.SenderId)).Select(y => y.CitrixId).FirstOrDefault(),
                               Receiver = _context.Users.Where(y => y.EmpId == Convert.ToInt32(x.ReceiverId)).Select(y => y.CitrixId).FirstOrDefault(),
                               ReferenceNo = x.ReferenceNo,
                               Comments = x.Comments,
                               ReadByUser = x.Isread == true ? "Yes" : "No",
                               ReadTime = x.ReadTime,
                               SendTime = x.SendTime
                           }).ToList();
                    }
                    else
                    {
                        chats = _context.ChatMaster.Where(x => x.SendTime != null && x.SendTime.Value.Date >= startDate.Date && x.SendTime.Value.Date <= endDate.Date)
                           .Select(x => new ChatsViewModel
                           {
                               Sender = _context.Users.Where(y => y.EmpId == Convert.ToInt32(x.SenderId)).Select(y => y.CitrixId).FirstOrDefault(),
                               Receiver = _context.Users.Where(y => y.EmpId == Convert.ToInt32(x.ReceiverId)).Select(y => y.CitrixId).FirstOrDefault(),
                               ReferenceNo = x.ReferenceNo,
                               Comments = x.Comments,
                               ReadByUser = x.Isread == true ? "Yes" : "No",
                               ReadTime = x.ReadTime,
                               SendTime = x.SendTime
                           }).ToList();
                    }
                }

                DataTable chatdata = ToDataTable(chats);

                string filename = "";
                string apath = filename + ".xlsx";
                using (XLWorkbook wb = new XLWorkbook())
                {
                    chatdata.TableName = "Chat Data";
                    var wsChatData = wb.Worksheets.Add(chatdata);

                    wsChatData.Columns().AdjustToContents();
                    try
                    {
                        using (MemoryStream stream = new MemoryStream())
                        {
                            wb.SaveAs(stream);
                            string excelname = $"ChatReport-{DateTime.Now.ToString("ddMMyyyy hh_mm_ss")}.xlsx";
                            return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                        }
                    }
                    catch (Exception ex)
                    {

                    }
                }
            }
            return View();
        }

        //Chat
        public ActionResult Chat()
        {
			_context.Database.SetCommandTimeout(300);
			ViewData["Users"] = _context.Users.OrderBy(x => x.UserName).ToList();
            var UserId = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var empid = _context.Users.Where(x => x.Id == UserId).Select(x => x.EmpId).FirstOrDefault();
            DateTime sevendaysago = DateTime.Now.AddDays(-7);
            var result = _context.ChatMaster.Where(x => x.SenderId == empid.ToString() && x.ReceiverId != "none" && x.SendTime.Value.Date >= sevendaysago.Date).Select(x => new ChatMaster
            {
                ReceiverId = _context.Users.Where(y => y.EmpId.ToString() == x.ReceiverId).Select(x => x.FirstName + " " + x.LastName).FirstOrDefault(),
                ReferenceNo = x.ReferenceNo,
                Comments = x.Comments,
                Isread = x.Isread,
                SendTime = x.SendTime,
                ReadTime = x.ReadTime
            }).OrderByDescending(x => x.Isread == false).ThenByDescending(x => x.SendTime).ToList();

            return View(result);
        }

        [HttpPost]

        public JsonResult Chat(ChatViewModel model)
        {
			_context.Database.SetCommandTimeout(300);
			var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var senduserid = _context.Users.Where(x => x.Id == userid).FirstOrDefault();
            string Msg = string.Empty;
            try
            {
                if (model != null)
                {

                    _context.ChatMaster.Add(new ChatMaster
                    {
                        SenderId = senduserid.EmpId.ToString(),
                        ReceiverId = model.ReceiverId,
                        ReferenceNo = model.ReferenceNo,
                        Comments = model.Comments,
                        Isread = false,
                        ReadTime = null,
                        SendTime = DateTime.UtcNow

                    });
                    _context.SaveChanges();
                    Msg = "send Successfully!";

                }
                else
                {
                    Msg = "Error occur at a time of message sending.";
                }
            }
            catch (Exception ex)
            {
                Msg = "Error " + ex.Message;
            }

            return Json(Msg);
        }

        //List to Data convert
        public DataTable ToDataTable<T>(List<T> items)
        {
            DataTable dataTable = new DataTable(typeof(T).Name);
            //Get all the properties by using reflection   
            PropertyInfo[] Props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
            foreach (PropertyInfo prop in Props)
            {
                //Setting column names as Property names  
                dataTable.Columns.Add(prop.Name);
            }
            foreach (T item in items)
            {
                var values = new object[Props.Length];
                for (int i = 0; i < Props.Length; i++)
                {

                    values[i] = Props[i].GetValue(item, null);
                }
                dataTable.Rows.Add(values);
            }

            return dataTable;
        }

        //Get UserCount
        //     public ActionResult GetCountofUser(DateTime? StartDate, DateTime? EndDate, string ActivityId, string Username)
        //     {
        //_context.Database.SetCommandTimeout(300);
        //List<UserDashboardViewModel> userdashboardModel = new List<UserDashboardViewModel>();
        //         ViewData["Activity"] = _context.ActivityMaster.OrderBy(x => x.Id).ToList();
        //         ViewData["User"] = _context.Users.OrderBy(x => x.CitrixId).ToList();
        //         ViewData["Status"] = _context.StatusMaster.OrderBy(x => x.Status).ToList();
        //         var activityList = _context.ActivityMaster.OrderBy(x => x.Id).ToList();
        //         List<StatusMaster> _status = _context.StatusMaster.ToList();
        //         string completed = _status.Where(x => x.Status == "Completed").Select(x => x.Id).FirstOrDefault();
        //         string pending = _status.Where(x => x.Status == "Pending").Select(x => x.Id).FirstOrDefault();
        //         string query = _status.Where(x => x.Status == "Query").Select(x => x.Id).FirstOrDefault();
        //         string wip = _status.Where(x => x.Status == "WIP").Select(x => x.Id).FirstOrDefault();
        //         string followup1 = _status.Where(x => x.Status == "Followup1").Select(x => x.Id).FirstOrDefault();
        //         string followup2 = _status.Where(x => x.Status == "Followup2").Select(x => x.Id).FirstOrDefault();
        //         string followup3 = _status.Where(x => x.Status == "Followup3").Select(x => x.Id).FirstOrDefault();


        //         if (StartDate != null && EndDate != null)
        //         {
        //             var data = _context.HBLActivityLog.Where(x => x.EndDate.Value.Date >= StartDate.Value.Date && x.EndDate.Value.Date <= EndDate.Value.Date).Include(x => x.Hbl).GroupBy(x => new
        //             {
        //                 x.ApplicationUser.CitrixId,
        //             }).Select(x => new UserDashboardViewModel
        //             {
        //                 User = x.Key.CitrixId,
        //                 Count = x.Count(),
        //             }).ToList();

        //             foreach (UserDashboardViewModel dashboard in data)
        //             {
        //                 dashboard.HBLCount = _context.HBLActivityLog.Where(x => x.ApplicationUser.CitrixId == dashboard.User && x.EndDate.Value.Date >= StartDate.Value.Date && x.EndDate.Value.Date <= EndDate.Value.Date).Include(x => x.Hbl).Include(x => x.Activity)
        //                 .GroupBy(x =>
        //                 new
        //                 {
        //                     x.Activity.Id,
        //                     x.StatusId,
        //                 }).Select(x => new HBLCount
        //                 {
        //                     Count = x.Count(),
        //                     Status = x.Key.StatusId,
        //                     ActivityId = x.Key.Id,
        //                 }).ToList();

        //                 foreach (ActivityMaster activityMaster in activityList.Where(x => x.IsActive == true))
        //                 {
        //                     dashboard.Completed = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status == completed).Sum(x => x.Count);
        //                     dashboard.Pending = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status == pending).Sum(x => x.Count);
        //                     dashboard.Query = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status == query).Sum(x => x.Count);
        //                     dashboard.WIP = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status == wip).Sum(x => x.Count);
        //                     dashboard.Followup1 = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status.Contains(followup1)).Sum(x => x.Count);
        //                     dashboard.Followup2 = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status.Contains(followup2)).Sum(x => x.Count);
        //                     dashboard.Followup3 = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status.Contains(followup3)).Sum(x => x.Count);

        //                     dashboard.HBLStatusCount.Add(new HBLStatusCount
        //                     {
        //                         Completed = dashboard.Completed,
        //                         Pending = dashboard.Pending + dashboard.Followup1 + dashboard.Followup2 + dashboard.Followup3,
        //                         Query = dashboard.Query,
        //                         WIP = dashboard.WIP
        //                     });
        //                     dashboard.TotalCompleted = dashboard.TotalCompleted + dashboard.Completed;
        //                     dashboard.TotalPending += dashboard.Pending;
        //                     dashboard.TotalQuery += dashboard.Query;
        //                     dashboard.TotalWIP += dashboard.WIP;
        //                 }
        //             }

        //             var overallTotal = new UserDashboardViewModel
        //             {
        //                 User = "Total",
        //                 Count = data.Sum(x => x.Count),
        //                 TotalCompleted = data.Sum(x => x.TotalCompleted),
        //                 TotalPending = data.Sum(x => x.TotalPending),
        //                 TotalQuery = data.Sum(x => x.TotalQuery),
        //                 TotalWIP = data.Sum(x => x.TotalWIP),
        //             };

        //             foreach (ActivityMaster activityMaster in activityList.Where(x => x.IsActive == true))
        //             {
        //                 var activityTotal = new HBLStatusCount
        //                 {
        //                     ActivityId = activityMaster.Id,
        //                     Completed = data.Sum(x => x.HBLCount
        //                         .Where(c => c.ActivityId == activityMaster.Id && c.Status.Contains(completed))
        //                         .Sum(c => c.Count)),
        //                     Pending = data.Sum(x => x.HBLCount
        //                         .Where(c => c.ActivityId == activityMaster.Id && c.Status.Contains(pending))
        //                         .Sum(c => c.Count)),
        //                     Query = data.Sum(x => x.HBLCount
        //                         .Where(c => c.ActivityId == activityMaster.Id && c.Status.Contains(query))
        //                         .Sum(c => c.Count)),
        //                     WIP = data.Sum(x => x.HBLCount
        //                         .Where(c => c.ActivityId == activityMaster.Id && c.Status.Contains(wip))
        //                         .Sum(c => c.Count))
        //                 };
        //                 overallTotal.HBLStatusCount.Add(activityTotal);
        //             }

        //             data.Add(overallTotal);
        //             if (Username == "none")
        //             {
        //                 userdashboardModel.AddRange(data);
        //             }
        //             else
        //             {
        //                 userdashboardModel.AddRange(data.Where(x => x.User == Username));
        //             }

        //             return Json(userdashboardModel);
        //         }
        //         else
        //         {
        //             // Same code as before
        //             var data = _context.HBLActivityLog.Include(x => x.Hbl).GroupBy(x => new
        //             {
        //                 x.ApplicationUser.CitrixId,
        //             }).Select(x => new UserDashboardViewModel
        //             {
        //                 User = x.Key.CitrixId,
        //                 Count = x.Count(),
        //             }).ToList();

        //             foreach (UserDashboardViewModel dashboard in data)
        //             {
        //                 dashboard.HBLCount = _context.HBLActivityLog.Where(x => x.ApplicationUser.CitrixId == dashboard.User).Include(x => x.Hbl).Include(x => x.Activity)
        //                 .GroupBy(x =>
        //                 new
        //                 {
        //                     x.ApplicationUser.CitrixId,
        //                     x.Activity.Id,
        //                     x.StatusId,

        //                 }).Select(x => new HBLCount
        //                 {
        //                     Count = x.Count(),
        //                     Status = x.Key.StatusId,
        //                     ActivityId = x.Key.Id,

        //                 }).ToList();

        //                 foreach (ActivityMaster activityMaster in activityList.Where(x => x.IsActive == true))
        //                 {
        //                     dashboard.Completed = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status.Contains(completed)).Sum(x => x.Count);
        //                     dashboard.Pending = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status.Contains(pending)).Sum(x => x.Count);
        //                     dashboard.Query = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status.Contains(query)).Sum(x => x.Count);
        //                     dashboard.WIP = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status.Contains(wip)).Sum(x => x.Count);
        //                     dashboard.Followup1 = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status.Contains(followup1)).Sum(x => x.Count);
        //                     dashboard.Followup2 = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status.Contains(followup2)).Sum(x => x.Count);
        //                     dashboard.Followup3 = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status.Contains(followup3)).Sum(x => x.Count);
        //                     dashboard.HBLStatusCount.Add(new HBLStatusCount
        //                     {
        //                         Completed = dashboard.Completed,
        //                         Pending = dashboard.Pending + dashboard.Followup1 + dashboard.Followup2 + dashboard.Followup3,
        //                         Query = dashboard.Query,
        //                         WIP = dashboard.WIP
        //                     });
        //                     dashboard.TotalCompleted = dashboard.TotalCompleted + dashboard.Completed;
        //                     dashboard.TotalPending += dashboard.Pending;
        //                     dashboard.TotalQuery += dashboard.Query;
        //                     dashboard.TotalWIP += dashboard.WIP;

        //                 }
        //             }

        //             var overallTotal = new UserDashboardViewModel
        //             {
        //                 User = "Total",
        //                 Count = data.Sum(x => x.Count),
        //                 TotalCompleted = data.Sum(x => x.TotalCompleted),
        //                 TotalPending = data.Sum(x => x.TotalPending),
        //                 TotalQuery = data.Sum(x => x.TotalQuery),
        //                 TotalWIP = data.Sum(x => x.TotalWIP),
        //             };

        //             foreach (ActivityMaster activityMaster in activityList.Where(x => x.IsActive == true))
        //             {
        //                 var activityTotal = new HBLStatusCount
        //                 {
        //                     ActivityId = activityMaster.Id,
        //                     Completed = data.Sum(x => x.HBLCount
        //                         .Where(c => c.ActivityId == activityMaster.Id && c.Status.Contains(completed))
        //                         .Sum(c => c.Count)),
        //                     Pending = data.Sum(x => x.HBLCount
        //                         .Where(c => c.ActivityId == activityMaster.Id && c.Status.Contains(pending))
        //                         .Sum(c => c.Count)),
        //                     Query = data.Sum(x => x.HBLCount
        //                         .Where(c => c.ActivityId == activityMaster.Id && c.Status.Contains(query))
        //                         .Sum(c => c.Count)),
        //                     WIP = data.Sum(x => x.HBLCount
        //                         .Where(c => c.ActivityId == activityMaster.Id && c.Status.Contains(wip))
        //                         .Sum(c => c.Count))
        //                 };
        //                 overallTotal.HBLStatusCount.Add(activityTotal);
        //             }
        //             data.Add(overallTotal);
        //             userdashboardModel.AddRange(data);
        //         }

        //         if (Username != null)
        //         {
        //             if (Username != "none")
        //             {
        //                 return View(userdashboardModel.Where(x => x.User == Username));
        //             }
        //             else
        //             {
        //                 return View(userdashboardModel);
        //             }
        //         }
        //         else
        //         {
        //             return View(userdashboardModel);
        //         }
        //     }

        public ActionResult GetCountofUser(DateTime? StartDate, DateTime? EndDate, string ActivityId, string Username)
        {
            _context.Database.SetCommandTimeout(300);
            List<UserDashboardViewModel> userdashboardModel = new List<UserDashboardViewModel>();
            ViewData["Activity"] = _context.ActivityMaster.OrderBy(x => x.Id).ToList();
            ViewData["User"] = _context.Users.OrderBy(x => x.CitrixId).ToList();
            ViewData["Status"] = _context.StatusMaster.OrderBy(x => x.Status).ToList();
            var activityList = _context.ActivityMaster.OrderBy(x => x.Id).ToList();
            List<StatusMaster> _status = _context.StatusMaster.ToList();
            string completed = _status.Where(x => x.Status == "Completed").Select(x => x.Id).FirstOrDefault();
            string pending = _status.Where(x => x.Status == "Pending").Select(x => x.Id).FirstOrDefault();
            string query = _status.Where(x => x.Status == "Query").Select(x => x.Id).FirstOrDefault();
            string wip = _status.Where(x => x.Status == "WIP").Select(x => x.Id).FirstOrDefault();
            string followup1 = _status.Where(x => x.Status == "Followup1").Select(x => x.Id).FirstOrDefault();
            string followup2 = _status.Where(x => x.Status == "Followup2").Select(x => x.Id).FirstOrDefault();
            string followup3 = _status.Where(x => x.Status == "Followup3").Select(x => x.Id).FirstOrDefault();

            if (StartDate != null && EndDate != null)
            {
                // Ensure we only select the most recent record for each user by grouping and selecting the latest EndDate
                var data = _context.HBLActivityLog
                    .Where(x => x.EndDate.Value.Date >= StartDate.Value.Date && x.EndDate.Value.Date <= EndDate.Value.Date)
                    .GroupBy(x => new
                    {
                        x.ApplicationUser.CitrixId
                    })
                    .Select(g => new
                    {
                        User = g.Key.CitrixId,
                        LatestEndDate = g.Max(x => x.EndDate), // Get the latest EndDate for each user
                        Count = g.Count()
                    })
                    .ToList()
                    .Select(x => new UserDashboardViewModel
                    {
                        User = x.User,
                        Count = x.Count
                    })
                    .ToList();

                foreach (UserDashboardViewModel dashboard in data)
                {
                    // Fetch HBL Count for each user by latest EndDate
                    dashboard.HBLCount = _context.HBLActivityLog
                        .Where(x => x.ApplicationUser.CitrixId == dashboard.User && x.EndDate.Value.Date >= StartDate.Value.Date && x.EndDate.Value.Date <= EndDate.Value.Date)
                        .Include(x => x.Hbl)
                        .Include(x => x.Activity)
                        .GroupBy(x => new
                        {
                            x.Activity.Id,
                            x.StatusId
                        })
                        .Select(g => new HBLCount
                        {
                            Count = g.Count(),
                            Status = g.Key.StatusId,
                            ActivityId = g.Key.Id
                        })
                        .ToList();

                    foreach (ActivityMaster activityMaster in activityList.Where(x => x.IsActive == true))
                    {
                        dashboard.Completed = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status == completed).Sum(x => x.Count);
                        dashboard.Pending = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status == pending).Sum(x => x.Count);
                        dashboard.Query = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status == query).Sum(x => x.Count);
                        dashboard.WIP = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status == wip).Sum(x => x.Count);
                        dashboard.Followup1 = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status.Contains(followup1)).Sum(x => x.Count);
                        dashboard.Followup2 = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status.Contains(followup2)).Sum(x => x.Count);
                        dashboard.Followup3 = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status.Contains(followup3)).Sum(x => x.Count);

                        dashboard.HBLStatusCount.Add(new HBLStatusCount
                        {
                            Completed = dashboard.Completed,
                            Pending = dashboard.Pending + dashboard.Followup1 + dashboard.Followup2 + dashboard.Followup3,
                            Query = dashboard.Query,
                            WIP = dashboard.WIP
                        });

                        dashboard.TotalCompleted += dashboard.Completed;
                        dashboard.TotalPending += dashboard.Pending;
                        dashboard.TotalQuery += dashboard.Query;
                        dashboard.TotalWIP += dashboard.WIP;
                    }
                }

                var overallTotal = new UserDashboardViewModel
                {
                    User = "Total",
                    Count = data.Sum(x => x.Count),
                    TotalCompleted = data.Sum(x => x.TotalCompleted),
                    TotalPending = data.Sum(x => x.TotalPending),
                    TotalQuery = data.Sum(x => x.TotalQuery),
                    TotalWIP = data.Sum(x => x.TotalWIP)
                };

                foreach (ActivityMaster activityMaster in activityList.Where(x => x.IsActive == true))
                {
                    var activityTotal = new HBLStatusCount
                    {
                        ActivityId = activityMaster.Id,
                        Completed = data.Sum(x => x.HBLCount.Where(c => c.ActivityId == activityMaster.Id && c.Status.Contains(completed)).Sum(c => c.Count)),
                        Pending = data.Sum(x => x.HBLCount.Where(c => c.ActivityId == activityMaster.Id && c.Status.Contains(pending)).Sum(c => c.Count)),
                        Query = data.Sum(x => x.HBLCount.Where(c => c.ActivityId == activityMaster.Id && c.Status.Contains(query)).Sum(c => c.Count)),
                        WIP = data.Sum(x => x.HBLCount.Where(c => c.ActivityId == activityMaster.Id && c.Status.Contains(wip)).Sum(c => c.Count))
                    };

                    overallTotal.HBLStatusCount.Add(activityTotal);
                }

                data.Add(overallTotal);

                if (Username == "none")
                {
                    userdashboardModel.AddRange(data);
                }
                else
                {
                    userdashboardModel.AddRange(data.Where(x => x.User == Username));
                }

                return Json(userdashboardModel);
            }
            else
            {
                // Same code as before, ensuring only unique/latest EndDate is selected
                var data = _context.HBLActivityLog
                    .GroupBy(x => new
                    {
                        x.ApplicationUser.CitrixId
                    })
                    .Select(g => new
                    {
                        User = g.Key.CitrixId,
                        LatestEndDate = g.Max(x => x.EndDate),
                        Count = g.Count()
                    })
                    .ToList()
                    .Select(x => new UserDashboardViewModel
                    {
                        User = x.User,
                        Count = x.Count
                    })
                    .ToList();

                foreach (UserDashboardViewModel dashboard in data)
                {
                    dashboard.HBLCount = _context.HBLActivityLog
                        .Where(x => x.ApplicationUser.CitrixId == dashboard.User)
                        .Include(x => x.Hbl)
                        .Include(x => x.Activity)
                        .GroupBy(x => new
                        {
                            x.ApplicationUser.CitrixId,
                            x.Activity.Id,
                            x.StatusId
                        })
                        .Select(g => new HBLCount
                        {
                            Count = g.Count(),
                            Status = g.Key.StatusId,
                            ActivityId = g.Key.Id
                        })
                        .ToList();

                    foreach (ActivityMaster activityMaster in activityList.Where(x => x.IsActive == true))
                    {
                        dashboard.Completed = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status.Contains(completed)).Sum(x => x.Count);
                        dashboard.Pending = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status.Contains(pending)).Sum(x => x.Count);
                        dashboard.Query = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status.Contains(query)).Sum(x => x.Count);
                        dashboard.WIP = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status.Contains(wip)).Sum(x => x.Count);
                        dashboard.Followup1 = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status.Contains(followup1)).Sum(x => x.Count);
                        dashboard.Followup2 = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status.Contains(followup2)).Sum(x => x.Count);
                        dashboard.Followup3 = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status.Contains(followup3)).Sum(x => x.Count);

                        dashboard.HBLStatusCount.Add(new HBLStatusCount
                        {
                            Completed = dashboard.Completed,
                            Pending = dashboard.Pending + dashboard.Followup1 + dashboard.Followup2 + dashboard.Followup3,
                            Query = dashboard.Query,
                            WIP = dashboard.WIP
                        });

                        dashboard.TotalCompleted += dashboard.Completed;
                        dashboard.TotalPending += dashboard.Pending;
                        dashboard.TotalQuery += dashboard.Query;
                        dashboard.TotalWIP += dashboard.WIP;
                    }
                }

                var overallTotal = new UserDashboardViewModel
                {
                    User = "Total",
                    Count = data.Sum(x => x.Count),
                    TotalCompleted = data.Sum(x => x.TotalCompleted),
                    TotalPending = data.Sum(x => x.TotalPending),
                    TotalQuery = data.Sum(x => x.TotalQuery),
                    TotalWIP = data.Sum(x => x.TotalWIP)
                };

                foreach (ActivityMaster activityMaster in activityList.Where(x => x.IsActive == true))
                {
                    var activityTotal = new HBLStatusCount
                    {
                        ActivityId = activityMaster.Id,
                        Completed = data.Sum(x => x.HBLCount.Where(c => c.ActivityId == activityMaster.Id && c.Status.Contains(completed)).Sum(c => c.Count)),
                        Pending = data.Sum(x => x.HBLCount.Where(c => c.ActivityId == activityMaster.Id && c.Status.Contains(pending)).Sum(c => c.Count)),
                        Query = data.Sum(x => x.HBLCount.Where(c => c.ActivityId == activityMaster.Id && c.Status.Contains(query)).Sum(c => c.Count)),
                        WIP = data.Sum(x => x.HBLCount.Where(c => c.ActivityId == activityMaster.Id && c.Status.Contains(wip)).Sum(c => c.Count))
                    };

                    overallTotal.HBLStatusCount.Add(activityTotal);
                }

                data.Add(overallTotal);
                userdashboardModel.AddRange(data);
            }

            if (Username != null)
            {
                if (Username != "none")
                {
                    return View(userdashboardModel.Where(x => x.User == Username));
                }
                else
                {
                    return View(userdashboardModel);
                }
            }
            else
            {
                return View(userdashboardModel);
            }
        }


        //User wise data
        [HttpPost]
        public JsonResult GetUserDatacount()
        {
			_context.Database.SetCommandTimeout(300);
			var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            List<ApplicationUser> udata = _context.Users.ToList();



            var result = _context.HBLMaster
                        .Include(fm => fm.HBLActivityLogs)
                            .ThenInclude(fa => fa.ApplicationUser)
                        .Where(fm => fm.HBLActivityLogs.Any(fa => fa.Status.Status != "Completed"))
                        .Select(fm => new
                        {
                            Id = fm.Id,
                            FileId = fm.FileId,
                            ActivityName = fm.HBLActivityLogs.Select(x => x.Activity.NameOfActivity),
                            StatusName = fm.HBLActivityLogs.Select(x => x.Status.Status),
                            UserName = fm.HBLActivityLogs.Select(x => x.ApplicationUser.UserName),
                            // Add other relevant properties here
                        })
                        .ToList();

            var fdata = _context.HBLMaster.Include(x => x.HBLActivityLogs).ThenInclude(x => x.Activity)
                      .Select(x => new
                      {
                          Id = x.Id,
                          HBLNo = x.HBLNumber,
                          ActivityId = x.HBLActivityLogs.Select(x => x.ActivityId),
                          StatusId = x.HBLActivityLogs.Select(x => x.Status),
                          Comment = x.HBLActivityLogs.Select(x => x.Comment),
                          UserId = x.HBLActivityLogs.Select(x => x.UserId)
                      }).ToList();

            var data = (from fm in _context.FileMaster
                        join fa in _context.FileActivityLog
                        on fm.Id equals fa.FileId
                        join am in _context.ActivityMaster
                        on fa.ActivityId equals am.Id
                        join um in _context.Users
                        on fa.UserId equals um.Id
                        select new FileDashModel
                        {
                            Id = fm.Id,
                            CountryName = fm.Country.CountryName,
                            DraftCutOff = fm.DraftCutoff,
                            ETD = fm.Etd,
                            FileNumber = fm.FileNumber,
                            ActivityId = am.NameOfActivity,
                            StatusId = fa.Status.Status,
                            Comment = fa.Comment,
                            UserId = um.UserName

                        });

            int totalRecord = 0;
            int filterRecord = 0;

            var returnObj = new
            {
                data = result//.Where(x => x.Username!=null)
            };

            return Json(returnObj);
        }

        //HBL Allocation data
        public JsonResult HBLAllocation(string[] hblNumbers, string activity, string user, string status)
        {
			_context.Database.SetCommandTimeout(300);
			string Msg = "";
            try
            {
                var statusId = _context.StatusMaster.Where(x => x.Status == "WIP").Select(x => x.Id).FirstOrDefault();
                var completedId = _context.StatusMaster.Where(x => x.Status == "Completed").Select(x => x.Id).FirstOrDefault();
                foreach (string hblid in hblNumbers)
                {
                    var hblactivity = _context.HBLActivityLog.Where(x => x.HBLId == hblid.Trim() && x.ActivityId == activity).FirstOrDefault();

                    if (hblactivity != null)
                    {
                        if (hblactivity.StatusId != completedId)
                        {
                            HBLActivitylogHistory hBLActivitylogHistory = new HBLActivitylogHistory
                            {
                                HBLogId = hblactivity.Id,
                                ActivityId = hblactivity.ActivityId,
                                StatusId = hblactivity.StatusId,
                                UserId = hblactivity.UserId,
                                Comment = hblactivity.Comment,
                                StartDate = hblactivity.StartDate,
                                //EndDate = hblactivity.EndDate,

                            };
                            _context.HBLActivitylogHistory.Add(hBLActivitylogHistory);
                            _context.SaveChanges();

                            if (hblactivity.UserId == user)
                            {
                                return Json("Same User");
                            }
                            else
                            {
                                hblactivity.UserId = user;
                                _context.HBLActivityLog.Update(hblactivity);
                                _context.SaveChanges();
                            }
                        }
                        else
                        {
                            return Json("Activity already completed");
                        }
                        

                    }
                    else
                    {
                        HBLActivityLog hBLActivityLogs = new HBLActivityLog
                        {
                            UserId = user,
                            StatusId = statusId,
                            ActivityId = activity,
                            HBLId = hblid,
                            StartDate = DateTime.UtcNow,
                            EndDate = DateTime.UtcNow,
                        };
                        _context.HBLActivityLog.Add(hBLActivityLogs);
                        _context.SaveChanges();
                        //Code Added By Ravi on dated 25/01/2024
                        HBLActivitylogHistory hBLActivitylogHistory = new HBLActivitylogHistory
                        {
                            HBLogId = hBLActivityLogs.HBLId,
                            ActivityId = hBLActivityLogs.ActivityId,
                            StatusId = hBLActivityLogs.StatusId,
                            UserId = hBLActivityLogs.UserId,
                            Comment = hBLActivityLogs.Comment,
                            StartDate = hBLActivityLogs.StartDate,
                            //EndDate = hblactivity.EndDate,

                        };
                        _context.HBLActivitylogHistory.Add(hBLActivitylogHistory);
                        _context.SaveChanges();
                    }
                }
            }
            catch (Exception ex)
            {
                return Json("error");
            }
            _context.SaveChanges();
            return Json("Success");

        }

        //Assign role to user
        [HttpPost]
        public JsonResult AssignRole([FromBody] UserRoleViewModel userrole)
        {
			_context.Database.SetCommandTimeout(300);
			string Msg = null;
            var user = _context.Users.FirstOrDefault(x => x.EmpId == Convert.ToInt32(userrole.UserId));
            if (user == null)
            {
                Msg = "User not found";
                return Json(new { Msg });
            }

            var userRole = _context.UserRoles.FirstOrDefault(x => x.UserId == user.Id);
            if (userRole != null)
            {
                _context.UserRoles.Remove(userRole);
                _context.SaveChanges();
                _context.UserRoles.Add(new IdentityUserRole<string>
                {
                    RoleId = userrole.RoleId,
                    UserId = user.Id
                });
            }
            else
            {
                _context.UserRoles.Add(new IdentityUserRole<string>
                {
                    RoleId = userrole.RoleId,
                    UserId = user.Id
                });
            }
            _context.SaveChanges();
            Msg = "User role updated successfully";

            return Json(Msg);
        }

        //Assign Chat feature to user
        [HttpPost]
        public JsonResult ChatEnables(bool Enable, string citrixid)
        {
			_context.Database.SetCommandTimeout(300);
			string Msg = null;
            var user = _context.Users.FirstOrDefault(x => x.CitrixId.Trim().ToLower() == citrixid.Trim().ToLower());

            if (user == null)
            {
                Msg = "User not found";
                return Json(new { Msg });
            }
            else
            {
                if (Enable == true)
                {
                    user.ChatEnable = Enable;
                    _context.Users.Update(user);
                    _context.SaveChanges();
                    Msg = "Enable";
                }
                else
                {
                    user.ChatEnable = Enable;
                    _context.Users.Update(user);
                    _context.SaveChanges();
                    Msg = "Disable";
                }
            }

            return Json(Msg);
        }

        //Assign Chat feature to user
        [HttpPost]
        public JsonResult IsLdap(bool Enable, string citrixid)
        {
			_context.Database.SetCommandTimeout(300);
			string Msg = null;
            var user = _context.Users.FirstOrDefault(x => x.CitrixId.Trim().ToLower() == citrixid.Trim().ToLower());

            if (user == null)
            {
                Msg = "User not found";
                return Json(new { Msg });
            }
            else
            {
                if (Enable == true)
                {
                    user.IsLDAP = Enable;
                    user.IsReset = false;
                    _context.Users.Update(user);
                    _context.SaveChanges();
                    Msg = "Enable";
                }
                else
                {
                    user.IsLDAP = Enable;
                    _context.Users.Update(user);
                    _context.SaveChanges();
                    Msg = "Disable";
                }
            }

            return Json(Msg);
        }

        //Assign Chat feature to user
        [HttpPost]
        public JsonResult IsReset(bool Enable, string citrixid)
        {
			_context.Database.SetCommandTimeout(300);
			string Msg = null;
            var user = _context.Users.FirstOrDefault(x => x.CitrixId.Trim().ToLower() == citrixid.Trim().ToLower());

            if (user == null)
            {
                Msg = "User not found";
                return Json(new { Msg });
            }
            else
            {
                if (Enable == true)
                {
                    user.IsReset = Enable;
                    _context.Users.Update(user);
                    _context.SaveChanges();
                    Msg = "Enable";
                }
                else
                {
                    user.IsReset = Enable;
                    _context.Users.Update(user);
                    _context.SaveChanges();
                    Msg = "Disable";
                }
            }
            //return Json(Msg);
            return Json(new { Message = Msg, UserName = user.UserName, CitrixId = user.CitrixId, UserId = user.Id });
        }

        //Report File Downloaded from Dashboard
        [HttpPost]
        public IActionResult FilterDataReport([FromBody] HBLDashModel[] model)
        {
			_context.Database.SetCommandTimeout(300);
			// Access the properties of the received JSON object

			DataTable dt = ToDataTable(model.ToList());
            string excelname = $"UserReport-{DateTime.Now.ToString("ddmmyyyy hh:mm:ss")}.xlsx";
            MemoryStream stream = new MemoryStream();
            using (XLWorkbook wb = new XLWorkbook())
            {
                dt.TableName = "HBL Data";
                var wsFileData = wb.Worksheets.Add(dt);
                wsFileData.Columns().AdjustToContents();
                try
                {
                    wb.SaveAs(stream);
                }
                catch (Exception ex)
                {

                }
            }
            // Return a response, if needed
            return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
        }

    }

}
