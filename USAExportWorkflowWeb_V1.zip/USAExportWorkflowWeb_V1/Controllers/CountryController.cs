﻿using USAExportWorkflowWeb_V1.DataModel;
using USAExportWorkflowWeb_V1.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;

namespace USAExportWorkflowWeb_V1.Controllers
{
	//Country
	public class CountryController : Controller
	{
		private readonly ApplicationDBContext _context;

		public CountryController(ApplicationDBContext context)
		{
			_context = context;
		}

		// GET: Country
		public async Task<IActionResult> Index()
		{
			return View(await _context.CountryMaster.ToListAsync());
		}

		// GET: Country/Details/5
		public async Task<IActionResult> Details(string? id)
		{
			_context.Database.SetCommandTimeout(300);
			if (id == null || id.Trim()=="")
			{
				return NotFound();
			}

			var country = await _context.CountryMaster
				.FirstOrDefaultAsync(m => m.Id == id);
			if (country == null)
			{
				return NotFound();
			}

			return View(country);
		}

		// GET: Country/Create
		public IActionResult Create()
		{
			return View();
		}

		// POST: Country/Create
		// To protect from overposting attacks, enable the specific properties you want to bind to, for 
		// more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Create([Bind("Id,CountryName")] CountryMaster country)
		{
			_context.Database.SetCommandTimeout(300);
			if (ModelState.IsValid)
			{ 
				var existingCountry = _context.CountryMaster.FirstOrDefault(m => m.CountryName.ToLower() == country.CountryName.ToLower());
				if (existingCountry == null)
				{
                    _context.Add(country);
                    await _context.SaveChangesAsync();
                    return RedirectToAction(nameof(Index));
                }
				else
				{
                    return RedirectToAction(nameof(Create));
                }
			}
			return View(country);
		}

		// GET: Country/Edit/5
		public async Task<IActionResult> Edit(string? id)
		{
			_context.Database.SetCommandTimeout(300);
			if (id == null || id.Trim()=="")
			{
				return NotFound();
			}
			var country = await _context.CountryMaster.FindAsync(id);
			if (country == null)
			{
				return NotFound();
			}
			return View(country);
		}

		// POST: Country/Edit/5		
		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Edit(string id, [Bind("Id,CountryName")] CountryMaster country)
		{
			_context.Database.SetCommandTimeout(300);
			if (id != country.Id)
			{
				return NotFound();
			}

			if (ModelState.IsValid)
			{
				try
				{
					_context.Update(country);
					await _context.SaveChangesAsync();
				}
				catch (DbUpdateConcurrencyException)
				{
					if (!CountryExists(country.Id))
					{
						return NotFound();
					}
					else
					{
						throw;
					}
				}
				return RedirectToAction(nameof(Index));
			}
			return View(country);
		}

		// GET: Country/Delete/5
		public async Task<IActionResult> Delete(string? id)
		{
			_context.Database.SetCommandTimeout(300);
			if (id == null)
			{
				return NotFound();
			}

			var country = await _context.CountryMaster.FirstOrDefaultAsync(m => m.Id == id); 
			if (country == null)
			{
				return NotFound();
			}

			return View(country);
		}

		// POST: Country/Delete/5
		[HttpPost, ActionName("Delete")]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> DeleteConfirmed(string id)
		{
			_context.Database.SetCommandTimeout(300);
			var country = await _context.CountryMaster.FindAsync(id);
			_context.CountryMaster.Remove(country);
			await _context.SaveChangesAsync();
			return RedirectToAction(nameof(Index));
		}
		//Check Country is exits
		private bool CountryExists(string id)
		{
			return _context.CountryMaster.Any(e => e.Id == id);
		}
	}
}


