﻿using USAExportWorkflowWeb_V1.DataModel;
using USAExportWorkflowWeb_V1.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using System.Linq.Dynamic.Core;
using Microsoft.AspNetCore.Authorization;
using System.Data;
using ClosedXML.Excel;
using System.Reflection;
using DocumentFormat.OpenXml.InkML;

namespace USAExportWorkflowWeb_V1.Controllers
{
    //User 
    [Authorize]
    public class UserController : Controller
    {
        ApplicationDBContext _context;
        private readonly IHttpContextAccessor _httpContextAccessor;
        public UserController(ApplicationDBContext context, IHttpContextAccessor httpContextAccessor)
        {
            _context = context;
            _httpContextAccessor = httpContextAccessor;
        }
        public IActionResult Index()
        {
            var UserId = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            ViewData["username"] = _context.Users.Where(x => x.Id == UserId && x.ChatEnable == true).Select(x => x.UserName).FirstOrDefault();
            return View();
        }

        public IActionResult Files()
        {
            ViewBag.ActivityMaster = _context.ActivityMaster.ToList();
            ViewBag.Countries = _context.CountryMaster.ToList();
            return View();

        }
        /// <summary>
        /// Add Activity
        /// </summary>
        /// <param name="fileActivity"></param>
        /// <returns></returns>
        [HttpPost]
        public IActionResult AddActivity(FileActivityLogModel fileActivity)
        {
			_context.Database.SetCommandTimeout(300);
			string Msg = "";
            if (ModelState.IsValid)
            {
                var fileactivityIsexits = _context.FileActivityLog.Where(x => x.ActivityId == fileActivity.ActivityId && x.FileId == fileActivity.FileId).FirstOrDefault();

                if (fileactivityIsexits == null)
                {
                    _context.FileActivityLog.Add(new FileActivityLog
                    {
                        Id = fileActivity.Id,
                        FileId = fileActivity.FileId,
                        ActivityId = fileActivity.ActivityId,
                        StatusId = fileActivity.StatusId,
                        Comment = fileActivity.Comment,
                        UserId = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier),
                        //StartDate = DateTime.UtcNow,
                        EndDate = DateTime.UtcNow,
                    });
                    Msg = "";
                    _context.SaveChanges();
                    return Json(fileActivity.FileId);
                }
                else
                {

                    _context.FileAcitivityLogHistory.Add(new FileAcitivityLogHistory
                    {
                        FileLogId = fileactivityIsexits.Id,
                        ActivityId = fileactivityIsexits.ActivityId,
                        StatusId = fileactivityIsexits.StatusId,
                        Comment = fileactivityIsexits.Comment,
                        UserId = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier),
                        StartDate = DateTime.UtcNow,
                        EndDate = DateTime.UtcNow,
                    });

                    fileactivityIsexits.StatusId = fileActivity.StatusId;
                    fileactivityIsexits.Comment = fileActivity.Comment;
                    fileactivityIsexits.StartDate = DateTime.UtcNow;
                    fileactivityIsexits.EndDate = DateTime.UtcNow;
                    fileactivityIsexits.UserId = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);

                    Msg = "Status Update Successfully.";
                    _context.SaveChanges();

                    return Json(Msg);
                }

            }
            else
            {
                return Json("Something went wrong");
            }
        }

        [HttpGet]
        public IActionResult FileActivity(string Id)
        {
			_context.Database.SetCommandTimeout(300);
			ViewData["fileId"] = Id;
            ViewData["fileDtls"] = _context.FileMaster.Where(x => x.Id == Id).Include(x => x.Country).FirstOrDefault();

            ViewData["FileActivityList"] = _context.FileActivityLog.Where(x => x.FileId == Id)
                                                        .Include(x => x.Activity).Include(x => x.Status).Include(x => x.ApplicationUser)
                                                        .Select(x => new FileActivityLogModel
                                                        {
                                                            Id = x.Id,
                                                            FileId = x.File.Id,
                                                            ActivityId = x.ActivityId,
                                                            ActivityName = x.Activity.NameOfActivity,
                                                            StatusId = x.StatusId,
                                                            StatusName = x.Status.Status,
                                                            UserId = x.UserId,
                                                            UserName = x.ApplicationUser.UserName,
                                                            Comment = x.Comment,
                                                            StartDate = x.StartDate,
                                                            EndDate = x.EndDate,
                                                        }).ToList();
            ViewBag.Activity = _context.ActivityMaster.Where(x => x.Source == "Upload").ToList();
            ViewBag.Status = _context.StatusMaster.ToList();

            return PartialView();
        }

        //Get hbl's data 
        //     [HttpPost]
        //     public IActionResult GetHBLs(string activity, string hblnumber, string bookingno, string filenumber, string container)
        //     {
        //_context.Database.SetCommandTimeout(300);
        //         int totalRecord = 0;
        //         int filterRecord = 0;
        //         int hblrecord = 0;
        //         var draw = Request.Form["draw"].FirstOrDefault();
        //         var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
        //         var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
        //         var searchValue = Request.Form["search[value]"].FirstOrDefault();
        //         int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "0");
        //         int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");
        //         string key = "";
        //         string value = "";

        //         //List<HBLDashModel> hBLDashModel = new List<HBLDashModel>();
        //         //var data = _context.HBLMaster.Include(x => x.HBLActivityLogs).Include(x => x.File).ThenInclude(x => x.Country).Select(x => new HBLDashModel
        //         //{
        //         //    Id = x.Id,
        //         //    CountryName = x.File.Country.CountryName,
        //         //    HBLNumber = x.HBLNumber,
        //         //    ContainerNo = x.Container,
        //         //    BookingNo = x.Booking,
        //         //    CustomerName = x.CustomerName,
        //         //    User = x.HBLActivityLogs.Select(x => x.ApplicationUser.UserName).FirstOrDefault(),
        //         //    Status = x.HBLActivityLogs.Select(x => x.Status.Status).FirstOrDefault(),
        //         //    Activity = x.HBLActivityLogs.Select(x => x.Activity.NameOfActivity).FirstOrDefault(),
        //         //    ReceivedDate = x.EnterDate,
        //         //    ETD = x.File.Etd,
        //         //    FileNumber = x.File.FileNumber
        //         //}).ToList();

        //         List<HBLDashModel> hBLDashModel = new List<HBLDashModel>();
        //         _context.Database.SetCommandTimeout(300);
        //         // Calculate the date three months ago from the current date
        //         DateTime threeMonthsAgo = DateTime.Now.AddMonths(-3);

        //         //var data = _context.HBLMaster
        //         //    .Include(x => x.HBLActivityLogs)
        //         //    .Include(x => x.File)
        //         //    .ThenInclude(x => x.Country)
        //         //    .Where(x => x.File.Etd >= threeMonthsAgo)  // Filter data for the last three months
        //         //    .Select(x => new HBLDashModel
        //         //    {
        //         //        Id = x.Id,
        //         //        CountryName = x.File.Country.CountryName,
        //         //        HBLNumber = x.HBLNumber,
        //         //        ContainerNo = x.Container,
        //         //        BookingNo = x.Booking,
        //         //        CustomerName = x.CustomerName,
        //         //        User = x.HBLActivityLogs.Select(x => x.ApplicationUser.UserName).FirstOrDefault(),
        //         //        Status = x.HBLActivityLogs.Select(x => x.Status.Status).FirstOrDefault(),
        //         //        Activity = x.HBLActivityLogs.Select(x => x.Activity.NameOfActivity).FirstOrDefault(),
        //         //        ReceivedDate = x.EnterDate,
        //         //        ETD = x.File.Etd,
        //         //        FileNumber = x.File.FileNumber
        //         //    }).ToList();

        //         var rawData = _context.HBLMaster
        //             .Where(x => x.File.Etd >= threeMonthsAgo)  // Filter data for the last three months
        //             .Select(x => new
        //             {
        //                 x.Id,
        //                 x.HBLNumber,
        //                 x.Booking,
        //                 x.Container,
        //                 x.CustomerName,
        //                 x.EnterDate,
        //                 x.File.FileNumber,
        //                 x.File.Etd,
        //                 CountryName = x.File.Country.CountryName,
        //                 User = x.HBLActivityLogs.Select(y => y.ApplicationUser.UserName).FirstOrDefault(),
        //                 Status = x.HBLActivityLogs.Select(y => y.Status.Status).FirstOrDefault(),
        //                 Activity = x.HBLActivityLogs.Select(y => y.Activity.NameOfActivity).FirstOrDefault()
        //             })
        //         .ToList();

        //         var data = rawData
        //             .GroupBy(x => new { x.Booking, x.HBLNumber })  // Group by BookingNo and HBLNumber
        //             .Select(g => g.First())  // Select the first distinct record in each group
        //             .Select(x => new HBLDashModel
        //             {
        //                 Id = x.Id,
        //                 CountryName = x.CountryName,
        //                 HBLNumber = x.HBLNumber,
        //                 ContainerNo = x.Container,
        //                 BookingNo = x.Booking,
        //                 CustomerName = x.CustomerName,
        //                 User = x.User,
        //                 Status = x.Status,
        //                 Activity = x.Activity,
        //                 ReceivedDate = x.EnterDate,
        //                 ETD = x.Etd,
        //                 FileNumber = x.FileNumber
        //             })
        //         .ToList();


        //         //Sorting data
        //         IQueryable<HBLDashModel> SortedData = data.AsQueryable();

        //         if (!string.IsNullOrEmpty(activity) && activity != "none" && activity != "--Select--")
        //         {
        //             SortedData = SortedData.Where(x => x.Activity == activity.Trim());

        //         }
        //         if (!string.IsNullOrEmpty(hblnumber) && hblnumber != "none" && hblnumber != "--Select--")
        //         {
        //             SortedData = SortedData.Where(x => x.HBLNumber.Contains(hblnumber.Trim()));

        //         }
        //         if (!string.IsNullOrEmpty(bookingno) && bookingno != "none" && bookingno != "--Select--")
        //         {

        //             SortedData = SortedData.Where(x => x.BookingNo.Contains(bookingno.Trim()));
        //         }
        //         if (!string.IsNullOrEmpty(filenumber) && filenumber != "none" && filenumber != "--Select--")
        //         {
        //             SortedData = SortedData.Where(x => x.FileNumber.Contains(filenumber.Trim()));
        //         }
        //         if (!string.IsNullOrEmpty(container) && container != "none" && container != "--Select--")
        //         {
        //             SortedData = SortedData.Where(x => x.ContainerNo.Contains(container.Trim()));
        //         }


        //         //Searching data       
        //         //if (!string.IsNullOrEmpty(searchValue))
        //         //{
        //         //    string searchstring = "";
        //         //    foreach (string search in searchValue.Split('|', StringSplitOptions.RemoveEmptyEntries).ToList())
        //         //    {
        //         //        if (search == "UnAllocated")
        //         //        {
        //         //            searchValue = search;
        //         //        }
        //         //        else
        //         //        {
        //         //            key = search.Split('_')[0];
        //         //            value = search.Split('_')[1].Trim();

        //         //            if (key == "BookingNo")
        //         //            {
        //         //                if (value != "")
        //         //                    searchstring = searchstring + key + "=" + '"' + value + '"' + " && ";

        //         //            }
        //         //            if (key == "HBLNumber")
        //         //            {
        //         //                if (value != "")
        //         //                    searchstring = searchstring + key + "=" + '"' + value + '"' + " && ";

        //         //            }
        //         //        }
        //         //        if (searchstring != "")
        //         //        {
        //         //            //searchstring = searchstring.Trim().Substring(0, searchstring.Length - 3);
        //         //            //data = data.Where(searchstring.Trim());
        //         //            if (key=="HBLNumber")
        //         //            {
        //         //                SortedData = SortedData.Where(x => x.HBLNumber == value.Trim());
        //         //            }
        //         //            if(key=="BookingNo")
        //         //            {
        //         //                SortedData = SortedData.Where(x => x.BookingNo.Contains(value.Trim()));
        //         //            }                      

        //         //        }
        //         //    }
        //         //}


        //         if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
        //         {
        //             SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
        //         }
        //         var hblQuery = SortedData.Skip(skip).Take(pageSize == -1 ? 100 : pageSize).DistinctBy(x => x.BookingNo).ToList();
        //         var recordsTotal = data.Count();
        //         var recordsFiltered = data.Count();

        //         var returnObj = new
        //         {
        //             draw = draw,
        //             recordsTotal = recordsTotal,
        //             recordsFiltered = recordsFiltered,
        //             data = hblQuery,
        //         };

        //         return Json(returnObj);
        //     }

        [HttpPost]
        public IActionResult GetHBLs(string activity, string hblnumber, string bookingno, string filenumber, string container)
        {
            _context.Database.SetCommandTimeout(300); // Ensure you set the command timeout once.

            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            var searchValue = Request.Form["search[value]"].FirstOrDefault();
            int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "0");
            int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");

            DateTime threeMonthsAgo = DateTime.Now.AddMonths(-3);

            // Fetch data using IQueryable and only bring the necessary data to memory.
            var query = _context.HBLMaster
                .AsNoTracking() // Optimized for read-only access, no change tracking required.
                .Where(x => x.File.Etd >= threeMonthsAgo)  // Filter by ETD
                .Select(x => new
                {
                    x.Id,
                    x.HBLNumber,
                    x.Booking,
                    x.Container,
                    x.CustomerName,
                    x.EnterDate,
                    x.File.FileNumber,
                    x.File.Etd,
                    CountryName = x.File.Country.CountryName,
                    User = x.HBLActivityLogs.Select(y => y.ApplicationUser.UserName).FirstOrDefault(),
                    Status = x.HBLActivityLogs.Select(y => y.Status.Status).FirstOrDefault(),
                    Activity = x.HBLActivityLogs.Select(y => y.Activity.NameOfActivity).FirstOrDefault()
                })
                .AsQueryable();  // Keep it as IQueryable to apply filters/sorting/pagination efficiently.

            // Apply Filtering
            if (!string.IsNullOrEmpty(activity) && activity != "none" && activity != "--Select--")
                query = query.Where(x => x.Activity == activity.Trim());

            if (!string.IsNullOrEmpty(hblnumber) && hblnumber != "none" && hblnumber != "--Select--")
                query = query.Where(x => x.HBLNumber.Contains(hblnumber.Trim()));

            if (!string.IsNullOrEmpty(bookingno) && bookingno != "none" && bookingno != "--Select--")
                query = query.Where(x => x.Booking.Contains(bookingno.Trim()));

            if (!string.IsNullOrEmpty(filenumber) && filenumber != "none" && filenumber != "--Select--")
                query = query.Where(x => x.FileNumber.Contains(filenumber.Trim()));

            if (!string.IsNullOrEmpty(container) && container != "none" && container != "--Select--")
                query = query.Where(x => x.Container.Contains(container.Trim()));

            // Apply Searching (if required)
            //if (!string.IsNullOrEmpty(searchValue))
            //{
            //    query = query.Where(x => x.HBLNumber.Contains(searchValue) || x.Booking.Contains(searchValue) || x.Container.Contains(searchValue));
            //}

            // Apply Sorting
            if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
            {
                // Use reflection or a validated dynamic OrderBy approach to prevent SQL injection.
                query = query.OrderBy(sortColumn + " " + sortColumnDirection);
            }
            else
            {
                query = query.OrderByDescending(x => x.EnterDate); // Default sorting if not provided.
            }

            // Get total count before pagination
            int recordsTotal = query.Count();

            // Apply Pagination
            var pagedData = query.Skip(skip).Take(pageSize == -1 ? 100 : pageSize).ToList(); // Limiting to 100 for safety

            // Prepare the final response
            var returnObj = new
            {
                draw = draw,
                recordsTotal = recordsTotal,
                recordsFiltered = recordsTotal, // Adjust if filtering is performed differently.
                data = pagedData
            };

            return Json(returnObj);
        }


        [HttpGet]
        public IActionResult HBL(string fileNumber)
        {
			_context.Database.SetCommandTimeout(300);
			IEnumerable<HBLUserViewModel> data = null;

            if (fileNumber != null)
            {
                data = _context.HBLMaster.Include(x => x.File).Where(x => x.File.FileNumber == fileNumber).Select(x =>
                new HBLUserViewModel
                {
                    Id = x.Id,
                    FileNo = x.File.FileNumber,
                    BookingNo = x.Booking,
                    hblNo = x.HBLNumber,
                    CountryName = x.File.Country.CountryName,
                    CustomerName = x.CustomerName,

                });
            }
            else
            {
                data = _context.HBLMaster.Include(x => x.File).Select(x =>
                new HBLUserViewModel
                {
                    Id = x.Id,
                    FileNo = x.File.FileNumber,
                    BookingNo = x.Booking,
                    hblNo = x.HBLNumber,
                    CountryName = x.File.Country.CountryName,
                    CustomerName = x.CustomerName,
                });
            }
            //string activitytype = "";
            //if (data.FirstOrDefault().FileNo.Contains("GEX"))
            //{
            //    activitytype="LCL";
            //}
            //else
            //{
            //    activitytype="FCL";
            //}

            ViewBag.Activity = _context.ActivityMaster.Where(x => x.Source == "Upload").ToList();
            ViewBag.Status = _context.StatusMaster.ToList();
            ViewBag.Countries = _context.CountryMaster.ToList();
            return View(data);
        }

        [HttpGet]
        public IActionResult AllocatedHBL()
        {
            ViewBag.Activity = _context.ActivityMaster.Where(x => x.Source == "Upload").ToList();
            ViewBag.Status = _context.StatusMaster.ToList();
            return View();
        }

        //Allocate data by user assign HBL's
        [HttpPost]
        public IActionResult AllocatedHBL(string fileNumber)
        {
			_context.Database.SetCommandTimeout(300);

			int totalRecord = 0;
            int filterRecord = 0;
            int hblrecord = 0;
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            var searchValue = Request.Form["search[value]"].FirstOrDefault();
            int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "0");
            int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");
            var threeMonthsAgo = DateTime.Now.AddMonths(-3);

            List<HBLUserViewModel> hBLUserViewModel = new List<HBLUserViewModel>();
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            //if (fileNumber != null)
            //{
            //    hBLUserViewModel = _context.HBLMaster.Include(x => x.HBLActivityLogs.Where(y => y.Status.Status != "Completed")).Include(x => x.File).Where(x => x.File.FileNumber == fileNumber && x.File.Etd >= threeMonthsAgo).Select(x =>
            //        new HBLUserViewModel
            //        {
            //            Id = x.Id,
            //            FileNo = x.File.FileNumber,
            //            BookingNo = x.Booking,
            //            hblNo = x.HBLNumber,
            //            CountryName = x.File.Country.CountryName,
            //            CustomerName = x.CustomerName,
            //            Etd = x.File.Etd,

            //        }).ToList();
            //}
            //else
            //{
            //    //var activityid = _context.ActivityMaster.Where(x => x.NameOfActivity == "LCL BL Entry").Select(x => x.Id).FirstOrDefault();
            //    //hBLUserViewModel = _context.HBLActivityLog.Where(x => x.UserId == userid && x.ActivityId == activityid && x.Status.Status == "WIP").Include(x => x.Hbl).Select(x => new HBLUserViewModel
            //    hBLUserViewModel = _context.HBLActivityLog.Include(x => x.Hbl).ThenInclude(x => x.File).Where(x => x.UserId == userid && x.Status.Status == "WIP" && x.Hbl.File.Etd >= threeMonthsAgo).Select(x => new HBLUserViewModel
            //    {
            //        Id = x.HBLId,
            //        FileNo = x.Hbl.File.FileNumber,
            //        BookingNo = x.Hbl.Booking,
            //        hblNo = x.Hbl.HBLNumber,
            //        CountryName = x.Hbl.File.Country.CountryName,
            //        CustomerName = x.Hbl.CustomerName,
            //        Etd = x.Hbl.File.Etd
            //    }).DistinctBy(x => x.BookingNo).ToList();
            //}

            if (fileNumber != null)
            {
                // Fetching data from the database
                var hblMasterData = _context.HBLMaster
                    .Where(x => x.File.FileNumber == fileNumber && x.File.Etd >= threeMonthsAgo)
                    .Select(x => new
                    {
                        x.Id,
                        x.Booking,
                        x.HBLNumber,
                        x.CustomerName,
                        x.File.FileNumber,
                        x.File.Country.CountryName,
                        x.File.Etd,
                        ActivityLogStatus = x.HBLActivityLogs.FirstOrDefault(y => y.Status.Status != "Completed").Status.Status
                    })
                    .ToList(); // Materialize the query into memory

                // Filter and group in-memory
                hBLUserViewModel = hblMasterData
                    .Where(x => x.ActivityLogStatus != "Completed")
                    .GroupBy(x => new { x.Booking, x.HBLNumber })
                    .Select(g => g.First())
                    .Select(x => new HBLUserViewModel
                    {
                        Id = x.Id,
                        FileNo = x.FileNumber,
                        BookingNo = x.Booking,
                        hblNo = x.HBLNumber,
                        CountryName = x.CountryName,
                        CustomerName = x.CustomerName,
                        Etd = x.Etd,
                    })
                    .ToList();
            }
            else
            {
                // Fetching data from the database
                var hblActivityLogData = _context.HBLActivityLog
                    .Where(x => x.UserId == userid && x.Status.Status == "WIP" && x.Hbl.File.Etd >= threeMonthsAgo)
                    .Select(x => new
                    {
                        x.HBLId,
                        x.Hbl.Booking,
                        x.Hbl.HBLNumber,
                        x.Hbl.CustomerName,
                        x.Hbl.File.FileNumber,
                        x.Hbl.File.Country.CountryName,
                        x.Hbl.File.Etd
                    })
                    .ToList(); // Materialize the query into memory

                // Group in-memory
                hBLUserViewModel = hblActivityLogData
                    .GroupBy(x => new { x.Booking, x.HBLNumber })
                    .Select(g => g.First())
                    .Select(x => new HBLUserViewModel
                    {
                        Id = x.HBLId,
                        FileNo = x.FileNumber,
                        BookingNo = x.Booking,
                        hblNo = x.HBLNumber,
                        CountryName = x.CountryName,
                        CustomerName = x.CustomerName,
                        Etd = x.Etd,
                    })
                    .ToList();
            }

            IQueryable<HBLUserViewModel> SortedData = hBLUserViewModel.AsQueryable();

            if (!string.IsNullOrEmpty(fileNumber))
            {
                SortedData = SortedData.Where(x => x.FileNo == fileNumber.Trim());

            }

            if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
            {
                SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
            }

            //SortedData = SortedData.DistinctBy(x => x.BookingNo);

            var returnObj = new
            {
                draw = draw,
                recordsTotal = hBLUserViewModel.Count(),
                recordsFiltered = SortedData.Count(),
                data = SortedData,
            };
            return Json(returnObj);


        }


        [HttpPost]
        public IActionResult GetAllocatedFiles(DataTableAjaxPostModel model, string country, string fileNumber, string status, string activity)
        {
			_context.Database.SetCommandTimeout(300);
			var draw = model.draw;
            var sortColumn = string.IsNullOrEmpty(model.columns[model.order[0].column].data) ? "id" : model.columns[model.order[0].column].data;
            var sortColumnDirection = model.order[0].dir;
            var searchValue = model.search.value;
            int pageSize = model.length.HasValue ? model.length.Value : 100;
            int skip = model.start.HasValue ? model.start.Value : 0;
            var role = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Role);

            ViewBag.Status = _context.StatusMaster.ToList();

            if (role != "User")
            {  // Get the data for the DataTable
               //var data = _context.FileMaster.Include(x => x.Country).Include(x => x.FileActivityLogs).AsQueryable();
                var data = (from fa in _context.FileActivityLog
                            join fm in _context.FileMaster
                            on fa.FileId equals fm.Id
                            join am in _context.ActivityMaster
                            on fa.ActivityId equals am.Id
                            join um in _context.Users
                            on fa.UserId equals um.Id
                            select new FileDashModel
                            {
                                Id = fm.Id,
                                CountryName = fm.Country.CountryName,
                                DraftCutOff = fm.DraftCutoff,
                                ETD = fm.Etd,
                                FileNumber = fm.FileNumber,
                                ActivityId = am.NameOfActivity,
                                StatusId = fa.Status.Status,
                                Comment = fa.Comment,
                                UserId = um.UserName

                            });




                if (!string.IsNullOrEmpty(country) && country != "-- Select Country --")
                {
                    data = data.Where(x => x.CountryName.Contains(country));
                }
                if (!string.IsNullOrEmpty(fileNumber))
                {
                    data = data.Where(x => x.FileNumber.Contains(fileNumber));
                }
                if (!string.IsNullOrEmpty(status))
                {
                    data = data.Where(x => x.StatusId.Contains(status));
                }
                if (!string.IsNullOrEmpty(activity))
                {
                    data = data.Where(x => x.ActivityId.Contains(activity));
                }

                IEnumerable<FileDashModel> files = data.Select(
                    x => new FileDashModel
                    {
                        Id = x.Id,
                        CountryName = x.CountryName,
                        FileNumber = x.FileNumber,
                        ETD = x.ETD,
                        DraftCutOff = x.DraftCutOff,
                        ActivityId = x.ActivityId,
                        UserId = x.UserId,
                        StatusId = x.StatusId,
                        Comment = x.Comment,
                    }).OrderBy(sortColumn + " " + sortColumnDirection)
                   .Skip(skip)
                   .Take(pageSize).AsQueryable().ToList();
                return Json(new
                {
                    draw = model.draw,
                    recordsTotal = files.Count(),
                    recordsFiltered = files.Count(),
                    data = files
                });
            }
            else
            {
                // Get the data for the DataTable
                //var data = _context.FileMaster.Include(x => x.Country).Include(x => x.FileActivityLogs).AsQueryable();
                var data = _context.FileActivityLog
                          .Include(x => x.File)
                          .Include(x => x.Activity)
                          .Include(x => x.Status)
                          .Include(x => x.ApplicationUser)
                          .Where(x => x.ApplicationUser.UserName == User.Identity.Name)
                          .Select(x => new FileDashModel
                          {
                              Id = x.Activity.Id,
                              CountryName = x.File.Country.CountryName,
                              DraftCutOff = x.File.DraftCutoff,
                              ETD = x.File.Etd,
                              FileNumber = x.File.FileNumber,
                              ActivityId = x.Activity.NameOfActivity,
                              StatusId = x.Status.Status,
                              Comment = x.Comment,
                              UserId = x.ApplicationUser.UserName
                          });

                if (!string.IsNullOrEmpty(country) && country != "-- Select Country --")
                {
                    data = data.Where(x => x.CountryName.Contains(country));
                }
                if (!string.IsNullOrEmpty(fileNumber))
                {
                    data = data.Where(x => x.FileNumber.Contains(fileNumber));
                }
                if (!string.IsNullOrEmpty(status))
                {
                    data = data.Where(x => x.StatusId.Contains(status));
                }
                if (!string.IsNullOrEmpty(activity))
                {
                    data = data.Where(x => x.ActivityId.Contains(activity));
                }

                IEnumerable<FileDashModel> files = data.Select(
                    x => new FileDashModel
                    {
                        Id = x.Id,
                        CountryName = x.CountryName,
                        FileNumber = x.FileNumber,
                        ETD = x.ETD,
                        DraftCutOff = x.DraftCutOff,
                        ActivityId = x.ActivityId,
                        UserId = x.UserId,
                        StatusId = x.StatusId,
                        Comment = x.Comment,
                    }).OrderBy(sortColumn + " " + sortColumnDirection)
                   .Skip(skip)
                   .Take(pageSize).AsQueryable().ToList();
                return Json(new
                {
                    draw = model.draw,
                    recordsTotal = files.Count(),
                    recordsFiltered = files.Count(),
                    data = files
                });
            }

            // Return the data in the format required by DataTables

        }

        [HttpPost]
        public IActionResult GetFiles(DataTableAjaxPostModel model, string country, string fileNumber, string status, string activity)
        {
			_context.Database.SetCommandTimeout(300);
			var draw = model.draw;
            var sortColumn = string.IsNullOrEmpty(model.columns[model.order[0].column].data) ? "id" : model.columns[model.order[0].column].data;
            var sortColumnDirection = model.order[0].dir;
            var searchValue = model.search.value;
            int pageSize = model.length.HasValue ? model.length.Value : 100;
            int skip = model.start.HasValue ? model.start.Value : 0;
            var role = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Role);

            ViewBag.Status = _context.StatusMaster.ToList();

            if (role != "User")
            {  // Get the data for the DataTable               
                var data = (from fa in _context.FileActivityLog
                            join fm in _context.FileMaster
                            on fa.FileId equals fm.Id
                            join am in _context.ActivityMaster
                            on fa.ActivityId equals am.Id
                            join um in _context.Users
                            on fa.UserId equals um.Id
                            select new FileDashModel
                            {
                                Id = fm.Id,
                                CountryName = fm.Country.CountryName,
                                DraftCutOff = fm.DraftCutoff,
                                ETD = fm.Etd,
                                FileNumber = fm.FileNumber,
                                ActivityId = am.NameOfActivity,
                                StatusId = fa.Status.Status,
                                Comment = fa.Comment,
                                UserId = um.UserName

                            });

                if (!string.IsNullOrEmpty(country) && country != "-- Select Country --")
                {
                    data = data.Where(x => x.CountryName.Contains(country));
                }
                if (!string.IsNullOrEmpty(fileNumber))
                {
                    data = data.Where(x => x.FileNumber.Contains(fileNumber));
                }
                if (!string.IsNullOrEmpty(status))
                {
                    data = data.Where(x => x.StatusId.Contains(status));
                }
                if (!string.IsNullOrEmpty(activity))
                {
                    data = data.Where(x => x.ActivityId.Contains(activity));
                }

                IEnumerable<FileDashModel> files = data.Select(
                    x => new FileDashModel
                    {
                        Id = x.Id,
                        CountryName = x.CountryName,
                        FileNumber = x.FileNumber,
                        ETD = x.ETD,
                        DraftCutOff = x.DraftCutOff,
                        ActivityId = x.ActivityId,
                        UserId = x.UserId,
                        StatusId = x.StatusId,
                        Comment = x.Comment,
                    }).OrderBy(sortColumn + " " + sortColumnDirection)
                   .Skip(skip)
                   .Take(pageSize).AsQueryable().ToList();
                return Json(new
                {
                    draw = model.draw,
                    recordsTotal = files.Count(),
                    recordsFiltered = files.Count(),
                    data = files
                });
            }
            else
            {
                // Get the data for the DataTable
                //var data = _context.FileMaster.Include(x => x.Country).Include(x => x.FileActivityLogs).AsQueryable();
                var data = _context.FileActivityLog
                          .Include(x => x.File)
                          .Include(x => x.Activity)
                          .Include(x => x.Status)
                          .Include(x => x.ApplicationUser)
                          .Where(x => x.ApplicationUser.UserName == User.Identity.Name)
                          .Select(x => new FileDashModel
                          {
                              Id = x.Activity.Id,
                              CountryName = x.File.Country.CountryName,
                              DraftCutOff = x.File.DraftCutoff,
                              ETD = x.File.Etd,
                              FileNumber = x.File.FileNumber,
                              ActivityId = x.Activity.NameOfActivity,
                              StatusId = x.Status.Status,
                              Comment = x.Comment,
                              UserId = x.ApplicationUser.UserName
                          });

                if (!string.IsNullOrEmpty(country) && country != "-- Select Country --")
                {
                    data = data.Where(x => x.CountryName.Contains(country));
                }
                if (!string.IsNullOrEmpty(fileNumber))
                {
                    data = data.Where(x => x.FileNumber.Contains(fileNumber));
                }
                if (!string.IsNullOrEmpty(status))
                {
                    data = data.Where(x => x.StatusId.Contains(status));
                }
                if (!string.IsNullOrEmpty(activity))
                {
                    data = data.Where(x => x.ActivityId.Contains(activity));
                }

                IEnumerable<FileDashModel> files = data.Select(
                    x => new FileDashModel
                    {
                        Id = x.Id,
                        CountryName = x.CountryName,
                        FileNumber = x.FileNumber,
                        ETD = x.ETD,
                        DraftCutOff = x.DraftCutOff,
                        ActivityId = x.ActivityId,
                        UserId = x.UserId,
                        StatusId = x.StatusId,
                        Comment = x.Comment,
                    }).OrderBy(sortColumn + " " + sortColumnDirection)
                   .Skip(skip)
                   .Take(pageSize).AsQueryable().ToList();
                return Json(new
                {
                    draw = model.draw,
                    recordsTotal = files.Count(),
                    recordsFiltered = files.Count(),
                    data = files
                });
            }

            // Return the data in the format required by DataTables

        }


        public IActionResult Adhoc()
        {
            //ViewBag.ActivityMaster = _context.ActivityMaster.ToList();
            ViewBag.Countries = _context.CountryMaster.ToList();
            return View();

        }

        [HttpGet]
        public IActionResult AdhocFileActivity()
        {
            //ViewData["fileId"] = Id;
            //ViewData["fileDtls"] = _context.FileMaster.Where(x => x.Id == Id).Include(x => x.Country).FirstOrDefault();

            //ViewData["FileActivityList"] = _context.FileActivityLog.Where(x => x.FileId == Id)
            //                                            .Include(x => x.Activity).Include(x => x.Status).Include(x => x.ApplicationUser)
            //                                            .Select(x => new FileActivityLogModel
            //                                            {
            //                                                Id = x.Id,
            //                                                FileId = x.File.Id,
            //                                                ActivityId = x.ActivityId,
            //                                                ActivityName = x.Activity.NameOfActivity,
            //                                                StatusId = x.StatusId,
            //                                                StatusName = x.Status.Status,
            //                                                UserId = x.UserId,
            //                                                UserName = x.ApplicationUser.UserName,
            //                                                Comment = x.Comment,
            //                                                StartDate = x.StartDate,
            //                                                EndDate = x.EndDate,
            //                                            }).ToList();

            ViewBag.Countries = _context.CountryMaster.ToList();
            ViewBag.Activity = _context.ActivityMaster.Where(x => x.Source == "Adhoc").ToList();
            ViewBag.Status = _context.StatusMaster.ToList();

            return PartialView();
        }

        [HttpPost]
        public IActionResult AdhocFileActivity(AdhocFileActivityModel adhocfileActivity)
        {
			_context.Database.SetCommandTimeout(300);
			if (ModelState.IsValid)
            {
                AdhocFile adhocfile = _context.AdhocFile.Where(x => x.AdhocFileNumber == adhocfileActivity.AdhocFileNumber.ToUpper().Trim()).FirstOrDefault();

                if (adhocfile == null)
                {
                    adhocfile = new AdhocFile
                    {
                        Id = adhocfileActivity.Id,
                        CountryId = adhocfileActivity.CountryId,
                        AdhocFileNumber = adhocfileActivity.AdhocFileNumber.ToUpper().Trim(),
                        AdhocContainer = adhocfileActivity.AdhocContainer.ToUpper().Trim(),
                        EnterDate = DateTime.UtcNow,
                        IsActive = true,
                        IsDelete = false
                    };
                    _context.AdhocFile.Add(adhocfile);
                }


                foreach (AdhocFileActivityLogItem log in adhocfileActivity.AdhocFileActivities)
                {
                    _context.AdhocFileActivityLog.Add(new AdhocFileActivityLog
                    {
                        Id = log.Id,
                        AdhocFileId = adhocfile.Id,
                        ActivityId = log.ActivityId,
                        StatusId = log.StatusId,
                        Comment = log.Comment,
                        UserId = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier),
                        StartDate = DateTime.UtcNow,
                        EndDate = DateTime.UtcNow,
                    });

                }
                _context.SaveChanges();

                return Json(adhocfileActivity.Id);
            }
            else
            {
                return Json("Something went wrong");
            }
        }

        [HttpGet]
        public IActionResult AdhocHBLActivity()
        {
            ViewBag.Countries = _context.CountryMaster.ToList();
            ViewBag.Activity = _context.ActivityMaster.Where(x => x.Source == "Adhoc").ToList();
            ViewBag.Status = _context.StatusMaster.ToList();

            return PartialView();
        }

        [HttpPost]
        public IActionResult AdhocHBLActivity(AdhocHBLActivityModel adhocHBLActivity)
        {
			_context.Database.SetCommandTimeout(300);
			if (ModelState.IsValid)
            {
                AdhocHBL adhochbl = _context.AdhocHBL.Where(x => x.AdhocBooking == adhocHBLActivity.AdhocBooking.ToUpper().Trim() || x.AdhocHBLNumber == adhocHBLActivity.AdhocHBLNumber.ToUpper().Trim()).FirstOrDefault();

                if (adhochbl == null)
                {
                    adhochbl = new AdhocHBL
                    {
                        Id = adhocHBLActivity.Id,
                        AdhocCountryId = adhocHBLActivity.AdhocCountryId,
                        AdhocBooking = adhocHBLActivity.AdhocBooking.ToUpper().Trim(),
                        AdhocHBLNumber = adhocHBLActivity.AdhocHBLNumber.ToUpper().Trim(),
                        //AdhocFileNumber = adhocHBLActivity.AdhocFileNumber,
                        //AdhocContainer = adhocHBLActivity.AdhocContainer,
                        EnterDate = DateTime.UtcNow,
                        IsActive = true,
                        IsDelete = false

                    };
                    _context.AdhocHBL.Add(adhochbl);
                }

                foreach (AdhocHBLActivityLogItem log in adhocHBLActivity.AdhocHBLActivities)
                {
                    _context.AdhocHBLActivityLog.Add(new AdhocHBLActivityLog
                    {
                        Id = log.Id,
                        AdhocHBLId = adhochbl.Id,
                        ActivityId = log.ActivityId,
                        StatusId = log.StatusId,
                        Comment = log.Comment,
                        UserId = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier),
                        StartDate = DateTime.UtcNow,
                        EndDate = DateTime.UtcNow,
                    });

                }
                _context.SaveChanges();

                return Json(adhocHBLActivity.Id);
            }
            else
            {
                return Json("Something went wrong");
            }
        }

        [HttpPost]
        //public IActionResult GetAdhocFiles(DataTableAjaxPostModel model, string country, string fileNumber, string container)
        public IActionResult GetAdhocFiles(DataTableAjaxPostModel model, string country, string fileNumber, string container)
        {
			_context.Database.SetCommandTimeout(300);
			var draw = model.draw;
            var sortColumn = string.IsNullOrEmpty(model.columns[model.order[0].column].data) ? "id" : model.columns[model.order[0].column].data;
            var sortColumnDirection = model.order[0].dir;
            var searchValue = model.search.value;
            int pageSize = model.length.HasValue ? model.length.Value : 10;
            int skip = model.start.HasValue ? model.start.Value : 0;

            // Get the data for the DataTable
            var data = _context.AdhocFileActivityLog
            .Join(_context.AdhocFile, fileActivity => fileActivity.AdhocFileId, fileMaster => fileMaster.Id, (fileActivity, fileMaster) => new { fileActivity, fileMaster })
            .Join(_context.ActivityMaster, activityJoin => activityJoin.fileActivity.ActivityId, activityMaster => activityMaster.Id, (activityJoin, activityMaster) => new { activityJoin, activityMaster })
            .Join(_context.StatusMaster, statusjoin => statusjoin.activityJoin.fileActivity.StatusId, statusMaster => statusMaster.Id, (statusjoin, statusMaster) => new { statusjoin, statusMaster })
            .Join(_context.CountryMaster, countryjoin => countryjoin.statusjoin.activityJoin.fileMaster.CountryId, countryMaster => countryMaster.Id, (countryjoin, countryMaster) => new { countryjoin, countryMaster })
            .Join(_context.Users, userjoin => userjoin.countryjoin.statusjoin.activityJoin.fileActivity.ApplicationUser.Id, User => User.Id, (userjoin, User) => new
            AdhocFileDashModel
            {

                Id = userjoin.countryjoin.statusjoin.activityJoin.fileMaster.Id,
                CountryName = userjoin.countryMaster.CountryName,
                FileNumber = userjoin.countryjoin.statusjoin.activityJoin.fileMaster.AdhocFileNumber,
                Container = userjoin.countryjoin.statusjoin.activityJoin.fileMaster.AdhocContainer,
                LastActivityPerformed = userjoin.countryjoin.statusjoin.activityMaster.NameOfActivity,
                LastActivityStatus = userjoin.countryjoin.statusMaster.Status,
                LastProcessedDate = userjoin.countryjoin.statusjoin.activityJoin.fileActivity.EndDate,
                LastFileHandler = User.UserName
                //Comment = countryjoin.statusjoin.activityJoin.fileActivity.Comment,
            })
            .GroupBy(x => x.FileNumber)
            .Select(group => group.OrderByDescending(x => x.LastProcessedDate).First()).ToList().AsQueryable();

            if (!string.IsNullOrEmpty(country) && country != "-- Select Country --")
            {
                data = data.Where(x => x.CountryName.Contains(country));
            }
            if (!string.IsNullOrEmpty(fileNumber))
            {
                data = data.Where(x => x.FileNumber.Contains(fileNumber));
            }
            if (!string.IsNullOrEmpty(container))
            {
                data = data.Where(x => x.Container.Contains(container));
            }
            int filteredrecords = data.Count();

            List<AdhocFileDashModel> files = data.Select(
                x => new AdhocFileDashModel
                {
                    Id = x.Id,
                    CountryName = x.CountryName,
                    FileNumber = x.FileNumber,
                    Container = x.Container,
                    LastActivityPerformed = x.LastActivityPerformed,
                    LastActivityStatus = x.LastActivityStatus,
                    LastProcessedDate = x.LastProcessedDate,
                }).OrderBy(sortColumn + " " + sortColumnDirection)
               .Skip(skip)
               .Take(pageSize == -1 ? 10 : pageSize).AsQueryable().ToList();


            // Return the data in the format required by DataTables
            return Json(new
            {
                draw = model.draw,
                recordsTotal = data.Count(),
                recordsFiltered = filteredrecords,
                data = files
            });

        }

        [HttpPost]
        //public IActionResult GetAdhocHBLs(DataTableAjaxPostModel model, string country, string fileNumber, string container)
        public IActionResult GetAdhocHBLs(DataTableAjaxPostModel model, string country, string booking, string hblNumber)
        {
			_context.Database.SetCommandTimeout(300);
			var draw = model.draw;
            var sortColumn = string.IsNullOrEmpty(model.columns[model.order[0].column].data) ? "id" : model.columns[model.order[0].column].data;
            var sortColumnDirection = model.order[0].dir;
            var searchValue = model.search.value;
            int pageSize = model.length.HasValue ? model.length.Value : 10;
            int skip = model.start.HasValue ? model.start.Value : 0;

            // Get the data for the DataTable
            var data = _context.AdhocHBLActivityLog
            .Join(_context.AdhocHBL, hblActivity => hblActivity.AdhocHBLId, hblMaster => hblMaster.Id, (hblActivity, hblMaster) => new { hblActivity, hblMaster })
            .Join(_context.ActivityMaster, activityJoin => activityJoin.hblActivity.ActivityId, activityMaster => activityMaster.Id, (activityJoin, activityMaster) => new { activityJoin, activityMaster })
            .Join(_context.StatusMaster, statusjoin => statusjoin.activityJoin.hblActivity.StatusId, statusMaster => statusMaster.Id, (statusjoin, statusMaster) => new { statusjoin, statusMaster })
            .Join(_context.CountryMaster, countryjoin => countryjoin.statusjoin.activityJoin.hblMaster.AdhocCountryId, countryMaster => countryMaster.Id, (countryjoin, countryMaster) => new { countryjoin, countryMaster })
            .Join(_context.Users, userjoin => userjoin.countryjoin.statusjoin.activityJoin.hblActivity.ApplicationUser.Id, User => User.Id, (userjoin, User) => new
            AdhocHBLDashModel
            {

                Id = userjoin.countryjoin.statusjoin.activityJoin.hblMaster.Id,
                CountryName = userjoin.countryMaster.CountryName,
                HBLNo = userjoin.countryjoin.statusjoin.activityJoin.hblMaster.AdhocHBLNumber,
                BookingNo = userjoin.countryjoin.statusjoin.activityJoin.hblMaster.AdhocBooking,
                LastActivityPerformed = userjoin.countryjoin.statusjoin.activityMaster.NameOfActivity,
                LastActivityStatus = userjoin.countryjoin.statusMaster.Status,
                LastProcessedDate = userjoin.countryjoin.statusjoin.activityJoin.hblActivity.EndDate,
                LastHBLHandler = User.UserName
                //Comment = countryjoin.statusjoin.activityJoin.hblActivity.Comment,
            })
            .GroupBy(x => x.HBLNo)
            .Select(group => group.OrderByDescending(x => x.LastProcessedDate).First()).ToList().AsQueryable();

            if (!string.IsNullOrEmpty(country) && country != "--Select--")
            {
                data = data.Where(x => x.CountryName.Contains(country));
            }
            if (!string.IsNullOrEmpty(booking))
            {
                data = data.Where(x => x.BookingNo.Contains(booking));
            }
            if (!string.IsNullOrEmpty(hblNumber))
            {
                data = data.Where(x => x.HBLNo.Contains(hblNumber));
            }

            int filteredrecords = data.Count();

            List<AdhocHBLDashModel> files = data.Select(
                x => new AdhocHBLDashModel
                {
                    Id = x.Id,
                    CountryName = x.CountryName,
                    BookingNo = x.BookingNo,
                    HBLNo = x.HBLNo,
                    LastActivityPerformed = x.LastActivityPerformed,
                    LastActivityStatus = x.LastActivityStatus,
                    LastProcessedDate = x.LastProcessedDate,
                }).OrderBy(sortColumn + " " + sortColumnDirection)
               .Skip(skip)
               .Take(pageSize == -1 ? 10 : pageSize).AsQueryable().ToList();

            // Return the data in the format required by DataTables
            return Json(new
            {
                draw = model.draw,
                recordsTotal = data.Count(),
                recordsFiltered = filteredrecords,
                data = files
            });
        }

        [HttpGet]
        public IActionResult GetFileActivityData(string Id)
        {
			_context.Database.SetCommandTimeout(300);
			var adhocFile = _context.AdhocFileActivityLog.Where(fileActivity => fileActivity.AdhocFile.Id == Id)
            .Join(_context.ActivityMaster, activityJoin => activityJoin.ActivityId, activityMaster => activityMaster.Id, (activityJoin, activityMaster) => new { activityJoin, activityMaster })
            .Join(_context.StatusMaster, statusjoin => statusjoin.activityJoin.StatusId, statusMaster => statusMaster.Id, (statusjoin, statusMaster) => new { statusjoin, statusMaster })
            .Join(_context.Users, userjoin => userjoin.statusjoin.activityJoin.ApplicationUser.Id, User => User.Id, (userjoin, User) => new
            {

                Id = userjoin.statusjoin.activityMaster.Id,
                ActivityName = userjoin.statusjoin.activityMaster.NameOfActivity,
                Status = userjoin.statusMaster.Status,
                ProcessedDate = userjoin.statusjoin.activityJoin.EndDate,
                User = User.UserName,
                Comment = userjoin.statusjoin.activityJoin.Comment == null ? "" : userjoin.statusjoin.activityJoin.Comment,
            }).OrderByDescending(x => x.ProcessedDate).ToList().AsQueryable();

            return Json(new { adhocFile });
        }

        [HttpGet]
        public IActionResult GetHBLActivityData(string Id)
        {
			_context.Database.SetCommandTimeout(300);
			var adhocHBL = _context.AdhocHBLActivityLog.Where(fileActivity => fileActivity.AdhocHBLId == Id)
            .Join(_context.ActivityMaster, activityJoin => activityJoin.ActivityId, activityMaster => activityMaster.Id, (activityJoin, activityMaster) => new { activityJoin, activityMaster })
            .Join(_context.StatusMaster, statusjoin => statusjoin.activityJoin.StatusId, statusMaster => statusMaster.Id, (statusjoin, statusMaster) => new { statusjoin, statusMaster })
            .Join(_context.Users, userjoin => userjoin.statusjoin.activityJoin.ApplicationUser.Id, User => User.Id, (userjoin, User) => new
            {

                Id = userjoin.statusjoin.activityMaster.Id,
                ActivityName = userjoin.statusjoin.activityMaster.NameOfActivity,
                Status = userjoin.statusMaster.Status,
                ProcessedDate = userjoin.statusjoin.activityJoin.EndDate,
                User = User.UserName,
                Comment = userjoin.statusjoin.activityJoin.Comment == null ? "" : userjoin.statusjoin.activityJoin.Comment,
            }).OrderByDescending(x => x.ProcessedDate).ToList().AsQueryable();


            return Json(new { adhocHBL });
        }

        [HttpGet]
        public IActionResult GetHBLActivity(string Id)
        {
            var HBL = _context.HBLActivityLog.Where(x => x.HBLId == Id)
            .Include(activity => activity.Activity)
            .Include(status => status.Status)
            .Include(user => user.ApplicationUser)
            .Select(x => new
            {
                Id = x.Activity.Id,
                ActivityName = x.Activity.NameOfActivity,
                Status = x.Status.Status,
                ProcessedDate = x.EndDate,
                User = x.ApplicationUser.UserName,
                Comment = x.Comment == null ? "" : x.Comment,
            })
           .OrderByDescending(x => x.ProcessedDate).ToList().AsQueryable()
           .ToList();


            //var HBL = _context.HBLActivityLog.Where(fileActivity => fileActivity.HBLId == Id)
            //.Join(_context.ActivityMaster, activityJoin => activityJoin.ActivityId, activityMaster => activityMaster.Id, (activityJoin, activityMaster) => new { activityJoin, activityMaster })
            //.Join(_context.StatusMaster, statusjoin => statusjoin.activityJoin.StatusId, statusMaster => statusMaster.Id, (statusjoin, statusMaster) => new { statusjoin, statusMaster })
            //.Join(_context.Users, userjoin => userjoin.statusjoin.activityJoin.ApplicationUser.Id, User => User.Id, (userjoin, User) => new
            //{

            //    Id = userjoin.statusjoin.activityMaster.Id,
            //    ActivityName = userjoin.statusjoin.activityMaster.NameOfActivity,
            //    Status = userjoin.statusMaster.Status,
            //    ProcessedDate = userjoin.statusjoin.activityJoin.EndDate,
            //    User = User.UserName,
            //    Comment = userjoin.statusjoin.activityJoin.Comment == null ? "": userjoin.statusjoin.activityJoin.Comment,
            //}).OrderByDescending(x => x.ProcessedDate).ToList().AsQueryable();

            return Json(new { HBL });
        }
        // Add hbl activities 
        [HttpPost]
        public JsonResult AddHblActivities(HBLActivityLogViewModel model)
        {
			_context.Database.SetCommandTimeout(300);

			var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var ActivityId = _context.ActivityMaster.Where(x => x.NameOfActivity == "LCL BL Entry").Select(x => x.Id).FirstOrDefault();
            var StatusId = _context.StatusMaster.Where(x => x.Status == "WIP").Select(x => x.Id).FirstOrDefault();
            if (model.ActivityId == null)
            {
                return Json("Please select activitiy");
            }
            else if (model.StatusId == null)
            {
                return Json("Please select status");
            }
            else
            {               
                //FCL Confirm on Board and LCL Confirm on Board 
                if (model.ActivityId == "f1a535dc-d58e-4565-87b0-3088cfe5281e" || model.ActivityId == "bce2316c-8d6d-41e4-a7d6-5c8aae93739f" || model.ActivityId == "88c153ce-82de-435b-a6d8-91b2c3377031" || model.ActivityId == "7c8f0c63-de3f-4108-bbdf-579160c48ba0" ||
                    model.ActivityId == "41434445-44a7-4fed-906c-68723ba983f5" || model.ActivityId == "5737d467-0988-438f-9d35-7f2967fe7e1b")
                {
                    var containers = _context.HBLMaster.Where(x => x.Container == model.Container.Trim()).ToList();

                    foreach (var container in containers)
                    {
                        var hbllog = _context.HBLActivityLog.Where(x => x.HBLId == container.Id && x.ActivityId == model.ActivityId).FirstOrDefault();

                        if (hbllog == null)
                        {
                            _context.HBLActivityLog.Add(new HBLActivityLog
                            {
                                HBLId = container.Id,
                                ActivityId = model.ActivityId,
                                StatusId = model.StatusId,
                                UserId = userid,
                                StartDate = model.StartDate,                                
                                Comment = model.Comment,
                                AES_UN = model.AES_UN,
                                QUOTE_NUMBER = model.QUOTE_NUMBER,
                                MblNumber = model.MblNumber,
                                EndDate = DateTime.UtcNow
                            });
                            _context.SaveChanges();
                        }
                        else
                        {
                            if (hbllog != null)
                            {
                                //var hblstatus = _context.StatusMaster.Where(x => x.Status == "Completed").Select(x => x.Id).FirstOrDefault();

                                //if (hbllog.UserId == userid)
                                //{
                                hbllog.ActivityId = model.ActivityId;
                                hbllog.StatusId = model.StatusId;
                                hbllog.UserId = userid;
                                //if (model.ActivityId == ActivityId && model.StatusId == StatusId)
                                //{
                                    hbllog.StartDate = model.StartDate;
                                //}

                                hbllog.Comment = model.Comment;
                                hbllog.QUOTE_NUMBER = model.QUOTE_NUMBER;
                                hbllog.MblNumber = model.MblNumber;
                                //if (hbllog.AES_UN == null)
                                //{
                                //    hbllog.AES_UN = model.AES_UN;
                                //}
                                hbllog.AES_UN = model.AES_UN;

                                hbllog.EndDate = DateTime.UtcNow;

                                _context.HBLActivityLog.Update(hbllog);
                                _context.SaveChanges();

                                _context.HBLActivitylogHistory.Add(new HBLActivitylogHistory
                                {
                                    HBLogId = hbllog.Id,
                                    ActivityId = hbllog.ActivityId,
                                    StatusId = hbllog.StatusId,
                                    Comment = hbllog.Comment,
                                    UserId = hbllog.UserId,
                                    StartDate = hbllog.StartDate,
                                    EndDate = hbllog.EndDate,
                                });

                                _context.SaveChanges();
                                //}
                            }
                        }
                    }

                    return Json("Success");
                }
                else
                {
                    var hbllog = _context.HBLActivityLog.Where(x => x.HBLId == model.HblId && x.ActivityId == model.ActivityId).FirstOrDefault();

                    if (ModelState.IsValid)
                    {
                        if (hbllog == null)
                        {
                            _context.HBLActivityLog.Add(new HBLActivityLog
                            {
                                HBLId = model.HblId,
                                ActivityId = model.ActivityId,
                                StatusId = model.StatusId,
                                UserId = userid,
                                StartDate = model.StartDate,
                                EndDate = DateTime.UtcNow,
                                Comment = model.Comment,
                                AES_UN = model.AES_UN,
                                QUOTE_NUMBER = model.QUOTE_NUMBER,
                                MblNumber = model.MblNumber
                            });

                            _context.SaveChanges();
                        }
                        else
                        {
                            // var hbllog = _context.HBLActivityLog.FirstOrDefault(x => x.Id == hbllog.Id);

                            if (hbllog != null)
                            {
                                var hblstatus = _context.StatusMaster.Where(x => x.Status == "Completed").Select(x => x.Id).FirstOrDefault();

                                if (hbllog.StatusId == hblstatus && hbllog.UserId != userid)
                                {
                                    return Json("HBL status is aleredy completed");
                                }
                                else
                                {
                                    if (hbllog.UserId == userid)
                                    {
                                        hbllog.ActivityId = model.ActivityId;
                                        hbllog.StatusId = model.StatusId;
                                        hbllog.UserId = userid;
                                        //hbllog.StartDate = model.StartDate;    
                                        if (model.ActivityId == ActivityId && model.StatusId == StatusId)
                                        {
                                            hbllog.StartDate = model.StartDate;
                                        }
                                        hbllog.Comment = model.Comment;
                                        hbllog.QUOTE_NUMBER = model.QUOTE_NUMBER;
                                        hbllog.MblNumber = model.MblNumber;
                                        if (hbllog.AES_UN == null)
                                        {
                                            hbllog.AES_UN = model.AES_UN;
                                        }
                                        hbllog.EndDate = DateTime.UtcNow;

                                        _context.HBLActivityLog.Update(hbllog);
                                        _context.SaveChanges();

                                        _context.HBLActivitylogHistory.Add(new HBLActivitylogHistory
                                        {
                                            HBLogId = hbllog.HBLId,
                                            ActivityId = hbllog.ActivityId,
                                            StatusId = hbllog.StatusId,
                                            Comment = hbllog.Comment,
                                            UserId = userid,
                                            StartDate = hbllog.StartDate,
                                            EndDate = DateTime.UtcNow,
                                        });
                                        _context.SaveChanges();
                                    }
                                    else
                                    {
                                        return Json("You have not allowed to update");
                                    }

                                }
                            }
                        }

                        return Json("Success");
                    }
                    else
                    {
                        return Json("Error while processing the request");
                    }

                }
            }
        }

        [HttpGet]
        public IActionResult CreateFile()
        {
            ViewBag.Countries = _context.CountryMaster.ToList();
            ViewBag.Activity = _context.ActivityMaster.Where(x => x.Source == "Upload").ToList();
            ViewBag.Status = _context.StatusMaster.ToList();

            return PartialView();
        }
        [HttpPost]
        public IActionResult AddFileNewActivity(FileAddActivityLogModel file)
        {
			_context.Database.SetCommandTimeout(300);
			if (ModelState.IsValid)
            {
                FileMaster fileMaster = _context.FileMaster.Where(x => x.FileNumber == file.FileNumber.ToUpper().Trim()).FirstOrDefault();

                if (fileMaster == null)
                {
                    fileMaster = new FileMaster
                    {
                        Id = file.Id,
                        CountryId = file.CountryId,
                        FileNumber = file.FileNumber.ToUpper().Trim(),
                        Etd = file.ETD,
                        DraftCutoff = file.DraftCutOff,
                        EnterDate = DateTime.UtcNow,
                        IsActive = true,
                        IsDelete = false
                    };
                    _context.FileMaster.Add(fileMaster);
                }

                foreach (FileActivityLogItem log in file.FileActivities)
                {
                    _context.FileActivityLog.Add(new FileActivityLog
                    {
                        Id = log.Id,
                        FileId = fileMaster.Id,
                        ActivityId = log.ActivityId,
                        StatusId = log.StatusId,
                        Comment = log.Comment,
                        UserId = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier),
                        StartDate = DateTime.UtcNow,
                        EndDate = DateTime.UtcNow,
                    });
                }

                _context.SaveChanges();

                return Json(file.Id);
            }
            else
            {
                return Json("Something went wrong");
            }
        }

        [HttpGet]
        public IActionResult CreateHBL()
        {
            ViewBag.Countries = _context.CountryMaster.ToList();
            ViewBag.Activity = _context.ActivityMaster.Where(x => x.Source == "Upload").ToList();
            ViewBag.Status = _context.StatusMaster.ToList();

            return PartialView();
        }

        // Add new hbl activity
        [HttpPost]
        public IActionResult AddNewHBLActivity(HBLUserViewModel hbl)
        {
			_context.Database.SetCommandTimeout(300);
			string Msg = "";
            if (ModelState.IsValid)
            {
                var file = _context.FileMaster.Where(x => x.FileNumber == hbl.FileNo.ToUpper().Trim()).FirstOrDefault();

                if (file == null)
                {
                    _context.FileMaster.Add(new FileMaster
                    {
                        FileNumber = hbl.FileNo,
                        CountryId = hbl.CountryId,
                        EnterDate = DateTime.UtcNow
                    });
                    _context.SaveChanges();

                    HBLMaster hblMaster = _context.HBLMaster.Where(x => x.HBLNumber == hbl.hblNo.ToUpper().Trim()).FirstOrDefault();

                    if (hblMaster == null)
                    {
                        hblMaster = new HBLMaster
                        {
                            Id = hbl.Id,
                            HBLNumber = hbl.hblNo,
                            FileId = _context.FileMaster.Where(x => x.FileNumber == hbl.FileNo.ToUpper().Trim()).Select(x => x.Id).FirstOrDefault(),
                            Container = hbl.Container,
                            Booking = hbl.BookingNo,
                            CustomerName = hbl.CustomerName,
                            EnterDate = DateTime.UtcNow,
                            IsActive = true,
                            IsDelete = false
                        };
                        _context.HBLMaster.Add(hblMaster);
                        _context.SaveChanges();
                        Msg = "HBL Inserted Successfully..!!";
                    }
                    else
                    {
                        Msg = "HBL no is already added";
                    }

                }
                else
                {
                    HBLMaster hblMaster = _context.HBLMaster.Where(x => x.HBLNumber == hbl.hblNo.ToUpper().Trim()).FirstOrDefault();

                    if (hblMaster == null)
                    {
                        hblMaster = new HBLMaster
                        {
                            Id = hbl.Id,
                            HBLNumber = hbl.hblNo,
                            FileId = _context.FileMaster.Where(x => x.FileNumber == hbl.FileNo.ToUpper().Trim()).Select(x => x.Id).FirstOrDefault(),
                            Container = hbl.Container,
                            Booking = hbl.BookingNo,
                            CustomerName = hbl.CustomerName,
                            EnterDate = DateTime.UtcNow,
                            IsActive = true,
                            IsDelete = false
                        };
                        _context.HBLMaster.Add(hblMaster);
                        _context.SaveChanges();
                        Msg = "HBL Inserted Successfully..!!";
                    }
                    else
                    {
                        Msg = "HBL no is already added";
                    }

                    //foreach (HBLActivityLogs log in hbl.HBLActivities)
                    //{
                    //    _context.HBLActivityLog.Add(new HBLActivityLog
                    //    {
                    //        Id = log.Id,
                    //        HBLId = hbl.Id,
                    //        ActivityId = log.ActivityId,
                    //        StatusId = log.StatusId,
                    //        Comment = log.Comment,
                    //        UserId = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier),
                    //        StartDate = DateTime.UtcNow,
                    //        EndDate = DateTime.UtcNow,
                    //    });
                    //}

                }
                return Json(Msg);

            }
            else
            {
                return Json("Error while processing the request");

            }
        }
        //Insert Files
        [HttpGet]
        public IActionResult InsertFile()
        {
			_context.Database.SetCommandTimeout(300);
			ViewBag.Countries = _context.CountryMaster.ToList();
            ViewBag.Activity = _context.ActivityMaster.Where(x => x.Source == "Upload").ToList();
            ViewBag.Status = _context.StatusMaster.ToList();

            return PartialView();
        }

        public IActionResult InsertNewFile(FileInsertModel file)
        {
			_context.Database.SetCommandTimeout(300);
			if (ModelState.IsValid)
            {
                FileMaster fileMaster = _context.FileMaster.Where(x => x.FileNumber == file.FileNumber.ToUpper().Trim()).FirstOrDefault();

                if (fileMaster == null)
                {
                    fileMaster = new FileMaster
                    {
                        Id = file.Id,
                        CountryId = file.CountryId,
                        FileNumber = file.FileNumber.ToUpper().Trim(),
                        Etd = file.ETD,
                        DraftCutoff = file.DraftCutOff,
                        EnterDate = DateTime.UtcNow,
                        IsActive = true,
                        IsDelete = false
                    };
                    _context.FileMaster.Add(fileMaster);
                }
                _context.SaveChanges();

                return Json(file.Id);
            }
            else
            {
                return Json("Something went wrong");

            }
        }

        public IActionResult FileQuery()
        {
			_context.Database.SetCommandTimeout(300);
			ViewBag.StatusMaster = _context.StatusMaster.OrderBy(x => x.Status).ToList();
            ViewBag.ActivityMaster = _context.ActivityMaster.OrderBy(x => x.NameOfActivity).Where(x => x.Source == "Upload").ToList();
            ViewBag.Countries = _context.CountryMaster.OrderBy(x => x.CountryName).ToList();
            return View();

        }

        [HttpGet]
        public IActionResult GetfileData(string fileNumber)
        {
			_context.Database.SetCommandTimeout(300);
			var hbl = _context.HBLMaster.Where(x => x.File.FileNumber == fileNumber).ToList();
            var file = _context.FileMaster.Where(x => x.FileNumber == fileNumber).Select(x => new { x.Id }).FirstOrDefault();
            var sm = _context.StatusMaster.ToList();

            var fm = _context.FileActivityLog.Include(x => x.File).Include(x => x.Activity).Include(x => x.Status).Include(x => x.ApplicationUser).Where(x => x.FileId == file.Id).ToList();
            IQueryable<FileActivityLog> fileActivityLog = fm.AsQueryable();


            return Json(new { fm, hbl, sm });
        }
        //Get HBL Activity data
        //     [HttpGet]
        //     public IActionResult GetHblActivityData(string hblnumber)
        //     {
        //_context.Database.SetCommandTimeout(300);
        //var hblact = _context.HBLActivityLog.Include(x => x.Hbl).Include(x => x.Activity).Include(x => x.Status).Where(x => x.Hbl.HBLNumber == hblnumber).ToList();
        //         IQueryable<HBLActivityLog> hblActivityLog = hblact.AsQueryable();
        //         foreach (var item in hblact)
        //         {
        //             hblActivityLog.Select(x => new HBLActivityLog
        //             {
        //                 ActivityId = _context.HBLActivityLog.Where(x => x.Activity.Id == item.ActivityId).Select(x => x.Activity.NameOfActivity).FirstOrDefault(),
        //                 StatusId = _context.HBLActivityLog.Where(x => x.Status.Id == item.StatusId).Select(x => x.Status.Status).FirstOrDefault(),
        //                 UserId = _context.HBLActivityLog.Where(x => x.ApplicationUser.Id == item.UserId).Select(x => x.ApplicationUser.UserName).FirstOrDefault(),

        //             }).ToList();
        //         }
        //         return Json(hblact);
        //     }

        [HttpGet]
        public IActionResult GetHblActivityData(string hblnumber)
        {
            _context.Database.SetCommandTimeout(300);

            // Fetch the raw data from the context and include necessary relationships
            var distinctHblActivityLog = _context.HBLActivityLog
                .Include(x => x.Hbl)
                .Include(x => x.Activity)
                .Include(x => x.Status)
                .Where(x => x.Hbl.HBLNumber == hblnumber)
                .ToList();

            // Remove duplicates by grouping based on ActivityId, StatusId, and UserId and selecting the latest based on EndDate
            var hblact = distinctHblActivityLog
                .GroupBy(x => new { x.ActivityId, x.StatusId, x.UserId })
                .Select(group => group
                    .OrderByDescending(x => x.EndDate) // Order by EndDate, assuming the latest record is based on EndDate
                    .FirstOrDefault()) // Get the latest record for each group
                .ToList();

            // Update the fetched data to project into a new object, similar to your original loop
            var result = hblact.Select(item => new
            {
                Activity = _context.HBLActivityLog.Where(x => x.Activity.Id == item.ActivityId)
                    .Select(x => x.Activity.NameOfActivity)
                    .FirstOrDefault(),
                Status = _context.HBLActivityLog.Where(x => x.Status.Id == item.StatusId)
                    .Select(x => x.Status.Status)
                    .FirstOrDefault(),
                User = _context.HBLActivityLog.Where(x => x.ApplicationUser.Id == item.UserId)
                    .Select(x => x.ApplicationUser.UserName)
                    .FirstOrDefault(),
                EndDate = item.EndDate // Include EndDate if required
            }).ToList();

            // Return the distinct result as JSON
            return Json(hblact);
        }
        //Get HBL Query Data 
        public IActionResult HBLQuery(string fileNumber)
        {
			_context.Database.SetCommandTimeout(300);
			ViewBag.ActivityMaster = _context.ActivityMaster.OrderBy(x => x.NameOfActivity).Where(x => x.Source == "Upload").ToList();
            ViewBag.Countries = _context.CountryMaster.ToList();
            IEnumerable<HBLQueryActivity> data = null;
            var username = _httpContextAccessor.HttpContext.User.Identity.Name;
            var role = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Role);
            if (fileNumber != null)
            {
                if (role != "User")
                {
                    data = (from fa in _context.HBLActivityLog
                            join am in _context.ActivityMaster
                            on fa.ActivityId equals am.Id
                            join sm in _context.StatusMaster
                            on fa.StatusId equals sm.Id
                            join um in _context.Users
                            on fa.UserId equals um.Id
                            join hm in _context.HBLMaster
                            on fa.HBLId equals hm.Id

                            select (new HBLQueryActivity
                            {
                                Id = hm.Id,
                                FileNo = hm.File.ToString(),
                                BookingNo = hm.Booking,
                                HBLNo = hm.HBLNumber,
                                CountryName = hm.File.Country.CountryName,
                                CustomerName = hm.CustomerName,
                                UserId = um.UserName,
                                ActivityId = fa.Activity.NameOfActivity,
                                StatusId = fa.Status.Status,
                                Comment = fa.Comment,
                                ProcessDate = fa.StartDate,
                                Etd = hm.File.Etd,
                                StartDate = fa.StartDate,
                                EndDate = fa.EndDate

                            })).OrderByDescending(x => x.Etd);
                }
                else
                {
                    data = (from fa in _context.HBLActivityLog
                            join am in _context.ActivityMaster
                            on fa.ActivityId equals am.Id
                            join sm in _context.StatusMaster
                            on fa.StatusId equals sm.Id
                            join um in _context.Users
                            on fa.UserId equals um.Id
                            where (um.UserName == User.Identity.Name)
                            join hm in _context.HBLMaster
                            on fa.HBLId equals hm.Id

                            select (new HBLQueryActivity
                            {
                                Id = hm.Id,
                                FileNo = hm.File.ToString(),
                                BookingNo = hm.Booking,
                                HBLNo = hm.HBLNumber,
                                CountryName = hm.File.Country.CountryName,
                                CustomerName = hm.CustomerName,
                                UserId = um.UserName,
                                ActivityId = fa.Activity.NameOfActivity,
                                StatusId = fa.Status.Status,
                                Comment = fa.Comment,
                                ProcessDate = fa.StartDate,
                                Etd = hm.File.Etd,
                                StartDate = fa.StartDate,
                                EndDate = fa.EndDate
                            })).OrderByDescending(x => x.Etd);
                }
            }
            else
            {
                ViewBag.Status = _context.StatusMaster.ToList();

                if (role != "User")
                {
                    data = (from fa in _context.HBLActivityLog
                            join am in _context.ActivityMaster
                            on fa.ActivityId equals am.Id
                            join sm in _context.StatusMaster
                            on fa.StatusId equals sm.Id
                            join um in _context.Users
                            on fa.UserId equals um.Id
                            join hm in _context.HBLMaster
                            on fa.HBLId equals hm.Id

                            select (new HBLQueryActivity
                            {
                                Id = hm.Id,
                                FileNo = hm.File.ToString(),
                                BookingNo = hm.Booking,
                                HBLNo = hm.HBLNumber,
                                CountryName = hm.File.Country.CountryName,
                                CustomerName = hm.CustomerName,
                                UserId = um.UserName,
                                ActivityId = fa.Activity.NameOfActivity,
                                StatusId = fa.Status.Status,
                                Comment = fa.Comment,
                                ProcessDate = fa.StartDate,
                                Etd = hm.File.Etd,
                                StartDate = fa.StartDate,
                                EndDate = fa.EndDate
                            })).OrderByDescending(x => x.Etd);
                }
                else
                {
                    data = (from fa in _context.HBLActivityLog
                            join am in _context.ActivityMaster
                            on fa.ActivityId equals am.Id
                            join sm in _context.StatusMaster
                            on fa.StatusId equals sm.Id
                            join um in _context.Users
                            on fa.UserId equals um.Id
                            where (um.UserName == User.Identity.Name)
                            join hm in _context.HBLMaster
                            on fa.HBLId equals hm.Id

                            select (new HBLQueryActivity
                            {
                                Id = hm.Id,
                                FileNo = hm.File.ToString(),
                                BookingNo = hm.Booking,
                                HBLNo = hm.HBLNumber,
                                CountryName = hm.File.Country.CountryName,
                                CustomerName = hm.CustomerName,
                                UserId = um.UserName,
                                ActivityId = fa.Activity.NameOfActivity,
                                StatusId = fa.Status.Status,
                                Comment = fa.Comment,
                                ProcessDate = fa.StartDate,
                                Etd = hm.File.Etd,
                                StartDate = fa.StartDate,
                                EndDate = fa.EndDate
                            })).OrderByDescending(x => x.Etd);
                }
            }
            ViewBag.StatusMaster = _context.StatusMaster.ToList();
            return View(data);
        }
        //Get Hbl activity Query data 
        //     [HttpGet]
        //     public IActionResult GetHBLActivityQuery(string Id)
        //     {
        //_context.Database.SetCommandTimeout(300);
        //var sm = _context.StatusMaster.ToList();
        //         var HBL = _context.HBLActivityLog.Where(fileActivity => fileActivity.HBLId == Id)
        //         .Join(_context.ActivityMaster, activityJoin => activityJoin.ActivityId, activityMaster => activityMaster.Id, (activityJoin, activityMaster) => new { activityJoin, activityMaster })
        //         .Join(_context.StatusMaster, statusjoin => statusjoin.activityJoin.StatusId, statusMaster => statusMaster.Id, (statusjoin, statusMaster) => new { statusjoin, statusMaster })
        //         .Join(_context.Users, userjoin => userjoin.statusjoin.activityJoin.ApplicationUser.Id, User => User.Id, (userjoin, User) => new
        //         {

        //             Id = userjoin.statusjoin.activityMaster.Id,
        //             ActivityName = userjoin.statusjoin.activityMaster.NameOfActivity,
        //             Status = userjoin.statusMaster.Status,
        //             ProcessedDate = userjoin.statusjoin.activityJoin.EndDate,
        //             User = User.UserName,
        //             Comment = userjoin.statusjoin.activityJoin.Comment == null ? "" : userjoin.statusjoin.activityJoin.Comment,
        //         }).OrderByDescending(x => x.ProcessedDate).ToList().Where(x => x.Status == "Query").AsQueryable();

        //         return Json(new { HBL, sm, Id });
        //     }

        [HttpGet]
        public IActionResult GetHBLActivityQuery(string Id)
        {
            _context.Database.SetCommandTimeout(300);
            var sm = _context.StatusMaster.ToList();

            var HBL = _context.HBLActivityLog
                .Where(fileActivity => fileActivity.HBLId == Id)
                .Join(_context.ActivityMaster,
                    activityJoin => activityJoin.ActivityId,
                    activityMaster => activityMaster.Id,
                    (activityJoin, activityMaster) => new { activityJoin, activityMaster })
                .Join(_context.StatusMaster,
                    statusjoin => statusjoin.activityJoin.StatusId,
                    statusMaster => statusMaster.Id,
                    (statusjoin, statusMaster) => new { statusjoin, statusMaster })
                .Join(_context.Users,
                    userjoin => userjoin.statusjoin.activityJoin.ApplicationUser.Id,
                    User => User.Id,
                    (userjoin, User) => new
                    {
                        Id = userjoin.statusjoin.activityMaster.Id,
                        ActivityName = userjoin.statusjoin.activityMaster.NameOfActivity,
                        Status = userjoin.statusMaster.Status,
                        ProcessedDate = userjoin.statusjoin.activityJoin.EndDate,
                        User = User.UserName,
                        Comment = userjoin.statusjoin.activityJoin.Comment == null ? "" : userjoin.statusjoin.activityJoin.Comment,
                    })
                .Where(x => x.Status == "Query")
                .GroupBy(x => new { x.Id, x.ActivityName, x.Status, x.User, x.Comment }) // Group by relevant fields
                .Select(g => new
                {
                    g.Key.Id,
                    g.Key.ActivityName,
                    g.Key.Status,
                    ProcessedDate = g.Max(x => x.ProcessedDate), // Update with the maximum EndDate
                    g.Key.User,
                    g.Key.Comment
                })
                .OrderByDescending(x => x.ProcessedDate)
                .AsQueryable();

            return Json(new { HBL, sm, Id });
        }

        //Hbl change activity status
        public IActionResult HBLActivityChangeStatus(HBLQueryActivity hbl)
        {
			_context.Database.SetCommandTimeout(300);
			string Msg = "";

            var activityId = _context.ActivityMaster.Where(x => x.NameOfActivity == hbl.ActivityId).Select(x => x.Id).FirstOrDefault();
            var statusId = _context.StatusMaster.Where(x => x.Status == hbl.StatusId).Select(x => x.Id).FirstOrDefault();
            var userId = _context.Users.Where(x => x.UserName == hbl.UserId).Select(x => x.Id).FirstOrDefault();
            var hbldata = _context.HBLActivityLog.Where(x => x.Id == hbl.Id && x.ActivityId == activityId).FirstOrDefault();
            var hblActivityLog = _context.HBLActivityLog.FirstOrDefault(x => x.HBLId == hbl.Id);

            _context.HBLActivitylogHistory.Add(new HBLActivitylogHistory
            {

                HBLogId = hbl.Id,
                ActivityId = hblActivityLog.ActivityId,
                StatusId = hblActivityLog.StatusId,
                Comment = hblActivityLog.Comment,
                UserId = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier),
                StartDate = DateTime.UtcNow,
                EndDate = DateTime.UtcNow,
            });

            if (hblActivityLog != null)
            {
                hblActivityLog.ActivityId = hblActivityLog.ActivityId;
                hblActivityLog.StatusId = statusId;
                hblActivityLog.StartDate = hblActivityLog.StartDate;
                hblActivityLog.Comment = hbl.Comment;
                hblActivityLog.UserId = userId;
                hblActivityLog.EndDate = DateTime.UtcNow;

                _context.SaveChanges();
                Msg = "Status Update Successfully.";
            }
            else
            {
                Msg = "Error while processing the request.";
            }


            return Json(Msg);
        }

        public IActionResult FileActivityChangeStatus(FileQueryActivity filequery)
        {
			_context.Database.SetCommandTimeout(300);
			string Msg = "";

            var activityId = _context.ActivityMaster.Where(x => x.NameOfActivity == filequery.ActivityId).Select(x => x.Id).FirstOrDefault();
            var statusId = _context.StatusMaster.Where(x => x.Status == filequery.StatusId).Select(x => x.Id).FirstOrDefault();
            var userId = _context.Users.Where(x => x.UserName == filequery.UserId).Select(x => x.Id).FirstOrDefault();

            var fileActivityLog = _context.FileActivityLog.Where(x => x.FileId == filequery.Id && x.ActivityId == activityId).FirstOrDefault();


            _context.FileAcitivityLogHistory.Add(new FileAcitivityLogHistory
            {
                FileLogId = fileActivityLog.Id,
                ActivityId = fileActivityLog.ActivityId,
                StatusId = statusId,
                Comment = fileActivityLog.Comment,
                UserId = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier),
                StartDate = DateTime.UtcNow,
                EndDate = DateTime.UtcNow,
            });

            if (fileActivityLog != null)
            {
                fileActivityLog.ActivityId = fileActivityLog.ActivityId;
                fileActivityLog.StatusId = filequery.StatusId;
                //fileActivityLog.StartDate = filequery.ProcessDate;
                fileActivityLog.Comment = filequery.Comment;
                fileActivityLog.UserId = userId;

                _context.SaveChanges();
                Msg = "Status Update Successfully.";
            }
            else
            {
                Msg = "Error while processing the request.";
            }

            return Json(Msg);
        }

        //     [HttpGet]
        //     public IActionResult GetHBLAllocate(string Id)
        //     {
        //_context.Database.SetCommandTimeout(300);
        //var HBL = _context.HBLActivityLog.Where(x => x.HBLId == Id)
        //         .Include(activity => activity.Activity)
        //         .Include(status => status.Status)
        //         .Include(user => user.ApplicationUser)
        //         .Select(x => new
        //         {
        //             Id = x.Activity.Id,
        //             ActivityName = x.Activity.NameOfActivity,
        //             Status = x.Status.Status,
        //             ProcessedDate = x.EndDate,
        //             User = x.ApplicationUser.UserName,
        //             Comment = x.Comment == null ? "" : x.Comment,
        //         })
        //        .OrderByDescending(x => x.ProcessedDate).ToList().AsQueryable()
        //        .ToList();

        //         if (HBL != null)

        //             HBL = HBL.Where(x => x.Status == "WIP").Select(x => new
        //             {
        //                 Id = x.Id,
        //                 ActivityName = x.ActivityName,
        //                 Status = x.Status,
        //                 ProcessedDate = x.ProcessedDate,
        //                 User = x.User,
        //                 Comment = x.Comment == null ? "" : x.Comment,
        //             }).OrderByDescending(x => x.ProcessedDate).ToList().AsQueryable()
        //                            .ToList();
        //         return Json(HBL);
        //     }

        [HttpGet]
        public IActionResult GetHBLAllocate(string Id)
        {
            _context.Database.SetCommandTimeout(300);

            var HBL = _context.HBLActivityLog
                .Where(x => x.HBLId == Id)
                .Include(activity => activity.Activity)
                .Include(status => status.Status)
                .Include(user => user.ApplicationUser)
                .Select(x => new
                {
                    Id = x.Activity.Id,
                    ActivityName = x.Activity.NameOfActivity,
                    Status = x.Status.Status,
                    ProcessedDate = x.EndDate,
                    User = x.ApplicationUser.UserName,
                    Comment = x.Comment ?? "",  // Use null-coalescing operator for brevity
                })
                .OrderByDescending(x => x.ProcessedDate)
                .ToList(); // Execute the query and load results into memory

            if (HBL != null)
            {
                // Group by Activity ID and User, and select the latest EndDate
                HBL = HBL
                    .GroupBy(x => new
                    {
                        x.Id,
                        x.ActivityName,
                        x.Status,
                        x.User,
                        x.Comment
                    })
                    .Select(g => g.OrderByDescending(x => x.ProcessedDate).FirstOrDefault())
                    .Where(x => x.Status == "WIP") // Filter for WIP status
                    .OrderByDescending(x => x.ProcessedDate)
                    .ToList(); // Execute the query again and load results into memory
            }

            return Json(HBL);
        }


        //Report
        public ActionResult UserReport()
        {

            return View();
        }
        //Report Download
        [HttpPost]
        public ActionResult Report(ReportViewModel report)
        {
			_context.Database.SetCommandTimeout(300);
			var UserId = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            List<ReportTemplateModel> HBLdata = new List<ReportTemplateModel>();
            List<ChatsViewModel> chats = new List<ChatsViewModel>();
            string statusId = _context.StatusMaster.Where(x => x.Status.ToUpper() == "WIP").Select(x => x.Id).FirstOrDefault();
            if (report.ReportType == "Production Report")
            {
                if (report.start_date.ToShortDateString() != "1/1/0001")
                {
                    //    HBLdata = (from ha in _context.HBLActivityLog
                    //               where ((ha.EndDate != null && ha.EndDate.Value.Date >= report.start_date.Date && ha.EndDate.Value.Date <= report.end_date.Date) || (ha.StartDate != null && ha.StatusId == statusId && ha.StartDate.Value.Date >= report.start_date.Date && ha.StartDate.Value.Date <= report.end_date.Date) || ha.StatusId == statusId)
                    //               join hm in _context.HBLMaster
                    //               on ha.HBLId equals hm.Id
                    //               join fa in _context.FileMaster
                    //               on hm.FileId equals fa.Id
                    //               join am in _context.ActivityMaster
                    //               on ha.ActivityId equals am.Id
                    //               join um in _context.Users
                    //               on ha.UserId equals um.Id
                    //               where (um.Id == UserId)
                    //               select new ReportTemplateModel
                    //               {
                    //                   OfficeName = fa.Country.CountryName,
                    //                   FileNumber = fa.FileNumber,
                    //                   Container = hm.Container,
                    //                   BookingNo = hm.Booking,
                    //                   ETD = fa.Etd,
                    //                   HBL_No = hm.HBLNumber,
                    //                   ActivityId = am.NameOfActivity,
                    //                   StatusId = ha.Status.Status,
                    //                   Comment = ha.Comment,
                    //                   UserId = um.UserName,
                    //                   EnterDate = hm.EnterDate,
                    //                   StartDate = ha.StartDate,
                    //                   EndDate = ha.EndDate,
                    //                   AES_UN = ha.AES_UN,
                    //                   QUOTE_NUMBER = ha.QUOTE_NUMBER,
                    //                   MblNumber = ha.MblNumber
                    //               }).ToList();
                    //}
                    //else
                    //{
                    //    HBLdata = (from ha in _context.HBLActivityLog
                    //               join hm in _context.HBLMaster
                    //               on ha.HBLId equals hm.Id
                    //               join fa in _context.FileMaster
                    //               on hm.FileId equals fa.Id
                    //               join am in _context.ActivityMaster
                    //               on ha.ActivityId equals am.Id
                    //               join um in _context.Users
                    //               on ha.UserId equals um.Id
                    //               where ((um.Id == UserId && ha.EndDate != null && ha.EndDate.Value.Date >= report.start_date.Date && ha.EndDate.Value.Date <= report.end_date.Date || ha.StatusId == statusId) || (um.Id == UserId && ha.StatusId == statusId))
                    //               select new ReportTemplateModel
                    //               {
                    //                   OfficeName = fa.Country.CountryName,
                    //                   FileNumber = fa.FileNumber,
                    //                   Container = hm.Container,
                    //                   BookingNo = hm.Booking,
                    //                   ETD = fa.Etd,
                    //                   HBL_No = hm.HBLNumber,
                    //                   ActivityId = am.NameOfActivity,
                    //                   StatusId = ha.Status.Status,
                    //                   Comment = ha.Comment,
                    //                   UserId = um.UserName,
                    //                   EnterDate = hm.EnterDate,
                    //                   StartDate = ha.StartDate,
                    //                   EndDate = ha.EndDate,
                    //                   AES_UN = ha.AES_UN,
                    //                   QUOTE_NUMBER = ha.QUOTE_NUMBER,
                    //                   MblNumber = ha.MblNumber
                    //               }).ToList();
                    //}

                    //DataTable hbldt = ToDataTable(HBLdata);

                    ////saveFile.Filter = "Excel files (*.xlsx)|*.xlsx";
                    ////saveFile.Filter = "Excel files (*.xlsx)";
                    //string filename = "";
                    ////filename = saveFile.FileName;
                    //string apath = filename + ".xlsx";
                    //using (XLWorkbook wb = new XLWorkbook())
                    //{
                    //    var wsHblData = wb.Worksheets.Add(hbldt);

                    //    try
                    //    {
                    //        using (MemoryStream stream = new MemoryStream())
                    //        {
                    //            wb.SaveAs(stream);
                    //            string excelname = $"UserReport-{DateTime.Now.ToString("ddmmyyyy hh:mm:ss")}.xlsx";
                    //            return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                    //        }

                    //        // System.Windows.Forms.MessageBox.Show("File Save Successfully.!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    //    }
                    //    catch (Exception ex)
                    //    {
                    //        // System.Windows.Forms.MessageBox.Show("Something went wrong.!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    //    }
                    //}

                    _context.Database.SetCommandTimeout(300);

                    // Get statusId once
                    //var statusId = _context.StatusMaster
                    //                        .Where(x => x.Status == "WIP")
                    //                        .Select(x => x.Id)
                    //                        .FirstOrDefault();

                    // Retrieve HBLActivityLogs with necessary includes and filtering in one query
                    var hblActivityLogs = _context.HBLActivityLog.Where(x =>
                                                (x.UserId == UserId && x.EndDate != null && x.EndDate.Value.Date >= report.start_date.Date && x.EndDate.Value.Date <= report.end_date.Date) ||
                                                (x.StartDate != null && x.StatusId == statusId && x.StartDate.Value.Date >= report.start_date.Date && x.StartDate.Value.Date <= report.end_date.Date) ||
                                                x.StatusId == statusId)
                                            .Include(x => x.Hbl)
                                            .ThenInclude(h => h.File)
                                            .ThenInclude(f => f.Country)
                                            .Include(x => x.Status)
                                            .Include(x => x.Activity)
                                            .Include(x => x.ApplicationUser)
                                            .ToList();

                    var distinctFileIds = hblActivityLogs.Select(x => x.Hbl.FileId).Distinct();

                    // Get the count of HBLs for each file using a join and grouping
                    var fileHBLCounts = _context.HBLMaster
                        .Where(h => distinctFileIds.Contains(h.FileId))
                        .GroupBy(h => h.FileId)
                        .Select(g => new { FileId = g.Key, Count = g.Count() })
                        .ToDictionary(x => x.FileId, x => x.Count);

                    // Prepare data for FileDashModel and ReportTemplateModel in a single query to avoid multiple database hits
                    //data = hblActivityLogs.Select(x => new FileDashModel
                    //{
                    //    CountryName = x.Hbl.File.Country.CountryName,
                    //    DraftCutOff = x.Hbl.File.DraftCutoff,
                    //    ETD = x.Hbl.File.Etd,
                    //    FileNumber = x.Hbl.File.FileNumber,
                    //    ActivityId = x.Activity.NameOfActivity,
                    //    StatusId = x.Status.Status,
                    //    Comment = x.Comment,
                    //    UserId = x.ApplicationUser.UserName,
                    //    EnterDate = x.Hbl.File.EnterDate,
                    //    CountofHBL = fileHBLCounts.ContainsKey(x.Hbl.FileId) ? fileHBLCounts[x.Hbl.FileId] : 0,
                    //}).ToList();

                    HBLdata = hblActivityLogs.Select(x => new ReportTemplateModel
                    {
                        OfficeName = x.Hbl.File.Country.CountryName,
                        FileNumber = x.Hbl.File.FileNumber,
                        Container = x.Hbl.Container,
                        BookingNo = x.Hbl.Booking,
                        ETD = x.Hbl.File.Etd,
                        HBL_No = x.Hbl.HBLNumber,
                        ActivityId = x.Activity.NameOfActivity,
                        StatusId = x.Status.Status,
                        Comment = x.Comment,
                        UserId = x.ApplicationUser.UserName,
                        EnterDate = x.Hbl.EnterDate,
                        StartDate = x.StartDate,
                        EndDate = x.EndDate,
                        AES_UN = x.AES_UN,
                        QUOTE_NUMBER = x.QUOTE_NUMBER,
                        MblNumber = x.MblNumber
                    }).ToList();

                    // Convert lists to DataTables
                    //DataTable filedata = ToDataTable(data);
                    DataTable hbldata = ToDataTable(HBLdata);

                    // Export to Excel
                    string filename = $"ProductionReport-{DateTime.Now:ddMMyyyy hh_mm_ss}.xlsx";
                    using (XLWorkbook wb = new XLWorkbook())
                    {
                        //filedata.TableName = "File Data";
                        hbldata.TableName = "HBL Data";
                        //var wsFileData = wb.Worksheets.Add(filedata);
                        var wsHblData = wb.Worksheets.Add(hbldata);

                        // Uncomment these lines if column adjustment is needed
                        // wsFileData.Columns().AdjustToContents();
                        // wsHblData.Columns().AdjustToContents();

                        try
                        {
                            using (MemoryStream stream = new MemoryStream())
                            {
                                wb.SaveAs(stream);
                                return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", filename);
                            }
                        }
                        catch (Exception ex)
                        {
                            // Handle exception (consider logging it)
                            throw new Exception("An error occurred while generating the report.", ex);
                        }
                    }
                }
            }
            else
            {
                var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
                var userRole = _context.UserRoles.FirstOrDefault(x => x.UserId == userid);
                var role = _context.Roles.FirstOrDefault(x => x.Id == userRole.RoleId)?.Name;
                string empId = Convert.ToString(_context.Users.FirstOrDefault(x => x.Id == userid)?.EmpId);

                if (role == "User")
                {
                    //var chatMaster = _context.ChatMaster.Where(x => x.SenderId == empId || x.ReceiverId == empId).ToList();
                    chats = _context.ChatMaster.Where(x => x.SendTime.Value.Date >= report.start_date.Date && x.SendTime.Value.Date <= report.end_date.Date && (x.SenderId == empId || x.ReceiverId == empId))
                       .Select(x => new ChatsViewModel
                       {
                           Sender = _context.Users.Where(y => y.EmpId == Convert.ToInt32(x.SenderId)).Select(y => y.CitrixId).FirstOrDefault(),
                           Receiver = _context.Users.Where(y => y.EmpId == Convert.ToInt32(x.ReceiverId)).Select(y => y.CitrixId).FirstOrDefault(),
                           ReferenceNo = x.ReferenceNo,
                           Comments = x.Comments,
                           ReadByUser = x.Isread == true ? "Yes" : "No",
                           ReadTime = x.ReadTime,
                           SendTime = x.SendTime
                       }).ToList();
                }
                else
                {
                    chats = _context.ChatMaster.Where(x => x.SendTime.Value.Date >= report.start_date.Date && x.SendTime.Value.Date <= report.end_date.Date)
                       .Select(x => new ChatsViewModel
                       {
                           Sender = _context.Users.Where(y => y.EmpId == Convert.ToInt32(x.SenderId)).Select(y => y.CitrixId).FirstOrDefault(),
                           Receiver = _context.Users.Where(y => y.EmpId == Convert.ToInt32(x.ReceiverId)).Select(y => y.CitrixId).FirstOrDefault(),
                           ReferenceNo = x.ReferenceNo,
                           Comments = x.Comments,
                           ReadByUser = x.Isread == true ? "Yes" : "No",
                           ReadTime = x.ReadTime,
                           SendTime = x.SendTime
                       }).ToList();
                }
                DataTable chatdata = ToDataTable(chats);

                string filename = "";
                string apath = filename + ".xlsx";
                using (XLWorkbook wb = new XLWorkbook())
                {
                    chatdata.TableName = "User Chat Data";
                    var wsChatData = wb.Worksheets.Add(chatdata);

                    wsChatData.Columns().AdjustToContents();
                    try
                    {
                        using (MemoryStream stream = new MemoryStream())
                        {
                            wb.SaveAs(stream);
                            string excelname = $"UserChatReport-{DateTime.Now.ToString("ddMMyyyy hh_mm_ss")}.xlsx";
                            return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                        }
                    }
                    catch (Exception ex)
                    {

                    }
                }
            }
            return View();
        }

        //List to Database convert
        public DataTable ToDataTable<T>(List<T> items)
        {
            DataTable dataTable = new DataTable(typeof(T).Name);
            //Get all the properties by using reflection   
            PropertyInfo[] Props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
            foreach (PropertyInfo prop in Props)
            {
                //Setting column names as Property names  
                dataTable.Columns.Add(prop.Name);
            }
            foreach (T item in items)
            {
                var values = new object[Props.Length];
                for (int i = 0; i < Props.Length; i++)
                {

                    values[i] = Props[i].GetValue(item, null);
                }
                dataTable.Rows.Add(values);
            }

            return dataTable;
        }

        //HBLActivity Datatable
        public IActionResult HBLActivity()
        {
            ViewBag.Countries = _context.CountryMaster.ToList();
            ViewBag.Activity = _context.ActivityMaster.Where(x => x.Source == "Upload").ToList();
            ViewBag.Status = _context.StatusMaster.ToList();

            return View();
        }

        ///Extra example of searchable datatable
        [HttpPost]
        public IActionResult GetDatatable(DataTableAjaxPostModel model, string country, string fileNumber, string hBLNumber)
        {
			_context.Database.SetCommandTimeout(300);
			var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var username = _httpContextAccessor.HttpContext.User.Identity.Name;
            var role = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Role);


            // Get the data for the DataTable
            var data1 = _context.HBLActivityLog.Include(x => x.Activity).AsQueryable();
            var threeMonthsAgo = DateTime.Now.AddMonths(-3);

            IEnumerable<HBLQueryActivity> files;

            IEnumerable<HBLQueryActivity> data = null;

            //if (role == "Supervisor")
            //{
            //    //data = (from fa in _context.HBLActivityLog
            //    //        join am in _context.ActivityMaster
            //    //        on fa.ActivityId equals am.Id
            //    //        join sm in _context.StatusMaster
            //    //        on fa.StatusId equals sm.Id
            //    //        join um in _context.Users
            //    //        on fa.UserId equals um.Id
            //    //        //where (um.Id==userid)
            //    //        join hm in _context.HBLMaster
            //    //        on fa.HBLId equals hm.Id
            //    //        join fm in _context.FileMaster
            //    //        on hm.FileId equals fm.Id
            //    //        join cm in _context.CountryMaster
            //    //        on fm.CountryId equals cm.Id
            //    //        where (hm.EnterDate >= threeMonthsAgo)
            //    //        select (new HBLQueryActivity
            //    //        {
            //    //            Id = hm.Id,
            //    //            FileNo = fm.FileNumber,
            //    //            BookingNo = hm.Booking,
            //    //            HBLNo = hm.HBLNumber,
            //    //            //CountryName = hm.File.Country.CountryName,
            //    //            CountryName = cm.CountryName,
            //    //            UserId = um.UserName,
            //    //            ActivityId = fa.Activity.NameOfActivity,
            //    //            StatusId = fa.Status.Status,
            //    //            Comment = fa.Comment,
            //    //            StartDate = fa.StartDate,
            //    //            EndDate = fa.EndDate,
            //    //            Etd = hm.File.Etd,
            //    //            AES_UN = fa.AES_UN,
            //    //            QUOTE_NUMBER = fa.QUOTE_NUMBER,
            //    //            MblNumber = fa.MblNumber
            //    //        }));

            //     data = _context.HBLActivityLog.Include(x => x.Hbl).Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Include(x => x.Hbl.File).Include(x => x.Hbl.File.Country)
            //        .Where(x => x.Hbl.File.Etd.Value.Date >= threeMonthsAgo.Date)
            //        .Select(x => new HBLQueryActivity
            //        {
            //            Id = x.Hbl.Id,
            //            FileNo = x.Hbl.File.FileNumber,
            //            BookingNo = x.Hbl.Booking,
            //            HBLNo = x.Hbl.HBLNumber,
            //            CountryName = x.Hbl.File.Country.CountryName,
            //            UserId = x.ApplicationUser.UserName,
            //            ActivityId = x.Activity.NameOfActivity,
            //            StatusId = x.Status.Status,
            //            Comment = x.Comment,
            //            StartDate = x.StartDate,
            //            EndDate = x.EndDate,
            //            Etd = x.Hbl.File.Etd,
            //            AES_UN = x.AES_UN,
            //            QUOTE_NUMBER = x.QUOTE_NUMBER,
            //            MblNumber = x.MblNumber,
            //            CustomerName = x.Hbl.CustomerName
            //        });

            //}
            //else
            //{
            //    //data = (from fa in _context.HBLActivityLog
            //    //        join am in _context.ActivityMaster
            //    //        on fa.ActivityId equals am.Id
            //    //        join sm in _context.StatusMaster
            //    //        on fa.StatusId equals sm.Id
            //    //        join um in _context.Users
            //    //        on fa.UserId equals um.Id
            //    //        join hm in _context.HBLMaster
            //    //        on fa.HBLId equals hm.Id
            //    //        join fm in _context.FileMaster
            //    //        on hm.FileId equals fm.Id
            //    //        join cm in _context.CountryMaster
            //    //        on fm.CountryId equals cm.Id
            //    //        where (um.Id == userid && hm.EnterDate >= threeMonthsAgo)
            //    //        select (new HBLQueryActivity
            //    //        {
            //    //            Id = hm.Id,
            //    //            FileNo = fm.FileNumber,
            //    //            BookingNo = hm.Booking,
            //    //            HBLNo = hm.HBLNumber,
            //    //            //CountryName = hm.File.Country.CountryName,
            //    //            CountryName = cm.CountryName,
            //    //            UserId = um.UserName,
            //    //            ActivityId = fa.Activity.NameOfActivity,
            //    //            StatusId = fa.Status.Status,
            //    //            Comment = fa.Comment,
            //    //            StartDate = fa.StartDate,
            //    //            EndDate = fa.EndDate,
            //    //            Etd = hm.File.Etd,
            //    //            AES_UN = fa.AES_UN,
            //    //            QUOTE_NUMBER = fa.QUOTE_NUMBER,
            //    //            MblNumber = fa.MblNumber
            //    //        }));

            //     data = _context.HBLActivityLog.Include(x => x.Hbl).Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Include(x => x.Hbl.File).Include(x => x.Hbl.File.Country)
            //        .Where(x => x.Hbl.File.Etd.Value.Date >= threeMonthsAgo.Date && x.UserId == userid)
            //        .Select(x => new HBLQueryActivity
            //        {
            //            Id = x.Hbl.Id,
            //            FileNo = x.Hbl.File.FileNumber,
            //            BookingNo = x.Hbl.Booking,
            //            HBLNo = x.Hbl.HBLNumber,
            //            CountryName = x.Hbl.File.Country.CountryName,
            //            UserId = x.ApplicationUser.UserName,
            //            ActivityId = x.Activity.NameOfActivity,
            //            StatusId = x.Status.Status,
            //            Comment = x.Comment,
            //            StartDate = x.StartDate,
            //            EndDate = x.EndDate,
            //            Etd = x.Hbl.File.Etd,
            //            AES_UN = x.AES_UN,
            //            QUOTE_NUMBER = x.QUOTE_NUMBER,
            //            MblNumber = x.MblNumber,
            //            CustomerName = x.Hbl.CustomerName
            //        });

            //}

            if (role == "Supervisor")
            {
                var rawData = _context.HBLActivityLog
                    .Include(x => x.Hbl)
                    .Include(x => x.Activity)
                    .Include(x => x.ApplicationUser)
                    .Include(x => x.Status)
                    .Include(x => x.Hbl.File)
                    .Include(x => x.Hbl.File.Country)
                    .Where(x => x.Hbl.File.Etd.Value.Date >= threeMonthsAgo.Date)
                    .Select(x => new
                    {
                        x.Hbl.Id,
                        FileNo = x.Hbl.File.FileNumber,
                        BookingNo = x.Hbl.Booking,
                        HBLNo = x.Hbl.HBLNumber,
                        CountryName = x.Hbl.File.Country.CountryName,
                        UserId = x.ApplicationUser.UserName,
                        ActivityId = x.Activity.NameOfActivity,
                        StatusId = x.Status.Status,
                        Comment = x.Comment,
                        StartDate = x.StartDate,
                        EndDate = x.EndDate,
                        Etd = x.Hbl.File.Etd,
                        AES_UN = x.AES_UN,
                        QUOTE_NUMBER = x.QUOTE_NUMBER,
                        MblNumber = x.MblNumber,
                        CustomerName = x.Hbl.CustomerName
                    })
                    .ToList();  // Materialize the query into memory

                data = rawData
                    .GroupBy(x => new { x.BookingNo, x.HBLNo })
                    .Select(g => g.First())  // Select the first distinct record in each group
                    .Select(x => new HBLQueryActivity
                    {
                        Id = x.Id,
                        FileNo = x.FileNo,
                        BookingNo = x.BookingNo,
                        HBLNo = x.HBLNo,
                        CountryName = x.CountryName,
                        UserId = x.UserId,
                        ActivityId = x.ActivityId,
                        StatusId = x.StatusId,
                        Comment = x.Comment,
                        StartDate = x.StartDate,
                        EndDate = x.EndDate,
                        Etd = x.Etd,
                        AES_UN = x.AES_UN,
                        QUOTE_NUMBER = x.QUOTE_NUMBER,
                        MblNumber = x.MblNumber,
                        CustomerName = x.CustomerName
                    })
                    .ToList();
            }
            else
            {
                var rawData = _context.HBLActivityLog
                    .Include(x => x.Hbl)
                    .Include(x => x.Activity)
                    .Include(x => x.ApplicationUser)
                    .Include(x => x.Status)
                    .Include(x => x.Hbl.File)
                    .Include(x => x.Hbl.File.Country)
                    .Where(x => x.Hbl.File.Etd.Value.Date >= threeMonthsAgo.Date && x.UserId == userid)
                    .Select(x => new
                    {
                        x.Hbl.Id,
                        FileNo = x.Hbl.File.FileNumber,
                        BookingNo = x.Hbl.Booking,
                        HBLNo = x.Hbl.HBLNumber,
                        CountryName = x.Hbl.File.Country.CountryName,
                        UserId = x.ApplicationUser.UserName,
                        ActivityId = x.Activity.NameOfActivity,
                        StatusId = x.Status.Status,
                        Comment = x.Comment,
                        StartDate = x.StartDate,
                        EndDate = x.EndDate,
                        Etd = x.Hbl.File.Etd,
                        AES_UN = x.AES_UN,
                        QUOTE_NUMBER = x.QUOTE_NUMBER,
                        MblNumber = x.MblNumber,
                        CustomerName = x.Hbl.CustomerName
                    })
                    .ToList();  // Materialize the query into memory

                data = rawData
                    .GroupBy(x => new { x.BookingNo, x.HBLNo })
                    .Select(g => g.First())  // Select the first distinct record in each group
                    .Select(x => new HBLQueryActivity
                    {
                        Id = x.Id,
                        FileNo = x.FileNo,
                        BookingNo = x.BookingNo,
                        HBLNo = x.HBLNo,
                        CountryName = x.CountryName,
                        UserId = x.UserId,
                        ActivityId = x.ActivityId,
                        StatusId = x.StatusId,
                        Comment = x.Comment,
                        StartDate = x.StartDate,
                        EndDate = x.EndDate,
                        Etd = x.Etd,
                        AES_UN = x.AES_UN,
                        QUOTE_NUMBER = x.QUOTE_NUMBER,
                        MblNumber = x.MblNumber,
                        CustomerName = x.CustomerName
                    })
                    .ToList();
            }




            files = data.DistinctBy(x => x.BookingNo).AsEnumerable();

            // Return the data in the format required by DataTables  
            return Json(new
            {
                draw = model.draw,
                recordsTotal = data1.Count(),
                recordsFiltered = files.Count(),
                data = files
            });
        }

        public IActionResult HBLDatatable()
        {
            return View();
        }
        //Get HBLdatatable values
        [HttpPost]
        public IActionResult GetHBLDatatable(DataTableAjaxPostModel model, string country, string fileNumber, string hBLNumber)
        {
			_context.Database.SetCommandTimeout(300);
			int totalRecord = 0;
            int filterRecord = 0;
            int hblrecord = 0;
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            var searchValue = Request.Form["search[value]"].FirstOrDefault();
            int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "0");
            int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");
            // Get the data for the DataTable
            var data1 = _context.HBLMaster.Include(x => x.HBLActivityLogs).AsQueryable();

            List<HBLQueryActivity> result = new List<HBLQueryActivity>();

            IEnumerable<HBLQueryActivity> files;

            IEnumerable<HBLQueryActivity> data = null;
            data = _context.HBLMaster.Include(y => y.HBLActivityLogs).Select(x => new HBLQueryActivity
            {

                Id = x.Id,
                CountryName = x.File.Country.CountryName,
                HBLNo = x.HBLNumber,
                Container = x.Container,
                BookingNo = x.Booking,
                Etd = x.File.Etd,
                CustomerName = x.CustomerName
            });
            result = data.ToList();

            IQueryable<HBLQueryActivity> SortedData = result.AsQueryable();
            if (!string.IsNullOrEmpty(country))
            {
                SortedData = SortedData.Where(x => x.CountryName == country);

            }
            //if (!string.IsNullOrEmpty(container))
            //{
            //    SortedData = SortedData.Where(x => x.Container == container);

            //}
            //if (!string.IsNullOrEmpty(hblstatus) && hblstatus != "--select--")
            //{
            //    SortedData = SortedData.Where(x => x.Hblstatus == hblstatus);

            //}
            //if (!string.IsNullOrEmpty(userId) && userId != "--select--")
            //{
            //    var userName = _ctx.UserMaster.Where(x => x.Id == userId).Select(x => x.UserName).FirstOrDefault();
            //    SortedData = SortedData.Where(x => x.UserId == userName);

            //}
            //if (!string.IsNullOrEmpty(office) && office != "--select--")
            //{
            //    SortedData = SortedData.Where(x => x.Office == office);

            //}
            //if (!string.IsNullOrEmpty(eta_d))
            //{
            //    SortedData = SortedData.Where(x => x.Eta == Convert.ToDateTime(eta_d));

            //}





            // Return the data in the format required by DataTables  
            //return Json(new
            //{
            //    draw = model.draw,
            //    recordsTotal = data1.Count(),
            //    recordsFiltered = files.Count(),
            //    data = files
            //});

            try
            {

                if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
                    SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();

            }
            catch { }



            return Json(new
            {
                draw = model.draw,
                recordsTotal = SortedData.Count(),
                recordsFiltered = SortedData.Count(),
                data = SortedData.Skip(skip).Take(pageSize == -1 ? 100 : pageSize).ToList(),
                skip = skip,
                pageSize = pageSize,
            });


        }
        //Show Production count
        [HttpPost]
        public JsonResult GetUserDatacountProd()
        {
			_context.Database.SetCommandTimeout(300);
			var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);

            List<ApplicationUser> udata = _context.Users.Where(x => x.Id == userid).ToList();
            List<HBLActivityLog> fdata = _context.HBLActivityLog.Include(x => x.Status).ToList();
            var result = from c in fdata
                         group c.UserId by c.UserId into g
                         select new
                         {
                             Username = udata.Where(x => x.Id == g.Key).Select(x => x.UserName).FirstOrDefault(),
                             Total = fdata.Where(x => x.UserId == g.Key).Count(),
                             WIP = fdata.Where(x => x.UserId == g.Key && x.Status.Status == "WIP").Count(),
                             Pending = fdata.Where(x => x.UserId == g.Key && (x.Status.Status == "Pending" || x.Status.Status == "Query")).Count(),
                             Completed = fdata.Where(x => x.UserId == g.Key && x.Status.Status == "Completed").Count()
                         };

            try
            {

                if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
                    result = result.AsQueryable().OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
            }
            catch { }

            int totalRecord = 0;
            int filterRecord = 0;

            var returnObj = new
            {
                data = result.Where(x => x.Username != null)
            };

            return Json(returnObj);
        }

        //Show User wise Production count filter by dates
        [HttpPost]
        public JsonResult GetUserDatacount1(string start_date, string end_date)
        {
			_context.Database.SetCommandTimeout(300);
			var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);

            List<ApplicationUser> udata = _context.Users.Where(x => x.Id == userid).ToList();
            List<HBLActivityLog> fdata = _context.HBLActivityLog.Include(x => x.Status).Where(x => x.EndDate >= Convert.ToDateTime(start_date) && x.EndDate <= Convert.ToDateTime(end_date)).ToList();

            var result = from c in fdata
                         group c.UserId by c.UserId into g
                         select new
                         {
                             Username = udata.Where(x => x.Id == g.Key).Select(x => x.UserName).FirstOrDefault(),
                             Total = fdata.Where(x => x.UserId == g.Key).Count(),
                             WIP = fdata.Where(x => x.UserId == g.Key && x.Status.Status == "WIP").Count(),
                             Pending = fdata.Where(x => x.UserId == g.Key && (x.Status.Status == "Pending" || x.Status.Status == "Query")).Count(),
                             Completed = fdata.Where(x => x.UserId == g.Key && x.Status.Status == "Completed").Count()
                         };

            try
            {

                if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
                    result = result.AsQueryable().OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
            }
            catch { }

            int totalRecord = 0;
            int filterRecord = 0;

            var returnObj = new
            {
                data = result.Where(x => x.Username != null)
            };

            return Json(returnObj);
        }

        //User Dashoboard
        public IActionResult UserDashboard()
        {
			_context.Database.SetCommandTimeout(300);
			List<UserDashboardViewModel> userdashboardModel = new List<UserDashboardViewModel>();

            ViewData["Activity"] = _context.ActivityMaster.OrderBy(x => x.Id).ToList();
            ViewData["User"] = _context.Users.OrderBy(x => x.CitrixId).ToList();
            ViewData["Completed"] = _context.StatusMaster.Where(x => x.Status == "Completed").Select(x => x.Id).FirstOrDefault();
            ViewData["Pending"] = _context.StatusMaster.Where(x => x.Status == "Pending").Select(x => x.Id).FirstOrDefault();
            ViewData["Query"] = _context.StatusMaster.Where(x => x.Status == "Query").Select(x => x.Id).FirstOrDefault();
            ViewData["WIP"] = _context.StatusMaster.Where(x => x.Status == "WIP").Select(x => x.Id).FirstOrDefault();
            ViewData["User"] = _context.Users.OrderBy(x => x.CitrixId).ToList();
            ViewData["Status"] = _context.StatusMaster.OrderBy(x => x.Status).ToList();
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);

            var activityList = _context.ActivityMaster.OrderBy(x => x.Id).ToList();

            string completed = _context.StatusMaster.Where(x => x.Status == "Completed").Select(x => x.Id).FirstOrDefault();
            string pending = _context.StatusMaster.Where(x => x.Status == "Pending").Select(x => x.Id).FirstOrDefault();
            string query = _context.StatusMaster.Where(x => x.Status == "Query").Select(x => x.Id).FirstOrDefault();
            string wip = _context.StatusMaster.Where(x => x.Status == "WIP").Select(x => x.Id).FirstOrDefault();

            var data = _context.HBLActivityLog.Include(x => x.Hbl).GroupBy(x => new
            {
                x.ApplicationUser.CitrixId,

            }).Select(x => new UserDashboardViewModel
            {
                User = x.Key.CitrixId,
                Count = x.Count(),

            }).ToList();

            foreach (UserDashboardViewModel dashboard in data.Where(x => x.User == userid))
            {
                dashboard.HBLCount = _context.HBLActivityLog.Where(x => x.ApplicationUser.CitrixId == dashboard.User).Include(x => x.Hbl).Include(x => x.Activity)
                .GroupBy(x =>
                new
                {
                    x.ApplicationUser.CitrixId,
                    x.Activity.Id,
                    x.StatusId,

                }).Select(x => new HBLCount
                {
                    Count = x.Count(),
                    Status = x.Key.StatusId,
                    ActivityId = x.Key.Id,

                }).ToList();

                foreach (ActivityMaster activityMaster in activityList.Where(x => x.IsActive == true))
                {

                    dashboard.Completed = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status.Contains(completed)).Sum(x => x.Count);
                    dashboard.Pending = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status.Contains(pending)).Sum(x => x.Count);
                    dashboard.Query = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status.Contains(query)).Sum(x => x.Count);
                    dashboard.WIP = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status.Contains(wip)).Sum(x => x.Count);
                    dashboard.HBLStatusCount.Add(new HBLStatusCount
                    {
                        Completed = dashboard.Completed,
                        Pending = dashboard.Pending,
                        Query = dashboard.Query,
                        WIP = dashboard.WIP

                    });

                    dashboard.TotalCompleted = dashboard.HBLCount.Where(x => x.Status.Contains(completed)).Sum(x => x.Count);
                    dashboard.TotalPending = dashboard.HBLCount.Where(x => x.Status.Contains(pending)).Sum(x => x.Count);
                    dashboard.TotalQuery = dashboard.HBLCount.Where(x => x.Status.Contains(query)).Sum(x => x.Count);
                    dashboard.TotalWIP = dashboard.HBLCount.Where(x => x.Status.Contains(wip)).Sum(x => x.Count);
                }
            }

            // Calculate the total counts for each user
            var totalCounts = new UserDashboardViewModel
            {
                User = "Total",
                Count = data.Sum(x => x.Count),
                Completed = data.Sum(x => x.TotalCompleted),
                Pending = data.Sum(x => x.TotalPending),
                Query = data.Sum(x => x.TotalQuery),
                WIP = data.Sum(x => x.TotalWIP)
            };

            userdashboardModel.AddRange(data);
            userdashboardModel.Add(totalCounts);

            return View(userdashboardModel);

        }

        public ActionResult GetCountofUser(DateTime? StartDate, DateTime? EndDate, string ActivityId)
        {
			_context.Database.SetCommandTimeout(300);
			List<UserDashboardViewModel> userdashboardModel = new List<UserDashboardViewModel>();
            ViewData["Activity"] = _context.ActivityMaster.OrderBy(x => x.Id).ToList();
            ViewData["User"] = _context.Users.OrderBy(x => x.CitrixId).ToList();
            ViewData["Status"] = _context.StatusMaster.OrderBy(x => x.Status).ToList();
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var citrixId = _context.Users.Where(x => x.Id == userid).Select(x => x.CitrixId).FirstOrDefault();
            var activityList = _context.ActivityMaster.OrderBy(x => x.Id).ToList();
            List<StatusMaster> _status = _context.StatusMaster.ToList();

            string completed = _status.Where(x => x.Status == "Completed").Select(x => x.Id).FirstOrDefault();
            string pending = _status.Where(x => x.Status == "Pending").Select(x => x.Id).FirstOrDefault();
            string query = _status.Where(x => x.Status == "Query").Select(x => x.Id).FirstOrDefault();
            string wip = _status.Where(x => x.Status == "WIP").Select(x => x.Id).FirstOrDefault();
            string followup1 = _status.Where(x => x.Status == "Followup1").Select(x => x.Id).FirstOrDefault();
            string followup2 = _status.Where(x => x.Status == "Followup2").Select(x => x.Id).FirstOrDefault();
            string followup3 = _status.Where(x => x.Status == "Followup3").Select(x => x.Id).FirstOrDefault();
            if (StartDate != null && EndDate != null)
            {
                var data = _context.HBLActivityLog.Where(x => x.EndDate.Value.Date >= StartDate.Value.Date && x.EndDate.Value.Date <= EndDate.Value.Date && x.UserId == userid).Include(x => x.Hbl).GroupBy(x => new
                {
                    x.ApplicationUser.CitrixId,
                }).Select(x => new UserDashboardViewModel
                {
                    User = x.Key.CitrixId,
                    Count = x.Count(),
                }).ToList();

                foreach (UserDashboardViewModel dashboard in data.Where(x => x.User == citrixId))
                {
                    dashboard.HBLCount = _context.HBLActivityLog.Where(x => x.ApplicationUser.CitrixId == dashboard.User && x.EndDate.Value.Date >= StartDate.Value.Date && x.EndDate.Value.Date <= EndDate.Value.Date).Include(x => x.Hbl).Include(x => x.Activity)
                    .GroupBy(x =>
                    new
                    {
                        x.Activity.Id,
                        x.StatusId,
                    }).Select(x => new HBLCount
                    {
                        Count = x.Count(),
                        Status = x.Key.StatusId,
                        ActivityId = x.Key.Id,
                    }).ToList();

                    foreach (ActivityMaster activityMaster in activityList.Where(x => x.IsActive == true))
                    {
                        dashboard.Completed = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status.Contains(completed)).Sum(x => x.Count);
                        dashboard.Pending = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status.Contains(pending)).Sum(x => x.Count);
                        dashboard.Query = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status.Contains(query)).Sum(x => x.Count);
                        dashboard.WIP = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status.Contains(wip)).Sum(x => x.Count);
                        dashboard.Followup1 = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status.Contains(followup1)).Sum(x => x.Count);
                        dashboard.Followup2 = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status.Contains(followup2)).Sum(x => x.Count);
                        dashboard.Followup3 = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status.Contains(followup3)).Sum(x => x.Count);


                        dashboard.HBLStatusCount.Add(new HBLStatusCount
                        {
                            Completed = dashboard.Completed,
                            Pending = dashboard.Pending + dashboard.Followup1 + dashboard.Followup2 + dashboard.Followup3,
                            Query = dashboard.Query,
                            WIP = dashboard.WIP
                        });

                        dashboard.TotalCompleted = dashboard.TotalCompleted + dashboard.Completed;
                        dashboard.TotalPending += dashboard.Pending;
                        dashboard.TotalQuery += dashboard.Query;
                        dashboard.TotalWIP += dashboard.WIP;
                    }
                }

                userdashboardModel.AddRange(data);
                return Json(userdashboardModel);
            }
            else
            {
                var data = _context.HBLActivityLog.Where(x => x.UserId == userid).Include(x => x.Hbl).GroupBy(x => new
                {
                    x.ApplicationUser.CitrixId,

                }).Select(x => new UserDashboardViewModel
                {
                    User = x.Key.CitrixId,
                    Count = x.Count()

                }).ToList();

                foreach (UserDashboardViewModel dashboard in data.Where(x => x.User == citrixId))
                {
                    dashboard.HBLCount = _context.HBLActivityLog.Where(x => x.ApplicationUser.CitrixId == dashboard.User).Include(x => x.Hbl).Include(x => x.Activity)
                    .GroupBy(x =>
                    new
                    {
                        x.ApplicationUser.CitrixId,
                        x.Activity.Id,
                        x.StatusId,
                    }).Select(x => new HBLCount
                    {
                        Count = x.Count(),
                        Status = x.Key.StatusId,
                        ActivityId = x.Key.Id,
                    }).ToList();

                    foreach (ActivityMaster activityMaster in activityList.Where(x => x.IsActive == true))
                    {
                        dashboard.Completed = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status.Contains(completed)).Sum(x => x.Count);
                        dashboard.Pending = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status.Contains(pending)).Sum(x => x.Count);
                        dashboard.Query = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status.Contains(query)).Sum(x => x.Count);
                        dashboard.WIP = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status.Contains(wip)).Sum(x => x.Count);
                        dashboard.Followup1 = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status.Contains(followup1)).Sum(x => x.Count);
                        dashboard.Followup2 = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status.Contains(followup2)).Sum(x => x.Count);
                        dashboard.Followup3 = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status.Contains(followup3)).Sum(x => x.Count);


                        dashboard.HBLStatusCount.Add(new HBLStatusCount
                        {
                            Completed = dashboard.Completed,
                            Pending = dashboard.Pending + dashboard.Followup1 + dashboard.Followup2 + dashboard.Followup3,
                            Query = dashboard.Query,
                            WIP = dashboard.WIP
                        });

                        dashboard.TotalCompleted = dashboard.TotalCompleted + dashboard.Completed;
                        dashboard.TotalPending += dashboard.Pending + dashboard.Followup1 + dashboard.Followup2 + dashboard.Followup3;
                        dashboard.TotalQuery += dashboard.Query;
                        dashboard.TotalWIP += dashboard.WIP;
                    }
                }

                var overallTotal = new UserDashboardViewModel
                {
                    User = "Total",
                    Count = data.Sum(x => x.Count),
                    TotalCompleted = data.Sum(x => x.TotalCompleted),
                    TotalPending = data.Sum(x => x.TotalPending),
                    TotalQuery = data.Sum(x => x.TotalQuery),
                    TotalWIP = data.Sum(x => x.TotalWIP),
                };

                foreach (ActivityMaster activityMaster in activityList.Where(x => x.IsActive == true))
                {
                    var activityTotal = new HBLStatusCount
                    {
                        ActivityId = activityMaster.Id,
                        Completed = data.Sum(x => x.HBLCount
                            .Where(c => c.ActivityId == activityMaster.Id && c.Status.Contains(completed))
                            .Sum(c => c.Count)),
                        Pending = data.Sum(x => x.HBLCount
                            .Where(c => c.ActivityId == activityMaster.Id && c.Status.Contains(pending))
                            .Sum(c => c.Count)),
                        Query = data.Sum(x => x.HBLCount
                            .Where(c => c.ActivityId == activityMaster.Id && c.Status.Contains(query))
                            .Sum(c => c.Count)),
                        WIP = data.Sum(x => x.HBLCount
                            .Where(c => c.ActivityId == activityMaster.Id && c.Status.Contains(wip))
                            .Sum(c => c.Count))
                    };
                    overallTotal.HBLStatusCount.Add(activityTotal);
                }
                data.Add(overallTotal);
                userdashboardModel.AddRange(data);
                //userdashboardModel.AddRange(data);
            }
            return View(userdashboardModel);
        }

        public ActionResult Quotation()
        {
            //ViewData["StatusMaster"] = _context.StatusMaster.Where(x => x.Status == "Pending" || x.Status == "Completed").ToList();
            //ViewData["ActivityMaster"] = _context.ActivityMaster.Where(x => x.NameOfActivity == "FCL Quotes").ToList();
            ViewData["CountryMaster"] = _context.CountryMaster.ToList();
            //ViewData["Users"] = _context.Users.ToList();
            return View();
        }

        //Save Quation FCL Quotes Activity
        public ActionResult SaveQuotes(QuotationViewModel quotationViewModel)
        {
			_context.Database.SetCommandTimeout(300);
			var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            string Msg = string.Empty;
            try
            {
                if (quotationViewModel != null)
                {
                    _context.QutationMaster.Add(new QutationMaster
                    {

                        ContainerType = quotationViewModel.ContainerType,
                        DoorPort = quotationViewModel.DoorPort,
                        QuoteDate = quotationViewModel.QuoteDate,
                        BookingOffice = quotationViewModel.BookingOffice,
                        QuoteNumber = quotationViewModel.QuoteNumber,
                        startDate = quotationViewModel.startDate,
                        //Comment = quotationViewModel.Comment,
                        //CustomerName = quotationViewModel.CustomerName,
                        //ActivityId = quotationViewModel.ActivityId == "none" ? "" : quotationViewModel.ActivityId,
                        //Status = quotationViewModel.Status,
                        UserId = userid,
                        enddate = DateTime.UtcNow
                    });
                    _context.SaveChanges();
                    Msg = "Save Successfully!";
                }
                else
                {
                    Msg = "Model is null";
                }
            }
            catch (Exception ex)
            {
                Msg = "Error " + ex.Message;
            }

            return Json(Msg);
        }

        [HttpGet]
        public IActionResult getMessages()
        {
			_context.Database.SetCommandTimeout(300);
			var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var receiverid = _context.Users.Where(x => x.Id == userid).FirstOrDefault();
            List<ChatViewModel> model = new List<ChatViewModel>();
            DateTime twodaysago = DateTime.Now.AddDays(-2);
            var result = _context.ChatMaster.Where(x => x.ReceiverId == receiverid.EmpId.ToString() && x.SendTime.Value.Date >= twodaysago.Date)
                .Select(x => new ChatViewModel
                {
                    Id = x.Id,
                    ReferenceNo = x.ReferenceNo,
                    Comments = x.Comments,
                    SendTime = x.SendTime,
                    Isread = x.Isread,
                    SenderId = _context.Users.Where(y => y.EmpId.ToString() == x.SenderId).Select(y => y.CitrixId).FirstOrDefault()
                }).OrderByDescending(x => x.Isread == false).ThenByDescending(x => x.SendTime).ToList();
            //result.ToList();
            model.AddRange(result);

            return Json(model);
        }

        [HttpPost]
        public JsonResult ActionedMassges(string Id)
        {
			_context.Database.SetCommandTimeout(300);
			var result = _context.ChatMaster.Where(x => x.Id == Id).FirstOrDefault();
            if(result != null)
            {
                result.ReadTime = DateTime.UtcNow;
                result.Isread = true;
                _context.ChatMaster.Update(result);
                _context.SaveChanges();
                return Json("Actioned");
            }
            else
            {
                return Json("Failed");
            }
        }

        [HttpGet]
        public IActionResult SelectRole()
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);

            ViewData["AssignedRoles"] = _context.UserRoles.Where(x => x.UserId == userid).Select(x => new RoleNameList
            {
                RoleId = x.RoleId,
                RoleName = _context.Roles.Where(y => y.Id == x.RoleId).Select(x => x.Name).FirstOrDefault()

            }).ToList();
            return View();
        }

        [HttpGet]
        public IActionResult RoleAction(string RoleName)
        {
            if (RoleName.ToUpper().ToString() == "SUPERVISOR" || RoleName.ToUpper().ToString() == "MANAGER" || RoleName.ToUpper().ToString() == "ADMIN")
            {
                return RedirectToAction("Index", "Dashboard");
            }
            else if (RoleName.ToUpper().ToString() == "USER")
            {
                return RedirectToAction("Index", "User");
            }
            else
            {
                return NotFound();
            }
            return View();
        }

    }
}

