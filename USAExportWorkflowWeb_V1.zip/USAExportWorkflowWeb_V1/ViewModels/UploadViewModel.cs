﻿using USAExportWorkflowWeb_V1.DataModel;

namespace USAExportWorkflowWeb_V1.ViewModels
{
	public class UploadViewModel
	{
		public int CountryId { get; set; }
		public string UploadId { get; set; }
		public IFormFile File { get; set; }
	}
}
