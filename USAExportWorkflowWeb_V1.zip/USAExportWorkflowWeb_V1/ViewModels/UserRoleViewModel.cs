﻿namespace USAExportWorkflowWeb_V1.ViewModels
{
    public class UserRoleViewModel
    {
        public string RoleId { get; set; }
        public string UserId { get; set; }
    }
}
