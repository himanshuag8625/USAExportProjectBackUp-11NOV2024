﻿namespace USAExportWorkflowWeb_V1.ViewModels
{
    public class Dashboardcount
    {
        public string FileNumber { get; set; }
        public string ActivityName { get; set; }
        public string CountryName { get; set; }
        public string CurrentStatus { get; set; }

    }
}
