﻿namespace USAExportWorkflowWeb_V1.ViewModels
{
    public class HBLActivityLogViewModel
    {
        public string? HblId { get; set; }
        public string? ActivityId { get; set; }

        public string? StatusId { get; set; }
        public string? Container { get; set; }
        public string? Comment { get; set; }

        public string? Booking { get; set; }

        public string? UserId { get; set; } = null!;

        public DateTime? StartDate { get; set; }

        public DateTime? EndDate { get; set; }
        public string? AES_UN { get; set; }
        public string? QUOTE_NUMBER { get; set; }
        public string? MblNumber { get; set; }

    }
}
