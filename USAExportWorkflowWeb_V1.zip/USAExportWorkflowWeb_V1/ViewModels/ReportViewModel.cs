﻿namespace USAExportWorkflowWeb_V1.ViewModels
{
    public class ReportViewModel
    {
        public string ReportType { get; set; }
        public DateTime start_date { get; set; }
        public DateTime end_date { get; set; }
    }
}
