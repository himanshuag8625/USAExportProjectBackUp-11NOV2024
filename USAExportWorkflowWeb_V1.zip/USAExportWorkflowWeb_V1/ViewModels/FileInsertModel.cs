﻿namespace USAExportWorkflowWeb_V1.ViewModels
{
    public class FileInsertModel
    {        
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string CountryId { get; set; }
        public string FileNumber { get; set; } = null!;
        public string? Container { get; set; } = null!;
        public DateTime? ETD { get; set; }
        public DateTime? DraftCutOff { get; set; }
        public DateTime? EnterDate { get; set; }=DateTime.Now;
        public bool? IsActive { get; set; } = true;
        public bool IsDelete { get; set; } = false;

            
       
    }
}
