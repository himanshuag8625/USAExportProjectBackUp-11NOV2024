﻿namespace USAExportWorkflowWeb_V1.ViewModels
{
    public class QuotationViewModel
    {
        public string QuoteNumber { get; set; }
        public string  ContainerType { get; set; }
        //public string?  CustomerName { get; set; }
        public string BookingOffice { get; set; }
        public string DoorPort { get; set; }
        public DateTime? QuoteDate { get; set; }
        //public string? ActivityId { get; set; }
        //public string? Status { get; set; }
       
        //public string? Comment { get; set; }
        public string UserId { get; set; }
        public DateTime? startDate { get; set; }
       
        public DateTime? enddate { get; set; }
    }
}
