﻿namespace USAExportWorkflowWeb_V1.ViewModels
{
    public class DashboardProdcount
    {
        public int Received { get; set; }
        public int WIP { get; set; }
        public int Completed { get; set; }
        public int Pending { get; set; }
        public int UnAllocated { get; set; }
        public int Query { get; set; }
        public int etd2 { get; set; }
        public int etd5 { get; set; }
        public int etd10 { get; set; }
    }
}
