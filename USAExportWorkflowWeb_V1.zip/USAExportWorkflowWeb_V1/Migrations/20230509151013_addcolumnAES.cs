﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace USAExportWorkflowWeb_V1.Migrations
{
    public partial class addcolumnAES : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {  

            migrationBuilder.AddColumn<int>(
                name: "AES_UN",
                table: "HBLActivityLog",
                type: "int",
                nullable: true);

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "AES_UN",
                table: "HBLActivityLog");

           
        }
    }
}
