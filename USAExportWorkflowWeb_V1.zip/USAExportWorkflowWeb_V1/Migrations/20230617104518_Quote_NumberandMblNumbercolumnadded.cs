﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace USAExportWorkflowWeb_V1.Migrations
{
    public partial class Quote_NumberandMblNumbercolumnadded : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "MblNumber",
                table: "HBLActivityLog",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "QUOTE_NUMBER",
                table: "HBLActivityLog",
                type: "nvarchar(max)",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "MblNumber",
                table: "HBLActivityLog");

            migrationBuilder.DropColumn(
                name: "QUOTE_NUMBER",
                table: "HBLActivityLog");
        }
    }
}
