﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace USAExportWorkflowWeb_V1.Migrations
{
    public partial class addstartandenddate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "ActivityId",
                table: "QutationMaster",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "enddate",
                table: "QutationMaster",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "startDate",
                table: "QutationMaster",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ActivityId",
                table: "QutationMaster");

            migrationBuilder.DropColumn(
                name: "enddate",
                table: "QutationMaster");

            migrationBuilder.DropColumn(
                name: "startDate",
                table: "QutationMaster");
        }
    }
}
