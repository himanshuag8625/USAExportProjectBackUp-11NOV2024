﻿namespace USAExportWorkflowWeb_V1.DataModel
{
    public class HBLProductionCount
    {
        public string ActivityName { get; set; }
        public string User { get; set; }

        public int Completed { get; set; }
        public int WIP { get; set; }
        public int Query { get; set; }
        public int Pending { get; set; }


    }
}
