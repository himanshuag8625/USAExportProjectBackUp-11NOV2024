﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace USAExportWorkflowWeb_V1.DataModel
{

    public partial class HBLMaster
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();

        [MaxLength(100)]
        public string HBLNumber { get; set; } = null!;

        public string FileId { get; set; }

        public string CustomerName { get; set; } = null!;

        [MaxLength(100)]
        public string? Container { get; set; } = null!;

        [MaxLength(100)]
        public string Booking { get; set; } = null!;

        public DateTime EnterDate { get; set; }

        public bool? IsActive { get; set; } = true;
        public bool IsDelete { get; set; } = false;

        [ForeignKey("FileId")]
        public virtual FileMaster File { get; set; }

        public virtual ICollection<HBLActivityLog> HBLActivityLogs { get; set; } 
    }
}